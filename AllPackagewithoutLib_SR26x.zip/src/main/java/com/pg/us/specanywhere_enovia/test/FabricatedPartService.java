package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.bo.PromotionalItemPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;


public class FabricatedPartService {
	private static Logger LOGGER = Logger.getLogger(FabricatedPartService.class);

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		StopWatch sp = new StopWatch();
		sp.start();

		//String objId = "20336.41905.35538.57424";    // 90537946

		//String objId = "20336.41905.36504.39272";   // 91672665
		
		String objId = "20336.41905.20224.6509";  
		
		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
		Context context = pool.checkOut();
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();

		Map<String,String> mpHeaderResult = new HashMap<String,String>();
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mpMaterialResult = new HashMap<String,String>();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Map<String,String> mpSubstitute = new HashMap<String,String>();
		Map<String,String> mpNotes = new HashMap<String,String>();
		Map<String,String> mapWeightCharResult = new HashMap<String,String>();
		Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
		Map<String,String> mpPlantResult = new HashMap<String,String>();
		Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
		Map<String,String> mpDerivedToResult = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
		Map<String,String> mpPerformChar = new HashMap<String,String>();
		Map<String,String> mpSecurity = new HashMap<String,String>();
		Map<String,String> mapReferenceDocs = new HashMap<String, String>();
		Map<String,String> mpRelatedATS = new HashMap<String,String>();
		Map<String,String> mpMasterSpecs = new HashMap<String,String>();
		Map<String,String> mpMEPResult = new HashMap<String,String>();
		Map<String,String> mpSEPResult = new HashMap<String,String>();
		Map<String,String> mpMasterAttribute = new HashMap<String,String>();
		Map<String,String> mapCosResult = new HashMap<String,String>();


		FabricatedPartBO FABBO = new FabricatedPartBO();
		StringValidatorUtil validator = new StringValidatorUtil();

		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, StringList> BusinessObjectSelectableMap = FABBO.getFabricatedPartSelectables(context);
		Map<String, StringList> ChilsObjectSelectableMap = FABBO.getFABRelatedObjsSelectableMap(context);
		StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);


		DomainObject doFAB =  FABBO.getFABDO(context, objId);
		FABBO.addMultiList();
		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doFAB.getInfo(context, slContextSelects);
		swAttributes.stop();
		LOGGER.info("FAB GETINFO ELAPSED TIME : "+swAttributes.getTime());
		FABBO.removeMultiList();

		StringList slHistoryInfo = (StringList)resultMaps.get(ConstantsUtil.SELECT_HISTORY);
		String lastUpdatedUser = util.getLastUpdateUser(slHistoryInfo);

		//Master Attribute Data
		String sMasterID= (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID) : ConstantsUtil.EMPTY_STRING);
		if(validator.isNotNullOrEmpty(sMasterID)){
			StopWatch swMasterAttrib = new StopWatch();
			swMasterAttrib.start();
			mpMasterAttribute = FABBO.getMasterAttributeData(context,sMasterID);
			swMasterAttrib.stop();
			LOGGER.info("FAB GET MASTER ATTRIB ELAPSED TIME : "+swMasterAttrib.getTime());
		}

		//Header Content
		mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
		mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);

		//Basic  Data
		mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TEMPLATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_TEMPLATE)))?(String)resultMaps.get(ConstantsUtil.STR_TEMPLATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);		
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.POWERSOURCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEQUANTITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPANDBOMONSAPBOMASFED, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);		
		mpAttribResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LEGACYENVCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS) : ConstantsUtil.EMPTY_STRING);


		//LifeCycle
		String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
		String[] changeargs={objId,sPhysicalId};
		StopWatch swLifecycle = new StopWatch();
		swLifecycle.start();
		mpLifeCycleApproval = util.getCOName(context, changeargs);
		swLifecycle.stop();
		LOGGER.info("FAB GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
		mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);


		//Organization Data
		StopWatch swOrganization = new StopWatch();
		swOrganization.start();
		mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization = util.filterMapList(mpOrganization);
		swOrganization.stop();
		LOGGER.info("FAB Organization ELAPSED TIME : "+swOrganization.getTime());

		// Materials
		mpMaterialResult = FABBO.getSubstances(resultMaps);

		//BOM
		StopWatch swBom = new StopWatch();
		swBom.start();
		MapList mapList = doFAB.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.SYMBL_ASTERISK, slChildBusSelects , slChildRelSelects, false, true, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
		if(mapList.size()!=0){
			mpEBOMResult =FABBO.parseMaplist(context,mapList);
			mpSubstitute = FABBO.getSubstitute(context,mapList);
		}
		//Notes 
		MasterCOPBO mcop = new MasterCOPBO();
		mpNotes=mcop.updateNotes(context,resultMaps);
		swBom.stop();
		LOGGER.info("FAB BOM ELAPSED TIME : "+swBom.getTime());

		//Sap BOM
		StopWatch swSapBomAsFed = new StopWatch();
		swSapBomAsFed.start();
		mpSapBomAsFedcResult = FABBO.getSapBomAsFed(resultMaps);		
		//mpSapBomAsFedcResult = util.filterMapList(mpSapBomAsFedcResult);
		swSapBomAsFed.stop();
		LOGGER.info("APP GET SapBomAsFed ELAPSED TIME : "+swSapBomAsFed.getTime());

		//Weight Characteristics
		StopWatch swWeightCharacteristics = new StopWatch();
		swWeightCharacteristics.start();
		mapWeightCharResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mapWeightCharResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
		mapWeightCharResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mapWeightCharResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mapWeightCharResult.put(ConstantsUtil.TYPE,  util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mapWeightCharResult = util.filterMapList(mapWeightCharResult);
		swWeightCharacteristics.stop();
		LOGGER.info("FAB GET swWeightCharacteristics ELAPSED TIME : "+swSapBomAsFed.getTime());

		//Plant Data
		StopWatch swPlant = new StopWatch();
		swPlant.start();
		mpPlantResult = FABBO.updatePlantInfo(resultMaps);
		swPlant.stop();
		LOGGER.info("FAB Plant ELAPSED TIME : "+swPlant.getTime());

		//Derived Data
		StopWatch swDerived = new StopWatch();
		swDerived.start();
		String sName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_DERIVED_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_DERIVED_NAME) : ConstantsUtil.EMPTY_STRING;
		String sRev = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_DERIVED_REVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_DERIVED_REVISION) : ConstantsUtil.EMPTY_STRING;
		String sCreatedDate = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING;
		mpDerivedFromResult = FABBO.updateDerivedDataInfo(context,sName, sRev, sCreatedDate, doFAB,true,false);
		mpDerivedToResult = FABBO.updateDerivedDataInfo(context,sName, sRev, sCreatedDate, doFAB,false,true);

		swDerived.stop();
		LOGGER.info("FAB  Derived ELAPSED TIME : "+swDerived.getTime());

		//Ownership
		mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);

		//RelatedSpec
		StopWatch swRelatedSpec = new StopWatch();
		swRelatedSpec.start();
		mpRelatedSpecResult = util.updatePartSpec(context, resultMaps);
		swRelatedSpec.stop();
		LOGGER.info("FAB  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());

		//Performance Car
		Map paramMap = new HashMap();
		paramMap.put(ConstantsUtil.OBJECT_ID, objId);
		paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
		paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
		paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

		PerformanceCharcteristics perform = new PerformanceCharcteristics();
		StopWatch swPerfChar = new StopWatch();
		swPerfChar.start();
		MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
		if(!mlPerformChar.isEmpty())
		{
			FinishedProductPartBO fppBO = new FinishedProductPartBO();
			MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
			//mpPerformChar =util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
			swPerfChar.stop();
			LOGGER.info("FAB GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
		}
		//Security
		StopWatch swSecurity = new StopWatch();
		CommonBusUtilBO commonBo = new CommonBusUtilBO();
		swSecurity.start();
		mpSecurity =commonBo.updateSecurity(context,resultMaps);
		swSecurity.stop();
		LOGGER.info("FAB  Security ELAPSED TIME : "+swSecurity.getTime());

		//Reference Docs
		StopWatch swReference= new StopWatch();
		swReference.start();
		mapReferenceDocs =  mcop.updateRefDocs(context, resultMaps);
		swReference.stop();
		LOGGER.info("FAB  Reference ELAPSED TIME : "+swReference.getTime());

		//Market of Sale
		StringList slCos=(validator.isNotNullOrEmpty((StringList)resultMaps.get(ConstantsUtil.SELECT_COS_NAME)));
		String strCos = slCos.toString();
		strCos = strCos.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
		mapCosResult.put(ConstantsUtil.COUNTRIESOFSALE, strCos);
		StringList slCosRestriction = (validator.isNotNullOrEmpty((StringList)resultMaps.get(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION)));
		String strCosRestriction = slCosRestriction.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
		mapCosResult.put(ConstantsUtil.COUNTRIESOFSALERESTRICTIONS,strCosRestriction);
		StringList slCosDateAndTime = (validator.isNotNullOrEmpty((StringList)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE)));
		String strCosDateAndTime = slCosDateAndTime.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
		mapCosResult.put(ConstantsUtil.DATEANDTIMEOFLASTCOSCALC, strCosDateAndTime);
		//mapCosResult = util.filterMapList(mapCosResult);

		//Master Specs
		mpMasterSpecs.put(ConstantsUtil.ID,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_ID)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_ID) : ConstantsUtil.EMPTY_STRING);
		mpMasterSpecs.put(ConstantsUtil.NAME,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_NAME)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_NAME) : ConstantsUtil.EMPTY_STRING);
		mpMasterSpecs.put(ConstantsUtil.TITLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_TITLE)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpMasterSpecs.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_TYPE)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpMasterSpecs.put(ConstantsUtil.SPECIFICATIONSUBTYPE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_ASSEMBLY)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_ASSEMBLY) : ConstantsUtil.EMPTY_STRING);
		mpMasterSpecs.put(ConstantsUtil.STATE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_STATE)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_STATE) : ConstantsUtil.EMPTY_STRING);
		//mpMasterSpecs = util.filterMapList(mpMasterSpecs);


		//Related ATS
		mpRelatedATS.put(ConstantsUtil.ATS_NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_NAME)))?(String)resultMaps.get(ConstantsUtil.ATL_NAME) : ConstantsUtil.EMPTY_STRING);
		mpRelatedATS.put(ConstantsUtil.ATS_TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TYPE)))?(String)resultMaps.get(ConstantsUtil.ATL_TYPE) : ConstantsUtil.EMPTY_STRING);
		mpRelatedATS.put(ConstantsUtil.ATS_TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TITLE)))?(String)resultMaps.get(ConstantsUtil.ATL_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpRelatedATS.put(ConstantsUtil.ATS_STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_STATE)))?(String)resultMaps.get(ConstantsUtil.ATL_STATE) : ConstantsUtil.EMPTY_STRING);


		//MEP
		mpMEPResult.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTYPE) : ConstantsUtil.EMPTY_STRING);
		mpMEPResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMNAME) : ConstantsUtil.EMPTY_STRING);
		mpMEPResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMREVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMREVISION) : ConstantsUtil.EMPTY_STRING);
		mpMEPResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMCURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMCURRENT) : ConstantsUtil.EMPTY_STRING);
		mpMEPResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpMEPResult.put(ConstantsUtil.MANUFACTURER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME)  : ConstantsUtil.EMPTY_STRING);
		//mpMEPResult = util.filterMapList(mpMEPResult);


		//SEP
		mpSEPResult.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPTYPE) : ConstantsUtil.EMPTY_STRING);
		mpSEPResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPNAME) : ConstantsUtil.EMPTY_STRING);
		mpSEPResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPREVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPREVISION) : ConstantsUtil.EMPTY_STRING));
		mpSEPResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPCURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPCURRENT) : ConstantsUtil.EMPTY_STRING);
		mpSEPResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpSEPResult.put(ConstantsUtil.SUPPLIER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SUPNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SUPNAME) : ConstantsUtil.EMPTY_STRING);
		//mpSEPResult = util.filterMapList(mpSEPResult);


		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.MATERIALS, mpMaterialResult);
		hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
		hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
		hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
		hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mapWeightCharResult);
		hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
		hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO,mpDerivedToResult);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
		hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
		hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
		hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
		hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
		hmAttrib.put(ConstantsUtil.MANUFACTUREREQUIVALENTS, mpMEPResult); 
		hmAttrib.put(ConstantsUtil.SUPPLIEREQUIVALENTS, mpSEPResult);
		hmAttrib.put(ConstantsUtil.MASTERATTRIBUTES, mpMasterAttribute);
		hmAttrib.put(ConstantsUtil.COUNTRIESOFSALE, mapCosResult);
		hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);

		sp.stop();
		System.out.println("FAB MESSAGE ELAPSED TIME::" + sp.getTime());
		System.out.println("RESULT:: \n" + mpMasterSpecs);
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End
	}
}