package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaCOPService {

	public HashMap<String, Map<String, String>> getCOPdata(String objId, String comp,  Environment env) throws Exception; 
}
