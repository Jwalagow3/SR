package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaDSService {
	public HashMap<String, Map<String, String>> getDSData (Environment env, String sKey, String sObjId) throws Exception;
}
