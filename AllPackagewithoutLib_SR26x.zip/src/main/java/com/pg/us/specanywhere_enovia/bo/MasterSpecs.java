package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.Pattern;
import matrix.util.StringList;

public class MasterSpecs {

	private static Logger LOGGER = Logger.getLogger(FinishedProductPartBO.class);
	
	public MapList getMasterSpecifications(Context context, String strObjectOid, String relType ) throws Exception {
		/*String  partId = getParam(args, "objectId");
		String  strMode = getParam(args, "Mode");*/
		String  partId = strObjectOid;
		String  strMode = relType;
		MapList parentPartFamilyMasterSpecs = new MapList();
		MapList masterPartSpecs = new MapList();
		boolean isContextPushed = false;
		String strInheritanceType = "";
		MapList parentPartFamilyMasterSpecsLocal = new MapList();
		try{
		if(UIUtil.isNotNullAndNotEmpty(partId))
		{
			DomainObject partObject = DomainObject.newInstance(context, partId);
			String strReferenceType = (String)partObject.getInfo(context, "attribute[" + ConstantsUtil.ATTR_REFERENCE_TYPE + "]");
			String partType=partObject.getInfo(context,ConstantsUtil.SELECT_TYPE);
			if(UIUtil.isNotNullAndNotEmpty(strReferenceType) && !partType.equals(ConstantsUtil.TYPE_FINISHEDPRODUCTPART))
			{
				/*if("PDF".equals(strMode)) {
					parentPartFamilyMasterSpecs = getParentPartFamilySpecificationsForPDF(context, partObject,strMode );
					masterPartSpecs = getMasterPartSpecificationsForPDF(context, partObject);
				}
				else {*/
					if(strReferenceType.equals(ConstantsUtil.SYMB_M))
					{						
					parentPartFamilyMasterSpecs = getParentPartFamilySpecifications(context, partObject);
					} 
					else
					{
					masterPartSpecs = getMasterPartSpecifications(context, partObject);
					}
					
				//}
				parentPartFamilyMasterSpecs.addAll(masterPartSpecs);
				removeValueFromMapList(parentPartFamilyMasterSpecs, ConstantsUtil.SELECT_LEVEL);
				
			}
			else
			{
				if(partType.equals(ConstantsUtil.TYPE_FINISHEDPRODUCTPART))
				{
					ContextUtil.pushContext(context);
					isContextPushed = true;
					parentPartFamilyMasterSpecs=getEBOMSpecifications(context,"",partObject);
				}
			}
		}
		} catch (Exception e) {
			LOGGER.error("EXCEPTION IN MASTERSPECS: getMasterSpecifications "+e);
		}
		 finally {
			if(isContextPushed)
			{
			  ContextUtil.popContext(context);
			}
		}
		return parentPartFamilyMasterSpecs;
	}
	
	private void removeValueFromMapList(MapList inputList, String keyToRemove) {
		for (Object inputObject : inputList) {
			((Map)inputObject).remove((Object)keyToRemove);
		}
	}
	
	private MapList getMasterPartSpecifications(Context context, DomainObject partObject) throws Exception{
		MapList masterSpecList = new MapList();
		try{
			List<String> classifiedItemIds = partObject.getInfoList(context, "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM+"].id");
			String strRevision = ConstantsUtil.EMPTY_STRING;
			for(String classifiedItem:classifiedItemIds) {
				if(UIUtil.isNotNullAndNotEmpty(classifiedItem))
				{
					DomainRelationship cIRelObj = DomainRelationship.newInstance(context, classifiedItem);
					String idSelectable = getPartMasterSelectable(ConstantsUtil.SELECT_ID);
					//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- START
					String typeSelectable = getPartMasterSelectable(ConstantsUtil.SELECT_TYPE);
					//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- END
					String nameSelectable = getPartMasterSelectable(ConstantsUtil.SELECT_NAME);
					String revisionSelectable = getPartMasterSelectable(ConstantsUtil.SELECT_REVISION);
					String titleSelectable = getPartMasterSelectable("attribute["+ ConstantsUtil.ATTRIBUTE_TITLE + "]");
					String specSelectable = getPartMasterSelectable("from[" +ConstantsUtil.RELATIONSHIP_PART_SPECIFICATION+ "].to.id");
					String specRelSelectable = getPartMasterSelectable("from[" +ConstantsUtil.RELATIONSHIP_PART_SPECIFICATION+ "].attribute["+ ConstantsUtil.ATTR_PG_INHERITANCE_TYPE + "]");
					String masterCurrent = getPartMasterSelectable(ConstantsUtil.SELECT_CURRENT);
					//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- START
					StringList selects = createSelects(typeSelectable,idSelectable,nameSelectable,revisionSelectable, titleSelectable,specSelectable,specRelSelectable, masterCurrent);
					//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- END
					BusObjectAttribUtil util = new BusObjectAttribUtil();
					
					
					
					Map masterSpecMap = cIRelObj.getRelationshipData(context, selects);
					if (((StringList)masterSpecMap.get(nameSelectable)).size() > 0) {
						String type = (String)((StringList)masterSpecMap.get(typeSelectable)).get(0);
						String name = (String)((StringList)masterSpecMap.get(nameSelectable)).get(0);
						strRevision = (String)((StringList)masterSpecMap.get(revisionSelectable)).get(0);
						//name = name+ConstantsUtil.EMPTY_SPACE+strRevision;
						String id = (String)((StringList)masterSpecMap.get(idSelectable)).get(0);
						String title = (String)((StringList)masterSpecMap.get(titleSelectable)).get(0);
						String strMasterCurrent = (String)((StringList)masterSpecMap.get("frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to."+ConstantsUtil.SELECT_CURRENT)).get(0);
						if(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strMasterCurrent)
								|| ConstantsUtil.STATE_COMPLETE.equalsIgnoreCase(strMasterCurrent))
						{
							
							Map masterSpecificationMap = new HashMap();
							
							//String masterPartLink = UTILS.getLink(name, id);
							/*StringList specIds = (StringList)masterSpecMap.get(specSelectable);
							StringList specRelAttributes = (StringList)masterSpecMap.get(specRelSelectable);
							for (int i=0;i< specIds.size() ; i++) {
								Map masterSpecificationMap = new HashMap();
								masterSpecificationMap.put(ConstantsUtil.SELECT_ID, specIds.get(i));
								
								//util.verifyOwnership(context, masterSpecificationMap);
								
								//masterSpecificationMap.put(ConstantsUtil.SELECT_ID, specIds.get(i));
								//masterSpecificationMap.put("derivedPath", masterPartLink);
								masterSpecificationMap.put("strInheritanceType", specRelAttributes.get(i));
								masterSpecificationMap.put(ConstantsUtil.SELECT_ID, id);
								masterSpecificationMap.put("strMasterName", name);
								masterSpecificationMap.put("strMasterTitle", title);
								masterSpecList.add(masterSpecificationMap);
							}*/
							masterSpecificationMap.put(ConstantsUtil.SELECT_ID, id);
							//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- START
							masterSpecificationMap.put("strMasterType", type);
							masterSpecificationMap.put("strMasterName", name);
							masterSpecList.add(masterSpecificationMap);
							//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- END
							
						}
					}
				}
			}
		}catch(Exception ex){
			LOGGER.error("EXCEPTION IN MASTERSPECS: getMasterSpecifications "+ex);
		}
		return masterSpecList;
	}
	
	private MapList getEBOMSpecifications(Context context,String strMode,DomainObject partObject) throws Exception 
    {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
    	MapList specList=new MapList();
    	String ebomPartId=null;
    	String ebomPartName=null;
    	String relFromType=null;
    	String relToType=null;
    	String relFromId=null;
    	String[] newArguments=null;
    	String ebomPartTitle=null;
    	StringList strlObjectSelectable = new StringList(4);
    	String ebomPartRevision=null;
    	strlObjectSelectable.add(ConstantsUtil.SELECT_ID);
    	strlObjectSelectable.add(ConstantsUtil.SELECT_TYPE);
    	strlObjectSelectable.add(ConstantsUtil.SELECT_NAME);
    	strlObjectSelectable.add(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_TITLE));
    	strlObjectSelectable.add(ConstantsUtil.SELECT_REVISION);
    	StringList strlRelSelectable = new StringList(3);
    	strlRelSelectable.add(DomainRelationship.SELECT_FROM_TYPE);
    	strlRelSelectable.add(DomainRelationship.SELECT_TO_TYPE);
    	strlRelSelectable.add(DomainRelationship.SELECT_FROM_ID);
    	//Map paramMap = (Map) JPO.unpackArgs(args);
    	//String strMode = (String)paramMap.get("Mode");
    	
    	Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PG_CUSTOMERUNIT);
    	typePattern.addPattern(ConstantsUtil.TYPE_PGINNERPACKUNITPART);
    	typePattern.addPattern(ConstantsUtil.TYPE_PGCONSUMERUNITPART);
    	typePattern.addPattern(ConstantsUtil.TYPE_FINISHEDPRODUCTPART);
    	
    	MapList ebomPartList=partObject.getRelatedObjects(context,
    			DomainObject.RELATIONSHIP_EBOM,
				typePattern.getPattern(),
    			strlObjectSelectable,//Object Select
    			strlRelSelectable, //rel Select
    			false,//get To
    			true,//get From
    			(short)0,//recurse level
    			"",//where Clause
    			null,//relationshipWhere Clause
    			(short)0);
    	Iterator ebomItr=ebomPartList.iterator();
    	while(ebomItr.hasNext())
    	{
    		Map specMap=null;
    		Map partMap=(Map)ebomItr.next();
    		MapList tempList=new MapList();
    		ebomPartId=(String)partMap.get(ConstantsUtil.SELECT_ID);
    		ebomPartName=(String)partMap.get(ConstantsUtil.SELECT_NAME);
    		ebomPartTitle=(String)partMap.get(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_TITLE));
    		ebomPartRevision = (String)partMap.get(ConstantsUtil.SELECT_REVISION);
    		
    		relFromType=(String)partMap.get(DomainRelationship.SELECT_FROM_TYPE);
    		relToType=(String)partMap.get(DomainRelationship.SELECT_TO_TYPE);      
    		relFromId=(String)partMap.get(DomainRelationship.SELECT_FROM_ID);
    		if(relFromType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART) && (relToType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART) || relToType.equals(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)))
    		{
    			break;
    		}
    		if(relFromType.equals(ConstantsUtil.TYPE_PG_CUSTOMERUNIT) && relToType.equals(ConstantsUtil.TYPE_FINISHEDPRODUCTPART))
    		{
    			break;
    		}
    	
    		/*paramMap.put(ConstantsUtil.STRING_OBJECTID,ebomPartId);
    		paramMap.put("parentRelName","relationship_PartSpecification");*/
    		//newArguments = JPO.packArgs(paramMap);
    		tempList=(MapList)(util.getDocuments(context,ebomPartId,"relationship_PartSpecification"));
    		if(null!=tempList) {
    			Iterator tempListItr=tempList.iterator();
        		while(tempListItr.hasNext())
        		{
        				specMap=(Map)tempListItr.next();
        			if(UIUtil.isNotNullAndNotEmpty(strMode) && "PDF".equals(strMode)) {
        				specMap.put("derivedPath",ebomPartName+ConstantsUtil.EMPTY_SPACE+ebomPartRevision);
        			}
        			else {
        				specMap.put("derivedPath", ebomPartName+ConstantsUtil.EMPTY_SPACE+ebomPartRevision);
        				specMap.put("derivedPathId", ebomPartId);
        				specMap.put("strRowType",(String)partMap.get(ConstantsUtil.SELECT_TYPE));
        				specMap.put("strRowTitle",ebomPartTitle);
        			}
        			specList.add(specMap); 
        		}
    		}
    		
    		removeValueFromMapList(specList, ConstantsUtil.SELECT_LEVEL);
    		specList.addAll(getMasterSpecifications(context,ebomPartId,"relationship_PartSpecification"));
    	}
    	/*if(null!=specList && !specList.isEmpty())
    	{
    		specList=util.sortSpecifications(context,specList);
    	}*/
    	return specList;
    }
	
	private MapList getParentPartFamilySpecificationsForPDF(Context context, DomainObject partObject, String strMode) throws Exception {
		MapList parentPFMasterSpec = new MapList();
		
		StringList pfIds = getPartFamilyIds(context, partObject);
		
		for (Object pfID : pfIds) {
			String immdPartFamilyId = (String)pfID;
			MapList allParentPartFamilies = getAllParentPartFamiliesForPDF(context, immdPartFamilyId, partObject, strMode);
			parentPFMasterSpec.addAll(getSpecsFromPartFamiliesForPDF(context, allParentPartFamilies));
		}
		return parentPFMasterSpec;
	}
	
	
	private MapList getAllParentPartFamiliesForPDF(Context context, String partFamilyId, DomainObject partObject, String strMode) throws Exception {
		MapList allPartFamilies = new MapList();
		
		String referenceTypeAttribute = ConstantsUtil.ATTRIBUTE_REFERENCETYPE;
			allPartFamilies = getAllParentPartFamiliesForPDF(context, partFamilyId, "", strMode);
			for (Object parentPartFamily : allPartFamilies) {
				String path = (String)((Map)parentPartFamily).remove("path");
				((Map)parentPartFamily).put("derivedPath", path);
			}
		return allPartFamilies;
	}
	
	public MapList getAllParentPartFamiliesForPDF(Context context, String partFamilyId, String path, String strMode) throws Exception{
		StringList objectSelects = createSelects(ConstantsUtil.SELECT_NAME, ConstantsUtil.SELECT_ID);
		DomainObject doPartFamily = DomainObject.newInstance(context,partFamilyId);
		String inputPFName = doPartFamily.getInfo(context, ConstantsUtil.SELECT_NAME);
		String partFamilyType = ConstantsUtil.TYPE_PARTFAMILY;
		String subClassRel = ConstantsUtil.RELATIONSHIP_SUBCLASS;
		String localPath = "";
		if (UIUtil.isNullOrEmpty(path)) {
			localPath = inputPFName;
		}
		else
		{
			localPath = path;
		}
		MapList partFamilyList = doPartFamily.getRelatedObjects(context,
					 subClassRel,
					 partFamilyType,
					 objectSelects,
					 null,
					 true,
					 false,
					 (short)1,
					 null,
					 null,
					 0);
		
		MapList tempList = new MapList();
		Iterator pfIterator = partFamilyList.iterator();
		while(pfIterator.hasNext()) {
			Map pfMap = (Map)pfIterator.next();
			String pfId = (String)pfMap.get(ConstantsUtil.SELECT_ID);
			String pfName = (String)pfMap.get(ConstantsUtil.SELECT_NAME);
			localPath += "->" + pfName;
			pfMap.put("path", localPath);
			tempList.addAll(getAllParentPartFamiliesForPDF(context, pfId, localPath, strMode));
		}
		partFamilyList.addAll(tempList);
		return partFamilyList;
	}
	
	private StringList getPartFamilyIds(Context context, DomainObject partObject) throws FrameworkException {
		String selectable = "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM+"].from.id";
		StringList pfIds =  new StringList();
		try
		{
			pfIds = partObject.getInfoList(context, selectable);
			pfIds = filterRestrictedControlClass(context, pfIds);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			LOGGER.error("EXCEPTION IN MASTERSPECS: getPartFamilyIds "+e);
		}		
		return pfIds;
	}
	
	public StringList filterRestrictedControlClass(Context context, StringList slIdList)throws FrameworkException{
		StringList slFilteredIdList = new StringList();
		String strObjectType = ConstantsUtil.EMPTY_STRING;
		StringList slIPControlClassType = FrameworkUtil.split(ConstantsUtil.SECURITYCLASS_LIST, ",");
		StringList slSelectList = new StringList(ConstantsUtil.SELECT_TYPE);
		slSelectList.addElement(ConstantsUtil.SELECT_ID);
		Map mpObjectInfo = new HashMap();
		if(slIdList != null && !slIdList.isEmpty())
		{
			try {
				MapList mlObjectInfoList = DomainObject.getInfo(context, (String [])slIdList.toArray(new String[slIdList.size()]), slSelectList);
				if(mlObjectInfoList != null && !mlObjectInfoList.isEmpty())
				{
					for(Object objInfo : mlObjectInfoList)
					{
						mpObjectInfo = (Map)objInfo;
						strObjectType = mpObjectInfo.get(ConstantsUtil.SELECT_TYPE).toString();
						if(slIPControlClassType != null && !slIPControlClassType.isEmpty() && !slIPControlClassType.contains(FrameworkUtil.getAliasForAdmin(context, "type",strObjectType, false)))
						{
							slFilteredIdList.addElement(mpObjectInfo.get(ConstantsUtil.SELECT_ID).toString());
						}
					}
				}
			} catch (FrameworkException ex) {
				ex.printStackTrace();
				LOGGER.error("EXCEPTION IN MASTERSPECS: filterRestrictedControlClass "+ex);
			}
		}
		return slFilteredIdList;
	}
	
	private MapList getMasterPartSpecificationsForPDF(Context context, DomainObject partObject) throws Exception{
		MapList masterSpecList = new MapList();
		try{
		List<String> classifiedItemIds = partObject.getInfoList(context, "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM+"].id");
			for(String classifiedItem:classifiedItemIds) {
				if(UIUtil.isNotNullAndNotEmpty(classifiedItem))
				{
					DomainRelationship cIRelObj = DomainRelationship.newInstance(context, classifiedItem);
					String idSelectable = getPartMasterSelectable(ConstantsUtil.SELECT_ID);
					String nameSelectable = getPartMasterSelectable(ConstantsUtil.SELECT_NAME);
					String specSelectable = getPartMasterSelectable("from[" +DomainRelationship.RELATIONSHIP_PART_SPECIFICATION+ "].to.id");
					String masterCurrent = getPartMasterSelectable(ConstantsUtil.SELECT_CURRENT);
					StringList selects = createSelects(idSelectable,nameSelectable, specSelectable, masterCurrent);
					Map masterSpecMap = cIRelObj.getRelationshipData(context, selects);
					if (((StringList)masterSpecMap.get(nameSelectable)).size() > 0) {
						String name = (String)((StringList)masterSpecMap.get(nameSelectable)).get(0);
						String id = (String)((StringList)masterSpecMap.get(idSelectable)).get(0);
						String strMasterCurrent = (String)((StringList)masterSpecMap.get("frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to."+ConstantsUtil.SELECT_CURRENT)).get(0);
						if(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strMasterCurrent)
								|| ConstantsUtil.STATE_COMPLETE.equalsIgnoreCase(strMasterCurrent)){
							String masterPartLink = name;
							StringList specIds = (StringList)masterSpecMap.get(specSelectable);
							for (Object specId : specIds) {
								Map masterSpecificationMap = new HashMap();
								masterSpecificationMap.put(ConstantsUtil.SELECT_ID, specId);
								masterSpecificationMap.put("derivedPath", masterPartLink);
								masterSpecList.add(masterSpecificationMap);
							}
						}
					}
				}
			}
		}catch(Exception ex){
			LOGGER.error("EXCEPTION IN MASTERSPECS: getMasterPartSpecificationsForPDF "+ex);
		}
		return masterSpecList;
	}
	
	private String getPartMasterSelectable(String suffix) {
		StringBuffer selectable = new StringBuffer();
		selectable.append("frommid[").append(ConstantsUtil.RELATIONSHIP_PART_FAMILY_REFERENCE).append("].torel.to.").append(suffix);
		return selectable.toString();
	}
	
	public StringList createSelects(String... selects)
	{
		StringList selectList = new StringList();
		for(String select : selects)
		{
			selectList.add(select);
		}
		return selectList;
	}
	
	private MapList getParentPartFamilySpecifications(Context context, DomainObject partObject) throws Exception {
		MapList parentPFMasterSpec = new MapList();
		
		StringList pfIds = getPartFamilyIds(context, partObject);
		
		for (Object pfID : pfIds) {
			String immdPartFamilyId = (String)pfID;
			MapList allParentPartFamilies = getAllParentPartFamilies(context, immdPartFamilyId, partObject);
			parentPFMasterSpec.addAll(getSpecificsFromPartFamilies(context, allParentPartFamilies,partObject));
		}
		return parentPFMasterSpec;
	}
	
	private MapList getAllParentPartFamilies(Context context, String partFamilyId, DomainObject partObject) throws Exception {
		MapList allPartFamilies = new MapList();
		String referenceTypeAttribute = PropertyUtil.getSchemaProperty(context,"attribute_ReferenceType");
		String referenceTypeValue = partObject.getInfo(context, "attribute["+referenceTypeAttribute+"]");
		//if (isParentPartFamilySpecRetrievalEnabled(context)) {
			allPartFamilies = getAllParentPartFamilies(context, partFamilyId, "");
			for (Object parentPartFamily : allPartFamilies) {
				String path = (String)((Map)parentPartFamily).remove("path");
				((Map)parentPartFamily).put("derivedPath", path);
			}
		//}
		return allPartFamilies;
	}
	
	public MapList getAllParentPartFamilies(Context context, String partFamilyId, String path) throws Exception{
		StringList objectSelects = createSelects(ConstantsUtil.SELECT_NAME, ConstantsUtil.SELECT_ID);
		MapList partFamilyList = new MapList();
		if(UIUtil.isNotNullAndNotEmpty(partFamilyId))
		{
			DomainObject doPartFamily = DomainObject.newInstance(context,partFamilyId);
			String inputPFName = doPartFamily.getInfo(context, ConstantsUtil.SELECT_NAME);
			String localPath  = path;

			partFamilyList = doPartFamily.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_SUBCLASS,
					ConstantsUtil.TYPE_PART_FAMILY,
					objectSelects,
					null,
					true,
					false,
					(short)1,
					null,
					null,
					0);

			MapList tempList = new MapList();
			Iterator pfIterator = partFamilyList.iterator();
			while(pfIterator.hasNext())
			{
				Map pfMap = (Map)pfIterator.next();
				String pfId = (String)pfMap.get(ConstantsUtil.SELECT_ID);
				String pfName = (String)pfMap.get(ConstantsUtil.SELECT_NAME);
				localPath += ConstantsUtil.SYMBL_ARROW + pfName;
				pfMap.put("path", localPath);
				tempList.addAll(getAllParentPartFamilies(context, pfId, localPath));
			}

			partFamilyList.addAll(tempList);
		}
		return partFamilyList;
	}
	
	/**
	 * gets all the specifications connected to the part family through Master Parts.
	 * cloned getSpecsFromPartFamilies to add  one more argument to the method
	 * @param allPartFamilies
	 * @return MapList
	 * @throws FrameworkException
	 */
	private MapList getSpecificsFromPartFamilies(Context context, MapList allPartFamilies , DomainObject partObject) throws FrameworkException {
		MapList parentPFMasterSpec = new MapList();
		String specTypes = getSpecTypes(context);
		Map masterPartMap = new HashMap();
		Map strContextMasterPartMap = new HashMap();
		String partFamilyId = "";
		String partFamilyPath = "";
		String strCurrent = "";
		String sMasterReleasePhase = "";
		String sClassifiedItemReleasePhase = "";
		String classifiedItemPolicy = "";
		String classifiedItemType = "";
		String strContextMasterPartPolicy = "";
		String strContextMasterPartType = "";
		String masterPartPath = "";
		List<String> masterParts = new StringList();
		StringList partSpecSelectable = new StringList();
		StringList selStmt = new StringList();
		selStmt.add(ConstantsUtil.SELECT_CURRENT);
		selStmt.add(ConstantsUtil.SELECT_POLICY);
		selStmt.add(ConstantsUtil.SELECT_TYPE);
		DomainObject masterPartObject = null;
		MapList specIds = new MapList();
		for (Object partFamily: allPartFamilies) {
			partFamilyId = (String)((Map)partFamily).get(ConstantsUtil.SELECT_ID);
			masterParts = getMasterParts(context, partFamilyId);
			partFamilyPath = (String)((Map)partFamily).get("derivedPath");
			for (String masterPartId : masterParts) {
				partSpecSelectable = createSelects(ConstantsUtil.SELECT_ID);
				 masterPartObject = DomainObject.newInstance(context, masterPartId);
				selStmt = new StringList();
				selStmt.add(ConstantsUtil.SELECT_CURRENT);
				selStmt.add(ConstantsUtil.SELECT_POLICY);
				selStmt.add(ConstantsUtil.SELECT_TYPE);
				
				selStmt.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				masterPartMap = masterPartObject.getInfo(context,selStmt);
				strCurrent = (String)masterPartMap.get(ConstantsUtil.SELECT_CURRENT);
				
				classifiedItemPolicy = (String)masterPartMap.get(ConstantsUtil.SELECT_POLICY);
				classifiedItemType = (String)masterPartMap.get(ConstantsUtil.SELECT_TYPE);
				
				
				strContextMasterPartMap = (Map)partObject.getInfo(context, selStmt);
				strContextMasterPartPolicy = (String)strContextMasterPartMap.get(ConstantsUtil.SELECT_POLICY);
				strContextMasterPartType = (String)strContextMasterPartMap.get(ConstantsUtil.SELECT_TYPE);
				 sMasterReleasePhase = (String)strContextMasterPartMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				 sClassifiedItemReleasePhase = (String)masterPartMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				
				if(!strContextMasterPartType.equals(classifiedItemType))
				{
					continue;
				}
				
				if(ConstantsUtil.POLICY_EC_PART.equals(strContextMasterPartPolicy) && ConstantsUtil.PRODUCTION.equals(sMasterReleasePhase) && !(ConstantsUtil.POLICY_EC_PART.equals(classifiedItemPolicy) && ConstantsUtil.PRODUCTION.equals(sClassifiedItemReleasePhase)))
				{
					continue;
				}
				
				if(ConstantsUtil.POLICY_EC_PART.equals(strContextMasterPartPolicy) && ConstantsUtil.PILOT.equals(sMasterReleasePhase) && ConstantsUtil.POLICY_EC_PART.equals(classifiedItemPolicy) && ConstantsUtil.EXPERIMENTAL.equals(sClassifiedItemReleasePhase))
				{
					continue;
				}
				if(UIUtil.isNotNullAndNotEmpty(strCurrent) && (ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strCurrent) || ConstantsUtil.STATE_COMPLETE.equalsIgnoreCase(strCurrent)))
				{
					specIds = masterPartObject.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_PART_SPECIFICATION,specTypes,partSpecSelectable, null,
							false, true, (short)1, null, null, 0);
					masterPartPath = getMasterPartPath(context, partFamilyPath,masterPartObject);
					for (Object spec : specIds) {
						((Map)spec).put("derivedPath", masterPartPath);
					}
					parentPFMasterSpec.addAll(specIds);
				}
				partSpecSelectable.clear();
			}
			masterParts.clear();
		}
		return parentPFMasterSpec;
	}
	
	private String getMasterPartPath(Context context, String partFamilyPath, DomainObject masterPartObject) throws FrameworkException {
		String masterPartId = masterPartObject.getInfo(context, ConstantsUtil.SELECT_ID);
		String masterPartName = masterPartObject.getInfo(context, ConstantsUtil.SELECT_NAME);
		String parentPath = partFamilyPath == null ? "" : partFamilyPath + ConstantsUtil.SYMBL_ARROW;
		//String masterPartPath = parentPath + UTILS.getLink(masterPartName, masterPartId);
		return parentPath;
	}
	
	private StringList getMasterParts(Context context, String partFamilyId) throws FrameworkException {
		DomainObject partFamilyObject = DomainObject.newInstance(context, partFamilyId);
		String classifiedItemRel = PropertyUtil.getSchemaProperty(context,"relationship_ClassifiedItem");
		// Modified for removing type_ProductData references START
		String strpgSignupFormType = PropertyUtil.getSchemaProperty(context,"type_pgSignupForm");
		String strPartType = PropertyUtil.getSchemaProperty(context,"type_Part");
		String strTechnicalSpecificationType = PropertyUtil.getSchemaProperty(context,"type_TechnicalSpecification");
		String productDataType = strpgSignupFormType +","+ strPartType +","+ strTechnicalSpecificationType;
		// Modified for removing type_ProductData references END
		String referenceTypeAttribute = PropertyUtil.getSchemaProperty(context,"attribute_ReferenceType");
		StringList objectSelects = createSelects(ConstantsUtil.SELECT_ID);
		MapList classifiedItems = partFamilyObject.getRelatedObjects(context,
			classifiedItemRel,productDataType,objectSelects, null,
			false, true, (short)1, "attribute["+referenceTypeAttribute+"] == 'M'", null, (short)0);
		StringList masterPartIds = getIDStringListFromMapList(classifiedItems);
		return masterPartIds;
	}
	
	 public StringList getIDStringListFromMapList(MapList inputMapList)
	    {
	    	StringList idList = new StringList();
	    	for (Object inputObject : inputMapList)
	    	{
	    		String inputObjectId = (String)((Map)inputObject).get(ConstantsUtil.SELECT_ID);
	    		idList.add(inputObjectId);
	    	}
	    	return idList;
	    }
	 
	 private String getSpecTypes(Context context) throws FrameworkException {
		 	String specSymbolicTypes = "type_DOCUMENTS,type_TechnicalSpecification,type_VPMReference";
			List<String> specSymTypesList = StringUtil.split(specSymbolicTypes, ",");
			String specTypes = "";
			for (String specSymType : specSymTypesList) {
				if (UIUtil.isNotNullAndNotEmpty(specTypes)) {
					specTypes += ",";
				} 
				specTypes += PropertyUtil.getSchemaProperty(context, specSymType);
			}
			return specTypes;
		}
	 
	 private MapList getSpecsFromPartFamiliesForPDF(Context context, MapList allPartFamilies) throws FrameworkException {
			MapList parentPFMasterSpec = new MapList();
			String specTypes = getSpecTypes(context);
			MapList specIds = new MapList();
			for (Object partFamily: allPartFamilies) {
				String partFamilyId = (String)((Map)partFamily).get(ConstantsUtil.SELECT_ID);
				List<String> masterParts = getMasterParts(context, partFamilyId);
				String partFamilyPath = (String)((Map)partFamily).get("derivedPath");
				for (String masterPartId : masterParts) {
					StringList partSpecSelectable = createSelects(ConstantsUtil.SELECT_ID);
					if(UIUtil.isNotNullAndNotEmpty(masterPartId))
					{
						DomainObject masterPartObject = DomainObject.newInstance(context, masterPartId);
						String strCurrent = (String)masterPartObject.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					if (UIUtil.isNotNullAndNotEmpty(strCurrent)
							&& (ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strCurrent)
									|| ConstantsUtil.STATE_COMPLETE.equalsIgnoreCase(strCurrent)))						{
							specIds = masterPartObject.getRelatedObjects(context,
									ConstantsUtil.RELATIONSHIP_PART_SPECIFICATION,specTypes,partSpecSelectable, null,
								false, true, (short)1, null, null, 0);
						String masterPartPath = getMasterPartPathForPDF(context, partFamilyPath,masterPartObject);
						for (Object spec : specIds) {
							((Map)spec).put("derivedPath", masterPartPath);
						}
						parentPFMasterSpec.addAll(specIds);
						}
					}
				}
			}
			return parentPFMasterSpec;
		}
	 
	private String getMasterPartPathForPDF(Context context, String partFamilyPath, DomainObject masterPartObject)
			throws FrameworkException {
		String masterPartId = masterPartObject.getInfo(context, ConstantsUtil.SELECT_ID);
		String masterPartName = masterPartObject.getInfo(context, ConstantsUtil.SELECT_NAME);
		String parentPath = partFamilyPath == null ? "" : partFamilyPath + "-";
		String masterPartPath = parentPath + masterPartName;
		return masterPartPath;
	}

	public String getParam(String[] args, String paramName) throws Exception
	{
		Map paramMap = (Map) JPO.unpackArgs(args);
		String paramValue = "";
		if (paramMap.get(paramName) != null)
		{
			Object value = paramMap.get(paramName);
			if(value instanceof String[])
			{
				paramValue = ((String[]) paramMap.get(paramName))[0];
			}
			else if (value instanceof String)
			{
				paramValue = (String) paramMap.get(paramName);
			}
		}
		else
		{
			Map requestMap = (Map)paramMap.get("requestMap");
			if(requestMap!=null)
				paramValue = (String) requestMap.get(paramName);
		}
		return paramValue;
	}
}
