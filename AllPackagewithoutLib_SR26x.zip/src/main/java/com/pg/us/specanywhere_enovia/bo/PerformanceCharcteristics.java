package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;

import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.Pattern;
import matrix.util.StringList;

public class PerformanceCharcteristics  {

	private static Logger LOGGER = Logger.getLogger(PerformanceCharcteristics.class);

	BusObjectAttribUtil util = new BusObjectAttribUtil();

	public MapList getPerformanceChar(matrix.db.Context context, String[] args) throws Exception {

		MapList objList = new MapList();
		try {
			if (args.length == 0) {
				throw new IllegalArgumentException();
			}
			String strCharInheritanceType = "";
			String partType = null;
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_ID);
			objectSelects.add(DomainConstants.SELECT_CURRENT);
			objectSelects.add(DomainObject.SELECT_NAME);
			objectSelects.add(DomainObject.SELECT_TYPE);
			objectSelects.add(DomainObject.SELECT_POLICY);
			objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
			objectSelects.add(ConstantsUtil.ATTR_REFERENCE_TYPE);

			StringList relSelects = new StringList();
			relSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
			relSelects.add(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_INHERITED_FROM_PLATFORM);
			//START :: gaikwad.tg
			relSelects.add("id[connection]");
			relSelects.add("from.name");
			relSelects.add("to.name");
			relSelects.add("relationship");
			//END :: gaikwad.tg
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String objectId = (String) paramMap.get(ConstantsUtil.OBJECT_ID);
			String addNewRow = (String) paramMap.get(ConstantsUtil.ADDROW);
			String strSwitchMode = (String) paramMap.get(ConstantsUtil.SWITCHMODE);
			
			//START :: gaikwad.tg
			String relPattern = ConstantsUtil.RELATIONSHIP_EXTENDEDDATA + "," + ConstantsUtil.RELATIONSHIP_SHARED_TABLE + "," + ConstantsUtil.RELATIONSHIP_SHAREDCHARACTERISTIC+ "," + "Extended Data";

			String typePattern = ConstantsUtil.TYPE_SHARED_TABLE + "," + ConstantsUtil.TYPE__PERFORMANCE_CHAR;
			
			//END :: gaikwad.tg
			
			if (UIUtil.isNotNullAndNotEmpty(objectId)) {
				
				DomainObject doObj = DomainObject.newInstance(context, objectId);
				//START :: gaikwad.tg
				boolean isShared = Boolean.valueOf(doObj.getInfo(context, "relationship[" + ConstantsUtil.RELATIONSHIP_SHARED_TABLE + "]")).booleanValue();
				//END :: gaikwad.tg
				String strSelectedTable = (String) paramMap.get(ConstantsUtil.SELECTEDTABLE);
				strSelectedTable = strSelectedTable.substring(strSelectedTable.lastIndexOf(ConstantsUtil.SYMBL_CHARTILDA) + 1,
						strSelectedTable.length());
				boolean isContextPushed = false;
				ContextUtil.pushContext(context, PropertyUtil.getSchemaProperty(context, ConstantsUtil.PERSON_USER_AGENT),
						DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
				isContextPushed = true;
				StringList selStmt = new StringList();
				selStmt.add(ConstantsUtil.SELECT_ATTR_REFERENCE_TYPE);

				selStmt.add(ConstantsUtil.STR_CLASSI_REFERENCE_ID);
				selStmt.add(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT);
				selStmt.add(ConstantsUtil.SELECT_CURRENT);
				Map partInfoMap = doObj.getInfo(context, selStmt);
				MapList conextObjectList = new MapList();
				String strContextRefType = (String) partInfoMap.get(ConstantsUtil.SELECT_ATTR_REFERENCE_TYPE);
				String masterCurState = "";
				String strConnectedRefId = ConstantsUtil.EMPTY_STRING;
				if (partInfoMap
						.containsKey(ConstantsUtil.STR_CLASSI_REFERENCE_ID)) {
					strConnectedRefId = (String) partInfoMap
							.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID);
					
					masterCurState = (String) partInfoMap
							.get(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT);
					
				}

				final String derivedFilterSelection = (String) paramMap.get(ConstantsUtil.PGVPDPERMANCECHARFILTER);
				String rangeAll = ConstantsUtil.ALL;
				String rangeLocal = ConstantsUtil.STR_LOCAL;
				String rangeReferenced = ConstantsUtil.STR_REFERENCED;
				if (ConstantsUtil.STR_R.equals(strContextRefType) && UIUtil.isNotNullAndNotEmpty(strConnectedRefId)) {
					
					//START :: gaikwad.tg
					/*conextObjectList = doObj.getRelatedObjects(context, "Extended Data", "pgPerformanceCharacteristic,", objectSelects, relSelects,
							false, true, (short) 1, null, null, 0);*/
					
					if (isShared) {
						conextObjectList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
								false, true, (short) 2, null, null, 0);
					}
					 else {
						 conextObjectList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
									false, true, (short) 1, null, null, 0);
					}
					//END :: gaikwad.tg
					doObj.setId(strConnectedRefId);
				}


				if (ConstantsUtil.STR_R.equals(strContextRefType) && UIUtil.isNotNullAndNotEmpty(strConnectedRefId)
						&& !(ConstantsUtil.STATE_RELEASE.equals(masterCurState)
								|| ConstantsUtil.STATE_COMPLETE.equals(masterCurState))) {
					if (rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) {
						return new MapList();
					} else {
						return conextObjectList;
					}
				}

				if (rangeAll.equalsIgnoreCase(derivedFilterSelection)) {
					
					//START :: gaikwad.tg
					/*Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_CHARACTERISTIC);
					relPattern.addPattern(ConstantsUtil.RELATIONSHIP_SHARED_TABLE);
					
					Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC);
					typePattern.addPattern(ConstantsUtil.TYPE_SHARED_TABLE);


					objList = doObj.getRelatedObjects(context, relPattern.getPattern(), typePattern.getPattern(), objectSelects, relSelects,
							false, true, (short) 1, typeWhere.toString(), null, 0);*/
					
					StringBuffer typeWhere = new StringBuffer();
					typeWhere.append(ConstantsUtil.STR_NOTTYPE).append(ConstantsUtil.TYPE_PG_STABILITY_RESULTS);
					
					if (isShared) {
						objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
								false, true, (short) 2, null, null, 0);
					}
					 else {
						 objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
									false, true, (short) 1, null, null, 0);
					}
					//END :: gaikwad.tg

					MapList charObjList = new MapList();
					Iterator objListItr = objList.iterator();
					String strCharacteristicType = ConstantsUtil.EMPTY_STRING;

					while (objListItr.hasNext()) {
						Map ObjMap = (Map) objListItr.next();
						if (ObjMap != null && !ObjMap.isEmpty()) {
							strCharacteristicType = (String) ObjMap.get(DomainConstants.SELECT_TYPE);
							strCharInheritanceType = (String) ObjMap.get(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
							
								 if (rangeAll.equalsIgnoreCase(derivedFilterSelection)
										&& (ConstantsUtil.STR_R.equals(strContextRefType) && strCharInheritanceType.equals(ConstantsUtil.STR_LOCAL)
												&& !(ConstantsUtil.STATE_RELEASE.equals(masterCurState)
														|| ConstantsUtil.STATE_COMPLETE.equals(masterCurState)))) {
									charObjList.add(ObjMap);
								}
						}
					}
					
					if (!charObjList.isEmpty()
							&& !(ConstantsUtil.STR_R.equals(strContextRefType) && UIUtil.isNullOrEmpty(strConnectedRefId))) {
						objList.removeAll(charObjList);
					}
					
					Map mpTemp = new HashMap();
					MapList mlTemp = new MapList();
					for (int x = objList.size() - 1; x >= 0; x--) {
						mpTemp = (Map) objList.get(x);
						String strType = (String) mpTemp.get(DomainConstants.SELECT_TYPE);
						if (strType != null && strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)) {
							String strCharType = (String) mpTemp
									.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
							//START :: gaikwad.tg
							if (strCharType != null && strCharType.equals(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC)) {
								objList.remove(x);
							}
							//END :: gaikwad.tg
						}
					}
					objList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.CONST_INTERGER);
					if (addNewRow != null && addNewRow.equals(ConstantsUtil.TRUE)
							&& (strSwitchMode == null || ConstantsUtil.EMPTY_STRING.equals(strSwitchMode))) {
						HashMap m = new HashMap();
						m.put(ConstantsUtil.SELECT_ID, ConstantsUtil.BLANK);
						objList.add(m);
					}

					MapList mlTempList = new MapList();
					for (int iSeq = 0; iSeq < objList.size(); iSeq++) {
						Map mpTempList = (Map) objList.get(iSeq);
						mpTempList.put(ConstantsUtil.STR_SEQUENCE, Integer.toString(iSeq + 1));
						mlTempList.add(mpTempList);
					}
					objList.clear();
					objList.addAll(mlTempList);

				}

				String strReferenceType = (String) doObj.getInfo(context, ConstantsUtil.SELECT_ATTR_REFERENCE_TYPE);
				if (rangeAll.equalsIgnoreCase(derivedFilterSelection)
						|| rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) {

					if (UIUtil.isNotNullAndNotEmpty(strReferenceType)) {

						/*Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_CHARACTERISTIC);
						relPattern.addPattern(ConstantsUtil.RELATIONSHIP_SHARED_TABLE);
						
						Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC);
						typePattern.addPattern(ConstantsUtil.TYPE_SHARED_TABLE);
						
						MapList charList = doObj.getRelatedObjects(context, relPattern.getPattern(), typePattern.getPattern(), objectSelects,
								relSelects, false, true, (short) 1, null, null, 0);*/
						
						MapList charList = new MapList();
						if (isShared) {
							charList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
									false, true, (short) 2, null, null, 0);
						}
						 else {
							 charList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
										false, true, (short) 1, null, null, 0);
						}
						
						//END :: gaikwad.tg
						Iterator charListItrtr = charList.iterator();
						while (charListItrtr.hasNext()) {
							Map charMap = (Map) charListItrtr.next();
							if (charMap != null && !charMap.isEmpty()) {
								String strType = (String) charMap.get(DomainConstants.SELECT_TYPE);
								strCharInheritanceType = (String) charMap
										.get(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
								if (rangeAll.equalsIgnoreCase(derivedFilterSelection)) {
									if (UIUtil.isNotNullAndNotEmpty(strType)
											&& (strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)
													|| strType.equals(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC))) {
										String strCharType = (String) charMap.get(
												ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
										if (UIUtil.isNotNullAndNotEmpty(strCharType) && strCharType.equals(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC)
												&& ((ConstantsUtil.STR_M.equals(strContextRefType) || (ConstantsUtil.STR_R.equals(strContextRefType)
														&& (ConstantsUtil.STATE_RELEASE.equals(masterCurState)
																|| ConstantsUtil.STATE_COMPLETE
																		.equals(masterCurState)))))) {
											objList.add(charMap);

										}

									}
								} else if (rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) {
									if (UIUtil.isNotNullAndNotEmpty(strType)
											&& (strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)
													|| strType.equals(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC))) {
										String strCharType = (String) charMap.get(
												ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
										if ((UIUtil.isNotNullAndNotEmpty(strCharType) && strCharType.equals(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC))
												|| ConstantsUtil.STR_REFERENCED.equals(strCharInheritanceType)
												|| (ConstantsUtil.STR_R.equals(strContextRefType) && (ConstantsUtil.STATE_RELEASE
														.equals(masterCurState)
														|| ConstantsUtil.STATE_COMPLETE.equals(masterCurState))))
										{
											objList.add(charMap);

										}
									}
								}
							}
						}
					}
				}

				partType = doObj.getInfo(context, DomainConstants.SELECT_TYPE);
				if (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(partType) 
						&& (rangeAll.equalsIgnoreCase(derivedFilterSelection)
								|| rangeReferenced.equalsIgnoreCase(derivedFilterSelection))) {
					objList = getEbomPartsCharacterstics(context, paramMap, doObj, objList, derivedFilterSelection);
					return objList;
				}

				if (ConstantsUtil.STR_R.equals(strContextRefType) && conextObjectList != null && !conextObjectList.isEmpty()
						&& !rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) {
					objList.addAll(conextObjectList);
				}
				if (ConstantsUtil.STR_R.equals(strContextRefType) && rangeLocal.equalsIgnoreCase(derivedFilterSelection)
						&& strCharInheritanceType.equals(ConstantsUtil.STR_LOCAL)) {
					return objList;
				}
				if (ConstantsUtil.STR_R.equals(strContextRefType) && rangeLocal.equalsIgnoreCase(derivedFilterSelection)) {
					objList = conextObjectList;
				}
				if (isContextPushed)
					ContextUtil.popContext(context);
			}
		} catch (Exception ex) {
			LOGGER.error("Error from PerformanceCharcteristics:  getPerformanceChar"+ex);
			return new MapList();
		}	
		return objList;
	}


	private MapList getEbomPartsCharacterstics(Context context, Map paramMap, DomainObject finishedPartDO,
			MapList objList, String derivedFilterSelection) throws Exception {
		MapList ebomCharList = new MapList();
		MapList returnList = new MapList();
		String[] newArguments = null;
		StringList strlObjectSelectable = new StringList(3);
		strlObjectSelectable.add(DomainConstants.SELECT_ID);
		strlObjectSelectable.add(DomainConstants.SELECT_TYPE);
		strlObjectSelectable.add(DomainConstants.SELECT_NAME);

		StringList strlRelSelectable = new StringList(3);
		strlRelSelectable.add(DomainRelationship.SELECT_FROM_TYPE);
		strlRelSelectable.add(DomainRelationship.SELECT_TO_TYPE);
		strlRelSelectable.add(DomainRelationship.SELECT_FROM_ID);

		String ebomPartId = null;
		String ebomPartName = null;
		String strDerivedPath = null;
		String relFromType = null;
		String relToType = null;
		String relFromId = null;
		String rangeAll = ConstantsUtil.ALL;

		if (objList != null && objList.size() > 0 && rangeAll.equalsIgnoreCase(derivedFilterSelection)) {
			returnList.addAll(objList);
		}

		MapList conectedEBOMPartList = finishedPartDO.getRelatedObjects(context, DomainObject.RELATIONSHIP_EBOM,
				ConstantsUtil.TYPE_PG_CUSTOMERUNIT + "," + ConstantsUtil.TYPE_PGINNERPACKUNITPART + ","
						+ ConstantsUtil.TYPE_PGCONSUMERUNITPART,
				strlObjectSelectable, strlRelSelectable, false, true, (short) 0, "", null, 0);
		
		Iterator ebomItr = conectedEBOMPartList.iterator();
		while (ebomItr.hasNext()) {
			Map partMap = (Map) ebomItr.next();
			ebomPartId = (String) partMap.get(DomainConstants.SELECT_ID);
			ebomPartName = (String) partMap.get(DomainConstants.SELECT_NAME);
			relFromType = (String) partMap.get(DomainRelationship.SELECT_FROM_TYPE);
			relToType = (String) partMap.get(DomainRelationship.SELECT_TO_TYPE);
			relFromId = (String) partMap.get(DomainRelationship.SELECT_FROM_ID);
			/*if (ConstantsUtil.TYPE_PGCONSUMERUNITPART.equals(relFromType)
					&& (ConstantsUtil.TYPE_PGCONSUMERUNITPART.equals(relToType)
							|| ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(relToType))) {
				continue;
			}*/
			if (ConstantsUtil.TYPE_PG_CUSTOMERUNIT.equals(relFromType) && ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(relToType)) {
				returnList.clear();
				ebomPartId = relFromId;
				if (UIUtil.isNotNullAndNotEmpty(ebomPartId)) {
					ebomPartName = new DomainObject(ebomPartId).getInfo(context, DomainConstants.SELECT_NAME);
				}
			}
			paramMap.put(ConstantsUtil.STRING_OBJECTID, ebomPartId);
			paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, rangeAll);
			newArguments = JPO.packArgs(paramMap);
			//ebomCharList.add(paramMap);
			ebomCharList.addAll(getMicroChar(context, newArguments));

			if (relFromType.equals(ConstantsUtil.TYPE_PG_CUSTOMERUNIT) && relToType.equals(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
				break;
			}
		}
			return ebomCharList;
	}

	public MapList getMicroChar(matrix.db.Context context, String[] args) throws Exception {
		if (args.length == 0) {
			throw new IllegalArgumentException();
		}
		String partType = null;
		MapList objList = new MapList();
		MapList newMapList = new MapList();
		StringList objectSelects = new StringList();
		objectSelects.add(DomainConstants.SELECT_ID);
		objectSelects.add(DomainObject.SELECT_NAME);
		objectSelects.add(DomainObject.SELECT_TYPE);
		objectSelects.add(DomainObject.SELECT_POLICY);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
		objectSelects.add(ConstantsUtil.ATTR_REFERENCE_TYPE);

		StringList relSelects = new StringList();
		relSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
		relSelects.add(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);

		HashMap paramMap = (HashMap) JPO.unpackArgs(args);

		String objectId = (String) paramMap.get(ConstantsUtil.OBJECT_ID);
		String addNewRow = (String) paramMap.get(ConstantsUtil.ADDROW);
		String strSwitchMode = (String) paramMap.get(ConstantsUtil.SWITCHMODE);
		DomainObject doObj = DomainObject.newInstance(context, objectId);

		String strSelectedTable = (String) paramMap.get(ConstantsUtil.SELECTEDTABLE);
		strSelectedTable = strSelectedTable.substring(strSelectedTable.lastIndexOf('~') + 1, strSelectedTable.length());
		String type = ConstantsUtil.TYPE__PERFORMANCE_CHAR;

		final String derivedFilterSelection = (String) paramMap.get(ConstantsUtil.PGVPDPERMANCECHARFILTER);
		String rangeAll = ConstantsUtil.ALL;
		String rangeLocal = ConstantsUtil.STR_LOCAL;
		String rangeReferenced = ConstantsUtil.STR_REFERENCED;
		if (rangeAll.equalsIgnoreCase(derivedFilterSelection) || rangeLocal.equalsIgnoreCase(derivedFilterSelection)) {
			String relPattern = ConstantsUtil.RELATIONSHIP_EXTENDEDDATA + ","
					+ ConstantsUtil.RELATIONSHIP_SHARED_TABLE;
			String typePattern = ConstantsUtil.TYPE_SHARED_TABLE + "," + type;
			objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects, false, true,
					(short) 1, null, null, 0);
			Map mpTemp = new HashMap();
			MapList mlTemp = new MapList();
			for (int x = objList.size() - 1; x >= 0; x--) {
				mpTemp = (Map) objList.get(x);
				String strType = (String) mpTemp.get(DomainConstants.SELECT_TYPE);
				if (strType != null && strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)) {
					String strCharType = (String) mpTemp
							.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);

					if (strCharType != null && !strCharType.equals(type)) {
						objList.remove(x);
					}
				}
			}

			objList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.CONST_INTERGER);

			if (addNewRow != null && addNewRow.equals("true") && (strSwitchMode == null || "".equals(strSwitchMode))) {
				HashMap m = new HashMap();
				m.put(ConstantsUtil.SELECT_ID, ConstantsUtil.BLANK);
				objList.add(m);
			}

			MapList mlTempList = new MapList();
			for (int iSeq = 0; iSeq < objList.size(); iSeq++) {
				Map mpTempList = (Map) objList.get(iSeq);
				mpTempList.put(ConstantsUtil.STR_SEQUENCE, Integer.toString(iSeq + 1));
				mlTempList.add(mpTempList);
			}
			objList.clear();
			objList.addAll(mlTempList);

		}
		String strReferenceType = (String) doObj.getInfo(context, ConstantsUtil.SELECT_ATTR_REFERENCE_TYPE);
		if (rangeAll.equalsIgnoreCase(derivedFilterSelection)
				|| rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) {

			if (UIUtil.isNotNullAndNotEmpty(strReferenceType) && "R".equalsIgnoreCase(strReferenceType)) {
				MapList charList = getMasterCharacteristics(context, args);
				Iterator charListItrtr = charList.iterator();
				while (charListItrtr.hasNext()) {
					Map charMap = (Map) charListItrtr.next();
					if (charMap != null && !charMap.isEmpty()) {
						String strType = (String) charMap.get(DomainConstants.SELECT_TYPE);
						if (strType != null && strType.equals(type)) {
							objList.add(charMap);
						}
						if (strType != null && strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)) {
							String strCharType = (String) charMap
									.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
							if (strCharType != null && strCharType.equals(type)) {
								objList.add(charMap);
							}
						}
					}
				}
			}
		}


		partType = doObj.getInfo(context, DomainConstants.SELECT_TYPE);
		if (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(partType)
				&& (rangeAll.equalsIgnoreCase(derivedFilterSelection)
						|| rangeReferenced.equalsIgnoreCase(derivedFilterSelection))) {
			objList = getEbomPartsCharacterstics(context, paramMap, doObj, objList, derivedFilterSelection);
			
		}

		return objList;

	}

	public MapList getMasterCharacteristics(matrix.db.Context context, String[] args) throws Exception {
		if (args.length == 0) {
			throw new IllegalArgumentException();
		}

		MapList objList = new MapList();
		String objectId = util.getParam(args, ConstantsUtil.OBJECT_ID);
		String addNewRow = util.getParam(args, ConstantsUtil.ADDROW);
		String strSwitchMode = util.getParam(args, ConstantsUtil.SWITCHMODE);
		String strSelectedTable = util.getParam(args, ConstantsUtil.SELECTEDTABLE);
		strSelectedTable = strSelectedTable.substring(strSelectedTable.lastIndexOf('~') + 1, strSelectedTable.length());

		String type = ConstantsUtil.TYPE__PERFORMANCE_CHAR;
		if (UIUtil.isNotNullAndNotEmpty(objectId)) {
			DomainObject doObj = DomainObject.newInstance(context, objectId);
			String masterPartIdSelect = util.getMasterPartSelect(context, ConstantsUtil.SELECT_ID);
			String masterPartNameSelect = util.getMasterPartSelect(context, ConstantsUtil.SELECT_NAME);
			String masterPartTypeSelect = util.getMasterPartSelect(context, ConstantsUtil.SELECT_TYPE);
			String masterPartCurrentSelect = util.getMasterPartSelect(context, ConstantsUtil.SELECT_CURRENT);
			StringList objSelects = util.createSelects(ConstantsUtil.SELECT_ID, ConstantsUtil.SELECT_NAME,
					ConstantsUtil.SELECT_POLICY, ConstantsUtil.SELECT_ATTRIBUTE_STAGE, masterPartIdSelect,
					masterPartNameSelect, masterPartTypeSelect, masterPartCurrentSelect);
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			objSelects.addAll(util.getPerformCharSelects());
			Map objAndMasterMap = doObj.getInfo(context, objSelects);
			if (objAndMasterMap != null && !objAndMasterMap.isEmpty()) {
				String masterPartId = (String) objAndMasterMap.get(masterPartIdSelect);
				String strMasterPartType = "";
				if (UIUtil.isNotNullAndNotEmpty(masterPartId)) {
					strMasterPartType = (String) objAndMasterMap.get(masterPartTypeSelect);
				} else {
					strMasterPartType = ConstantsUtil.TYPE_FINISHEDPRODUCTPART;
				}
				String strMasterCurrent = (String) objAndMasterMap.get(masterPartCurrentSelect);
				if (ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strMasterCurrent)
						|| ConstantsUtil.STATE_COMPLETE.equalsIgnoreCase(strMasterCurrent)) {
					if (UIUtil.isNotNullAndNotEmpty(masterPartId)) {
						objList = getCharacteristicsList(context, masterPartId, type, addNewRow, strSwitchMode);
					}
				}
			}
		}

		return objList;
	}

	private MapList getCharacteristicsList(Context context, String objectId, String type, String addNewRow,
			String strSwitchMode) throws Exception {
		String relPattern = ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "," + ConstantsUtil.RELATIONSHIP_SHARED_TABLE;
		MapList objList = new MapList();
		String typePattern = ConstantsUtil.TYPE_SHARED_TABLE + "," + type;
		StringList objectSelects = util.createSelects(ConstantsUtil.SELECT_ID, ConstantsUtil.SELECT_NAME,
				ConstantsUtil.SELECT_TYPE, ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);

		StringList relSelects = util.createSelects(ConstantsUtil.SELECT_RELATIONSHIP_ID,
				ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,
				ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
		DomainObject doMasterPart = DomainObject.newInstance(context, objectId);
		
		objList = doMasterPart.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
				false, true, (short) 1, null, null, 0);
		
		
		Map mpTemp = new HashMap();
		MapList mlTemp = new MapList();
		for (int x = objList.size() - 1; x >= 0; x--) {
			mpTemp = (Map) objList.get(x);
			String strType = (String) mpTemp.get(DomainConstants.SELECT_TYPE);

			if (strType != null && strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)) {
				String strCharType = (String) mpTemp
						.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);

				if (strCharType != null && !strCharType.equals(type)) {
					objList.remove(x);
				}

			}
		}

		objList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.CONST_INTERGER);

		if (addNewRow != null && addNewRow.equals("true") && (strSwitchMode == null || "".equals(strSwitchMode))) {
			HashMap m = new HashMap();
			m.put(ConstantsUtil.SELECT_ID, ConstantsUtil.BLANK);
			objList.add(m);
		}

		MapList mlTempList = new MapList();
		for (int iSeq = 0; iSeq < objList.size(); iSeq++) {
			Map mpTempList = (Map) objList.get(iSeq);
			mpTempList.put(ConstantsUtil.STR_SEQUENCE, Integer.toString(iSeq + 1));
			mlTempList.add(mpTempList);
		}
		objList.clear();
		objList.addAll(mlTempList);
		return objList;
	}

}