/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaSecurityServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.pg.us.specanywhere_enovia.bo.SecurityClassificationBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaSecurityService;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.EncryptCrypto;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaSecurityServiceImpl implements EnoviaSecurityService {

	private static String USER;
	private static String PASS;
	private static String VAULT;
	private static Logger LOGGER = Logger.getLogger(EnoviaSecurityServiceImpl.class);
	
	public HashMap<String, Map<String,String>> getSecurityClassification(String strId, Environment env) throws Exception {
		HashMap<String, Map<String,String>> hmAttrib = new HashMap();
		StopWatch sp = new StopWatch();
		sp.start();
		EncryptCrypto encrpto = new EncryptCrypto();
		USER = env.getProperty("enovia.user.id");
		PASS = env.getProperty("enovia.user.pwd");
		VAULT = env.getProperty("enovia.user.vault");
		PASS = encrpto.decryptString(PASS);
		EnoviaConnectionPool pool = new EnoviaConnectionPool(USER, PASS, VAULT);
		Context context = pool.checkOut();
		
		DomainObject dmObj=null;
			try {
				DomainObject doObj = new DomainObject(strId);
				if(doObj.exists(context)) {
					dmObj=doObj;
					LOGGER.info("OBJECT EXISTS");
				}
				else
					LOGGER.info("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+strId);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doObj.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				
			} catch (Exception e) {
				LOGGER.error("Error: Unable to initialize domainobject for ID: " + strId);
			}
		
		
		Map<String, StringList> mpSelectable = SecurityClassificationBO.getSelectable(context);
		StringList slSelectable = mpSelectable.get("busSelect");
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.OWNERSHIP);
		Map resultMap = dmObj.getInfo(context, slSelectable);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.OWNERSHIP); 
		//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		dmObj.close(context);
		//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		try {
			hmAttrib.put(ConstantsUtil.OBJECTSECURITYCLASS, resultMap);
		} catch (Exception e) {
			LOGGER.error("Exception in getFilePath: "+e);
		}finally {
			pool.checkIn(context);
		}
		sp.stop();
		context.close();//Added for Defect 45181
		return hmAttrib;
	}
}
