package com.pg.us.specanywhere_enovia.bo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.pg.us.specanywhere_enovia.fop.FormulationSubstituteConstants;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPDFServiceImpl;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.PDFView;

import matrix.db.Context;

public class PDFBO {
	
	private static Logger LOGGER = Logger.getLogger(EnoviaPDFServiceImpl.class);

	public ArrayList<String> getSections(Context context, String strType, boolean bIsGendocView) {
		
		ArrayList<String> arrSection = new ArrayList<>();
		
		if(!bIsGendocView) {
			if(ConstantsUtilIRM.APMP.equals(strType) || ConstantsUtilIRM.PG_APMP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.WEIGHTCHARACTERSTICS);
				arrSection.add(ConstantsUtilIRM.SUSTAINABILITY);
				arrSection.add(ConstantsUtilIRM.SUBSTANCEMATERIALS);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.MASTERSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtil.PERFORMANCECHARACTERISTIC);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtilIRM.PQRVIEWMANUFACTURER);
				arrSection.add(ConstantsUtilIRM.PQRSUPPLIERVIEW);
				arrSection.add(ConstantsUtil.ALTERNATES);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtilIRM.GPSASSESSMENTS);
				arrSection.add(ConstantsUtil.DERIVEDTO);
				arrSection.add(ConstantsUtil.DERIVEDFROM);
				arrSection.add(ConstantsUtil.SUBSTANCES);
			}
			else if(ConstantsUtilIRM.APP.equals(strType) || ConstantsUtil.STRING_TYPE_APP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.WEIGHTCHARCTERISTIC);
				arrSection.add(ConstantsUtil.DANGEROUSGOODSCLASSIFICATION);
				arrSection.add(ConstantsUtilIRM.GLOBALHARMONIZEDSTANDARD);
				arrSection.add(ConstantsUtilIRM.INGREDIENTSTMT);
				arrSection.add(ConstantsUtilIRM.STORAGETRANSPORTATIONLABELINGASSESSMENTDATA);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.PRODUCTPARTSTABILITYDOCUMENT);
				arrSection.add(ConstantsUtilIRM.MASTERPARTSTABILITYDOCUMENT);
				arrSection.add(ConstantsUtilIRM.SAPBOMFED);
				arrSection.add(ConstantsUtil.CHEMICALANDPHYSLEGACYGHDCPROP);
				arrSection.add(ConstantsUtil.CHEMICALANDPHYSLEGACYWAREHOUSEPROP);
				arrSection.add(ConstantsUtilIRM.MARKETCLEARANCE);
				arrSection.add(ConstantsUtilIRM.MATERIALSANDCOMPOSITIONS);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.MASTERSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.REFERENCEDOCUMENTS);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtilIRM.CHARACTERISTICS);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtil.ALTERNATES);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtilIRM.MATERIALPRODUCED);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASS);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtilIRM.GPSASSESSMENTS);
				arrSection.add(ConstantsUtil.SMARTLABEL);
				arrSection.add(ConstantsUtil.CERTIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CERTVALIDATION);
				arrSection.add(ConstantsUtil.DERIVEDTO);
				arrSection.add(ConstantsUtil.DERIVEDFROM);
				arrSection.add(ConstantsUtilIRM.STABILITYRESULT);
				arrSection.add(ConstantsUtilIRM.MASTERATTRIBUTE);
				arrSection.add(ConstantsUtilIRM.DESIGNPARAMETER);
			}
			else if(ConstantsUtilIRM.ARMP.equals(strType) || ConstantsUtilIRM.TP_ARMP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.MATERIALSANDCOMPOSITION);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.MASTERSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtil.PERFORMANCECHARACTERISTIC);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtilIRM.PQRVIEWMANUFACTURER);
				arrSection.add(ConstantsUtilIRM.PQRSUPPLIERVIEW);
				arrSection.add(ConstantsUtil.CERTIFICATIONS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtilIRM.GPSASSESSMENTS);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.WEIGHTCHARCTERISTICS);
				arrSection.add(ConstantsUtil.DERIVEDTO);
				arrSection.add(ConstantsUtil.DERIVEDFROM);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
			}
			else if(ConstantsUtilIRM.COP.equals(strType) || ConstantsUtil.tCOP.contains(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTES);
				arrSection.add(ConstantsUtilIRM.WEIGHTCHARACTERSTICS);
				arrSection.add(ConstantsUtil.STORAGETRANSPORTDATA);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.SUSTAINABILITY);
				arrSection.add(ConstantsUtilIRM.MARKETCLEARANCE);
				arrSection.add(ConstantsUtilIRM.BILLOFMATERIALS);
				arrSection.add(ConstantsUtilIRM.SUBSTITUTES);
				arrSection.add(ConstantsUtil.RELATEDSPECIFICATIONS);
				arrSection.add(ConstantsUtil.MASTERSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtil.PERFORMANCECHARACTERISTIC);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtilIRM.GPSASSESSMENTS);
				arrSection.add(ConstantsUtil.OWNERSHIP);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.ORGANIZATIONS);
				arrSection.add(ConstantsUtil.CERTIFICATIONS);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtil.DERIVEDTO);
				arrSection.add(ConstantsUtil.DERIVEDFROM);
				arrSection.add(ConstantsUtilIRM.TRANSPORTUNITHEAD);
			}
			else if(ConstantsUtilIRM.CUP.equals(strType) || ConstantsUtil.tCUP.contains(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTES);
				arrSection.add(ConstantsUtilIRM.WEIGHTCHARACTERSTICS);
				arrSection.add(ConstantsUtil.STORAGETRANSPORTDATA);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtilIRM.SUBSTITUTES);
				arrSection.add(ConstantsUtil.RELATEDSPECIFICATIONS);
				arrSection.add(ConstantsUtil.MASTERSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtil.PERFORMANCECHARACTERISTIC);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtil.OWNERSHIP);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVAL);
				arrSection.add(ConstantsUtil.ORGANIZATIONS);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtil.DERIVEDTO);
				arrSection.add(ConstantsUtil.DERIVEDFROM);
				arrSection.add(ConstantsUtilIRM.TRANSPORTUNITHEAD);
			}
			else if(ConstantsUtilIRM.DPP.equals(strType) || ConstantsUtilIRM.PG_DPP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.WEIGHTCHARCTERISTIC);
				arrSection.add(ConstantsUtil.DANGEROUSGOODSCLASSIFICATION);
				arrSection.add(ConstantsUtilIRM.GLOBALHARMONIZEDSTANDARD);
				arrSection.add(ConstantsUtilIRM.INGREDIENTSTMT);
				arrSection.add(ConstantsUtilIRM.STORAGETRANSPORTATIONLABELINGASSESSMENTDATA);
				arrSection.add(ConstantsUtilIRM.PRODUCTPARTSTABILITYDOCUMENT);
				arrSection.add(ConstantsUtilIRM.MASTERPARTSTABILITYDOCUMENT);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.SAPBOMFED);
				arrSection.add(ConstantsUtilIRM.MARKETCLEARANCE);
				arrSection.add(ConstantsUtil.SUBSTANCESMATERIALS);
				arrSection.add(ConstantsUtilIRM.MATERIALSANDCOMPOSITIONS);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtilIRM.SUBSTITUTIONS);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.MASTERSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.REFERENCEDOCUMENTS);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtilIRM.PQRVIEWMANUFACTURER);
				arrSection.add(ConstantsUtilIRM.PQRSUPPLIERVIEW);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtilIRM.MATERIALPRODUCED);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASS);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILESECTION);
				arrSection.add(ConstantsUtilIRM.GPSASSESSMENTS);
				arrSection.add(ConstantsUtil.SMARTLABEL);
				arrSection.add(ConstantsUtil.CERTIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CERTVALIDATION);
				arrSection.add(ConstantsUtilIRM.STABILITYRESULT);
			}
			else if(ConstantsUtilIRM.FAB.equals(strType) || ConstantsUtilIRM.PG_FAB.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.WEIGHTCHARACTERISTICS);
				arrSection.add(ConstantsUtilIRM.SUSTAINABILITY);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.SAPBOMFEDS);
				arrSection.add(ConstantsUtilIRM.MARKETOFSALES);
				arrSection.add(ConstantsUtilIRM.REGISTRATIONDETAILS);
				arrSection.add(ConstantsUtilIRM.SUBSTANCEMATERIALS);
				arrSection.add(ConstantsUtilIRM.BILLOFMATERIAL);
				arrSection.add(ConstantsUtilIRM.SUBSTITUTIONS);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtil.MASTERSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.REFERENCEDOCUMENTS);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtil.ALTERNATES);
				arrSection.add(ConstantsUtilIRM.PQRVIEWMANUFACTURER);
				arrSection.add(ConstantsUtilIRM.PQRSUPPLIERVIEW);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtil.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASS);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtilIRM.PACKAGINGCERTIFICATIONS);
			}
			else if(ConstantsUtilIRM.FOP.equals(strType) || ConstantsUtil.tFOP.equals(strType)) {
				arrSection.add(ConstantsUtil.ATTRIBUTES);
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.WEIGHTCHARACTERSTIC);
				arrSection.add(ConstantsUtil.DANGEROUSGOODSCLASSIFICATION);
				arrSection.add(ConstantsUtilIRM.GLOBALHARMONIZEDSTANDARD);
				arrSection.add(ConstantsUtilIRM.INGREDIENTSTMT);
				arrSection.add(ConstantsUtilIRM.STORAGETRANSPORTATIONLABELINGASSESSMENTDATA);
				arrSection.add(ConstantsUtil.CHEMICALANDPHYSLEGACYGHDCPROP);
				arrSection.add(ConstantsUtil.CHEMICALANDPHYSLEGACYWAREHOUSEPROP);
				arrSection.add(ConstantsUtil.CHEMICALANDPHYSLEGACYPROP);
				arrSection.add(ConstantsUtilIRM.PRODUCTPARTSTABILITYDOCUMENT);
				arrSection.add(ConstantsUtilIRM.MASTERPARTSTABILITYDOCUMENT);
				arrSection.add(ConstantsUtilIRM.SAPBOMASFED);
				arrSection.add(ConstantsUtil.FORMULATIONPROCESS);
				arrSection.add(ConstantsUtil.FORMULATIONPROCESSFORMULA);
				arrSection.add(ConstantsUtil.PSUBSUBSTITUTES);
				arrSection.add(ConstantsUtilIRM.MARKETCLEARANCE);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.MASTERSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARCTERISTIC);
				arrSection.add(ConstantsUtilIRM.MATERIALSANDCOMPOSITIONS);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtilIRM.MATERIALPRODUCED);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIP);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.ORGANIZATION);
				arrSection.add(ConstantsUtilIRM.FILESECTION);
				arrSection.add(ConstantsUtilIRM.GPSASSESSMENTS);
				arrSection.add(ConstantsUtil.SMARTLABEL);
				arrSection.add(ConstantsUtil.CERTIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CERTVALIDATION);
				arrSection.add(ConstantsUtil.CHEMICALANDPHYSPROP);
				arrSection.add(ConstantsUtil.DERIVEDPARTS);
				arrSection.add(ConstantsUtilIRM.MASTERATTRIBUTE);
				arrSection.add(ConstantsUtilIRM.STABILITYRESULTS);
			}
			else if(ConstantsUtilIRM.FPP.equals(strType) || ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtil.ATTRIBUTESOBJECT);
				arrSection.add(ConstantsUtilIRM.SMARTLABELROLLUPDATA);
				arrSection.add(ConstantsUtil.DANGEROUSGOODSCLASSIFICATION);
				arrSection.add(ConstantsUtilIRM.GLOBALHARMONIZEDSTANDARD);
				arrSection.add(ConstantsUtilIRM.INGREDIENTSTMT);
				arrSection.add(ConstantsUtil.STORAGETRANSPORTDATAOBJECT);
				arrSection.add(ConstantsUtilIRM.STABILITYRESULTS);
				arrSection.add(ConstantsUtilIRM.WARHOUSECLASSIFICATION);
				arrSection.add(ConstantsUtilIRM.CONST_BATTERYROLLUP);
				arrSection.add(ConstantsUtilIRM.BATTERYCALCULATION);
				arrSection.add(ConstantsUtil.SAPBOMASFED);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.CONS_CUPARTWORK);
				arrSection.add(ConstantsUtilIRM.MARKETOFSALE);
				arrSection.add(ConstantsUtilIRM.REGISTRATIONDETAILS);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtil.PSUBSUBSTITUTES);
				arrSection.add(ConstantsUtil.BILLOFMATERIALSCUSTOMERUNIT);
				arrSection.add(ConstantsUtil.SUBSTITUTESCUSTOMERUNIT);
				arrSection.add(ConstantsUtilIRM.BOMINNERPACK);
				arrSection.add(ConstantsUtilIRM.SUBSTITUTESINNERPACK);
				arrSection.add(ConstantsUtil.BILLOFMATERIALSCONSUMERUNIT);
				arrSection.add(ConstantsUtilIRM.SUBSTITUTESCONSUMERUNIT);
				arrSection.add(ConstantsUtil.BILLOFMATERIALSTRANSPORTUNIT);
				arrSection.add(ConstantsUtil.SUBSTITUTESTRANSPORTUNIT);
				arrSection.add(ConstantsUtil.BILLOFMATERIALSMASTERCUSTOMERUNIT);
				arrSection.add(ConstantsUtil.SUBSTITUTESMASTERCUSTOMERUNIT);
				arrSection.add(ConstantsUtilIRM.BOMMASTERINNERPACK);
				arrSection.add(ConstantsUtil.SUBSTITUTESMASTERINNERPACK);
				arrSection.add(ConstantsUtilIRM.BOMMASTERCONSUMERUNIT);
				arrSection.add(ConstantsUtilIRM.SUBSTITUTESMASTERCONSUNIT);
				arrSection.add(ConstantsUtil.RELATEDSPECIFICATIONS);
				arrSection.add(ConstantsUtil.MASTERSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtil.PERFORMANCECHARACTERISTIC);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtil.WEIGHTSDIMENSIONSOBJECT);
				arrSection.add(ConstantsUtil.PACKINGUNIT);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.BASECODEDETAILS);
				arrSection.add(ConstantsUtil.SUBSTITUTEBASECODEDETAILS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLAASES);
				arrSection.add(ConstantsUtil.ORGANIZATIONSOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtil.CERTIFICATIONS);
				arrSection.add(ConstantsUtilIRM.PACKAGINGCERTIFICATIONS);
				arrSection.add(ConstantsUtil.DERIVEDTO);
				arrSection.add(ConstantsUtil.DERIVEDFROM);
				arrSection.add(ConstantsUtil.UNIQUE_FORMULA_IDENTIFIER);
				arrSection.add(ConstantsUtilIRM.BILLOFMATERIALSFINISHEDPRODUCTPART);
				arrSection.add(ConstantsUtilIRM.TRANSPORTUNITHEAD);//Added by Ketan for Defect no. 6515
			}
			else if(ConstantsUtilIRM.IP.equals(strType) || ConstantsUtilIRM.TYPE_INNER_PACK.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtil.ATTRIBUTESOBJECT);
				arrSection.add(ConstantsUtilIRM.WEIGHTCHARACTERSTICS);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtil.PSUBSUBSTITUTES);
				arrSection.add(ConstantsUtil.RELATEDSPECIFICATIONS);
				arrSection.add(ConstantsUtil.MASTERSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtil.PERFORMANCECHARACTERISTIC);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtil.ORGANIZATIONSOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
			}
			else if(ConstantsUtilIRM.IPP.equals(strType) || ConstantsUtilIRM.PG_IPP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtil.ATTRIBUTESOBJECT);
				arrSection.add(ConstantsUtil.WEIGHTCHARACTERISTIC);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.SAPBOMASFED);
				arrSection.add(ConstantsUtilIRM.MATERIALSANDCOMPOSITION);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtil.SUBSTITUTION);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.MASTERSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtil.PERFORMANCECHARACTERISTIC);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtilIRM.PQRVIEWMANUFACTURER);
				arrSection.add(ConstantsUtilIRM.PQRSUPPLIERVIEW);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtil.ORGANIZATIONSOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
			}
			else if(ConstantsUtilIRM.MCOP.equals(strType) || ConstantsUtilIRM.PG_MCOP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.REFERENCE);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtilIRM.SUBSTITUTIONS);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtilIRM.TRANSPORTUNITHEAD);
			}
			else if(ConstantsUtilIRM.MCP.equals(strType) || ConstantsUtilIRM.MATERIAL_COMPOSITION_PART.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtil.ATTRIBUTESOBJECT);
				arrSection.add(ConstantsUtilIRM.MATERIALSANDCOMPOSITIONS);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtilIRM.GPSASSESSMENTS);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtil.CERTIFICATIONS);
			}
			else if(ConstantsUtilIRM.MCUP.equals(strType) || FormulationSubstituteConstants.CONSTANT_STRING_MASTERCUSTOMERUNIT.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.REFERENCE);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtil.DERIVEDTO);
				arrSection.add(ConstantsUtil.DERIVEDFROM);
				arrSection.add(ConstantsUtilIRM.SUBSTITUTIONS);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtilIRM.TRANSPORTUNITHEAD);
			}
			else if(ConstantsUtilIRM.MIP.equals(strType) || ConstantsUtilIRM.PG_MASTER_INNER_PACK.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.REFERENCE);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtilIRM.SUBSTITUTES);
				arrSection.add(ConstantsUtil.RELATEDSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtil.PERFORMANCECHARACTERISTIC);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.DERIVEDTO);
				arrSection.add(ConstantsUtil.DERIVEDFROM);
			}
			else if(ConstantsUtilIRM.MPAP.equals(strType) || ConstantsUtilIRM.PG_APMP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.REFERENCE);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtilIRM.SUBSTITUTES);
				arrSection.add(ConstantsUtil.RELATEDSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtil.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.DERIVEDTO);
				arrSection.add(ConstantsUtil.DERIVEDFROM);
			}
			else if(ConstantsUtilIRM.MPMP.equals(strType) || ConstantsUtilIRM.PG_MPMP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtil.SUBSTANCESMATERIALS);
				arrSection.add(ConstantsUtilIRM.REFERENCE);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.REFERENCEDOCUMENTS);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASS);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
			}
			else if(ConstantsUtilIRM.MPP.equals(strType)|| ConstantsUtilIRM.PG_MPP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.REFERENCE);
				arrSection.add(ConstantsUtil.STABILITYDOCUMENT);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.REFERENCEDOCUMENTS);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASS);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
			}
			else if(ConstantsUtilIRM.MRMP.equals(strType)|| ConstantsUtilIRM.PG_MRMP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.REFERENCE);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.REFERENCEDOCUMENTS);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASS);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtil.DERIVEDTO);
				arrSection.add(ConstantsUtil.DERIVEDFROM);
			}
			else if(ConstantsUtilIRM.OPP.equals(strType) || ConstantsUtilIRM.PG_OPP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtil.SUBSTANCESMATERIALS);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtil.MASTERSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtilIRM.PQRVIEWMANUFACTURER);
				arrSection.add(ConstantsUtilIRM.PQRSUPPLIERVIEW);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtilIRM.SUSTAINABILITY);
			}
			else if(ConstantsUtilIRM.PAP.equals(strType)|| ConstantsUtil.tPAP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtil.WEIGHTCHARACTERISTIC);
				arrSection.add(ConstantsUtilIRM.SAPBOMASFED);
				arrSection.add(ConstantsUtil.SUBSTANCESMATERIALS);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.MARKETSOFSALEOBJECT);
				arrSection.add(ConstantsUtilIRM.REGISTRATIONDETAILS);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtil.SUBSTITUTION);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtil.MASTERSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtilIRM.PQRVIEWMANUFACTURER);
				arrSection.add(ConstantsUtilIRM.PQRSUPPLIERVIEW);
				arrSection.add(ConstantsUtil.ALTERNATES);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtilIRM.GPSASSESSMENTS);
				arrSection.add(ConstantsUtil.CERTIFICATIONS);
			}
			//SPEC: Added by Ajay for Defect. no. 2642 
			else if(ConstantsUtilIRM.PIP.equals(strType) || ConstantsUtilIRM.PROMOTIONAL_ITEM_PART.contains(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.WEIGHTCHARATERISTIC);
				arrSection.add(ConstantsUtil.MATERIALS);
				arrSection.add(ConstantsUtil.RELATEDSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.REFERENCEDOCUMENTS);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtilIRM.PQRVIEWMANUFACTURER);
				arrSection.add(ConstantsUtilIRM.PQRSUPPLIERVIEW);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASS);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
			}
			else if(ConstantsUtilIRM.PMP.equals(strType) || ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtil.ATTRIBUTESOBJECT);
				arrSection.add(ConstantsUtil.WEIGHTCHARACTERISTIC);
				arrSection.add(ConstantsUtilIRM.SUSTAINABILITY);
				arrSection.add(ConstantsUtil.MATERIALS);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.MASTERSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtil.PERFORMANCECHARACTERISTIC);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtilIRM.PQRVIEWMANUFACTURER);
				arrSection.add(ConstantsUtilIRM.PQRSUPPLIERVIEW);
				arrSection.add(ConstantsUtil.ALTERNATES);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.ORGANIZATION);
				arrSection.add(ConstantsUtilIRM.FILESECTION);
				arrSection.add(ConstantsUtilIRM.GPSASSESSMENTS);
				arrSection.add(ConstantsUtil.CERTIFICATIONS);
			}
			else if(ConstantsUtilIRM.POA.equals(strType) || ConstantsUtilIRM.PG_PIECE_OF_ART.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.CONST_ATTRIBUTES);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.MARKETSAPPROVED);
				arrSection.add(ConstantsUtil.RELATEDSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.REFERENCEDOCUMENTS);
				arrSection.add(ConstantsUtilIRM.PARTSASSOCIATION);
				arrSection.add(ConstantsUtil.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.CONST_SECURITYCLASSES);
				arrSection.add(ConstantsUtil.ORGANIZATIONS);
				arrSection.add(ConstantsUtilIRM.FILESECTION);
				arrSection.add(ConstantsUtilIRM.SUBATTRIBUTES);
			}
			else if(ConstantsUtilIRM.PSUB.equals(strType) || ConstantsUtilIRM.PG_PACKING_SUBASSEMBLY.equals(strType)){
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtil.ATTRIBUTESOBJECT);
				arrSection.add(ConstantsUtil.ORGANIZATIONSOBJECT);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtil.PSUBSUBSTITUTES);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtil.PERFORMANCECHARACTERISTIC);
				arrSection.add(ConstantsUtil.WEIGHTSDIMENSIONSOBJECT);
				arrSection.add(ConstantsUtil.PACKINGUNIT);
				arrSection.add(ConstantsUtil.SPECIFICATION);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtil.MARKETOFSALE);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtil.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLAASES);
				arrSection.add(ConstantsUtilIRM.ISATS);
				arrSection.add(ConstantsUtilIRM.HASATS);
			}
			else if(ConstantsUtilIRM.RMP.equals(strType) || ConstantsUtil.tRMP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtil.ATTRIBUTES);
				arrSection.add(ConstantsUtil.PROFILEIDENTIFICATION);
				arrSection.add(ConstantsUtil.PHYSICALPROPERTIES);
				arrSection.add(ConstantsUtil.PERFUMEPROPERTIES);
				arrSection.add(ConstantsUtil.CHEMICALMOLECULARPROPERTIES);
				arrSection.add(ConstantsUtil.DETERGENTSURFACTANTPROPERTIES);
				arrSection.add(ConstantsUtilIRM.BATTERYDETAILS);
				arrSection.add(ConstantsUtil.WEIGHTCHARACTERISTIC);
				arrSection.add(ConstantsUtil.CHEMICALCLASSIFICATION);
				arrSection.add(ConstantsUtilIRM.SUSTAINABILITY);
				arrSection.add(ConstantsUtil.STABILITYDOCUMENT);
				arrSection.add(ConstantsUtilIRM.MATERIALSANDCOMPOSITION);
				arrSection.add(ConstantsUtil.RELATEDSPECIFICATIONS);
				arrSection.add(ConstantsUtil.MASTERSPECIFICATIONS);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtilIRM.PERFORMANCECHARCTERISTIC);
				arrSection.add(ConstantsUtilIRM.HALBPLANTS);
				arrSection.add(ConstantsUtilIRM.ROHPLANTS);
				arrSection.add(ConstantsUtilIRM.PQRVIEWMANUFACTURER);
				arrSection.add(ConstantsUtilIRM.PQRSUPPLIERVIEW);
				arrSection.add(ConstantsUtil.CERTIFICATIONS);
				arrSection.add(ConstantsUtilIRM.PACKAGINGCERTIFICATIONSMASTER);
				arrSection.add(ConstantsUtil.ALTERNATES);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtilIRM.PRODUCINGFORMULA);
				arrSection.add(ConstantsUtilIRM.STARTINGMATERIAL);
				arrSection.add(ConstantsUtil.RDSITE);
				arrSection.add(ConstantsUtilIRM.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtilIRM.OWNERSHIP);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtil.ORGANIZATIONS);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtilIRM.GPSASSESSMENTS);
				arrSection.add(ConstantsUtil.SUBSTANCESMATERIALS);
			}
			else if(ConstantsUtilIRM.SWP.equals(strType) || ConstantsUtilIRM.PG_SWP.equals(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtilIRM.ATTRIBUTEOBJECT);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtilIRM.MARKETCLEARANCE);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtil.PLANTS);
				arrSection.add(ConstantsUtil.PERFORMANCECHARACTERISTIC);
				arrSection.add(ConstantsUtilIRM.PQRVIEWMANUFACTURER);
				arrSection.add(ConstantsUtilIRM.PQRSUPPLIERVIEW);
				arrSection.add(ConstantsUtilIRM.RELATEDSOFTWAREBUILDS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIPOBJECT);
				arrSection.add(ConstantsUtilIRM.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtilIRM.ORGANIZATIONOBJECT);
				arrSection.add(ConstantsUtilIRM.FILES);
				arrSection.add(ConstantsUtilIRM.GPSASSESSMENTS);
			}
			else if(ConstantsUtilIRM.TUP.equals(strType) ||  ConstantsUtil.tTUP.contains(strType)) {
				arrSection.add(ConstantsUtil.HEADERCONTENT);
				arrSection.add(ConstantsUtil.ATTRIBUTES);
				arrSection.add(ConstantsUtilIRM.NOTES);
				arrSection.add(ConstantsUtil.BILLOFMATERIALS);
				arrSection.add(ConstantsUtil.PSUBSUBSTITUTES);
				arrSection.add(ConstantsUtilIRM.BOMMASTERCUSTOMERUNIT);
				arrSection.add(ConstantsUtilIRM.BOMMASTERINNERPACK);
				arrSection.add(ConstantsUtil.SUBSTITUTESMASTERINNERPACK);
				arrSection.add(ConstantsUtilIRM.BOMMASTERCONSUMERUNIT);
				arrSection.add(ConstantsUtil.SUBSTITUTESMASTERCONSUMERUNIT);
				arrSection.add(ConstantsUtil.SUBSTITUTESMASTERCUSTOMERUNIT);
				arrSection.add(ConstantsUtilIRM.RELATEDSPECIFICATION);
				arrSection.add(ConstantsUtilIRM.CONS_REFERENCEDOCUMENT);
				arrSection.add(ConstantsUtilIRM.RELATEDATS);
				arrSection.add(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW);
				arrSection.add(ConstantsUtil.OWNERSHIP);
				arrSection.add(ConstantsUtil.IPCLASSES);
				arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
				arrSection.add(ConstantsUtil.ORGANIZATION);
				arrSection.add(ConstantsUtilIRM.FILESECTION);
				arrSection.add(ConstantsUtilIRM.TRANSPORTUNITHEAD);
			}
		}
		else {
			arrSection.add(ConstantsUtil.HEADERCONTENT);
			arrSection.add(ConstantsUtilIRM.ATTRIBUTELIST);
			arrSection.add(ConstantsUtil.MARKETSAPPROVED);
			arrSection.add(ConstantsUtil.RELATEDSPECIFICATIONS);
			arrSection.add(ConstantsUtilIRM.PARTASSOCIATION);
			arrSection.add(ConstantsUtilIRM.REFERENCEDOCUMENTS);
			arrSection.add(ConstantsUtilIRM.RELATEDACS);
			arrSection.add(ConstantsUtilIRM.RELATEDIAPS);
			arrSection.add(ConstantsUtil.PLANTS);
			arrSection.add(ConstantsUtilIRM.RELATEDATS);
			arrSection.add(ConstantsUtilIRM.MULTIPLEOWNERSHIPACCESS);
			arrSection.add(ConstantsUtilIRM.RELATEDPARTS);
			arrSection.add(ConstantsUtil.IPCLASSES);
			arrSection.add(ConstantsUtilIRM.SECURITYCLASSES);
			arrSection.add(ConstantsUtilIRM.ORGANIZATIONSDATA);
			arrSection.add(ConstantsUtil.FILES);
			arrSection.add(ConstantsUtilIRM.SUBATTRIBUTES);
		}
		
		return arrSection;
	}
	
	
	public HashMap<String, Object> getPDFdetails(Context context, PDFView pdfView) throws Exception {
		HashMap<String, Object> hmAttrib = new HashMap<String, Object>();
		
		String sName = pdfView.getName();
		String sType = pdfView.getType();
		String sRev = pdfView.getRevision();
		String sId = pdfView.getObjectId();
		
		Map<String,Object> mpData = new HashMap<String,Object>();
		String sView = ConstantsUtil.ALL;
		boolean bIsGendocView = false;
		
		//User Profile
		StopWatch swUserType = new StopWatch();
		swUserType.start();
		SecurityService sct = new SecurityService();
		String sUserType = sct.getUserType();
		BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
		if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
			sUserType = BObjutil.getUserView(context, sId);
		}
		swUserType.stop();
		LOGGER.info("PDF SERVICE USER TYPE ELAPSED TIME : "+swUserType.getTime());
		
		if(ConstantsUtil.PG_CM.equalsIgnoreCase(sUserType)) {
			sUserType = ConstantsUtilIRM.PDFCMVIEW;
		}
		else if(ConstantsUtil.PG_SP.equalsIgnoreCase(sUserType)) {
			sUserType = ConstantsUtilIRM.PDFSPVIEW;
		}
		else {
			sUserType = sUserType;
		}
		
		if(null==sUserType) {
			LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
			HashMap<String,String> errorMap = new HashMap<String,String>();
			String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
			errorMap.put(sError[0], sError[1]);
			hmAttrib.put(ConstantsUtil.ERROR, errorMap);
			context.close();
			return hmAttrib;
		}
			
		//Gendoc or PDF
		if(sType.contains(ConstantsUtilIRM.COM) || sType.equals(ConstantsUtil.tPOA)) { //Modified by Ketan for Defect 6534
			bIsGendocView = true;
		}
		
		//Fetching 'Data' -- START
		//sections
		StopWatch swSections = new StopWatch();
		swSections.start();
		ArrayList<String> arrSections = new ArrayList<>();
		arrSections = getSections(context, sType, bIsGendocView);
		swSections.stop();
		LOGGER.info("PDF SERVICE SECTIONS ELAPSED TIME : "+swSections.getTime());
		
		boolean bIsFilterView = false; //Modified by Ketan for Defect no. 7498
	
		mpData.put(ConstantsUtilIRM.NAME, sName);
		mpData.put(ConstantsUtilIRM.REV, sRev);
		mpData.put(ConstantsUtilIRM.SECTIONS, arrSections);
		mpData.put(ConstantsUtilIRM.ISFILTERVIEW, bIsFilterView);
		//Fetching 'Data' -- END
		
		hmAttrib.put(ConstantsUtilIRM.OBJECTTYPE, sType);
		hmAttrib.put(ConstantsUtilIRM.ROLE, sUserType);
		hmAttrib.put(ConstantsUtilIRM.DATA, mpData);
		hmAttrib.put(ConstantsUtilIRM.OBJECTID, sId);
		hmAttrib.put(ConstantsUtilIRM.VIEW, sView);
		hmAttrib.put(ConstantsUtilIRM.GENDOCVIEW, bIsGendocView);
		
		return hmAttrib;
	}

}
