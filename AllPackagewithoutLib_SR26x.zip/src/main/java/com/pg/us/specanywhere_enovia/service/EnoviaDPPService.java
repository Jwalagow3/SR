package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaDPPService {

	public HashMap<String, Map<String, String>> getDPPdata(String objId, String sComp, Environment env) throws Exception; 
}