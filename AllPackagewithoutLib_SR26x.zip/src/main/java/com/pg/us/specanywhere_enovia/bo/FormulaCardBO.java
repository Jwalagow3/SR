package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.type.MapType;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaVendorSpecsServiceImpl;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.FileUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class FormulaCardBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(FormulaCardBO.class);

	public FormulaCardBO() {
		// empty constructor
	}

	public FormulaCardBO(String oid) {
		this.setObjectId(oid);
	}

	/**
	 * Method Name : getFormulaCardBO Method Description : Initialization of
	 * business objects with their corresponding IDs
	 * 
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getFormulaCardBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	/**
	 * Method Name : getAPMPDO Method Description : Initialization of domain
	 * objects with their corresponding IDs
	 * 
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getFormulaCardDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if (bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	/**
	 * Method Name : getAPMPPartSelectables Method Description :
	 * 
	 * @param context
	 * @return
	 */
	public StringList getFormulaCardSelects(Context context) {
		StringList busSelect = new StringList(100);
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getPlantBusSelectable(context));
		busSelect.addAll(getSecuritySelects(context));
		return busSelect;

	}

	/**
	 * Method Name : getPlantBusSelectable Method Description :
	 * 
	 * @param context
	 * @return
	 */
	public static StringList getPlantBusSelectable(Context context) {
		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		return busSelect;
	}

	/**
	 * Method Name : getSecuritySelects Method Description : Fetching "Security"
	 * related data
	 * 
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}

	/**
	 * Method Name : getCountryClearanceSelectable Method Description :
	 * 
	 * @param context
	 * @return
	 */
	public static StringList getCountryClearanceSelectable(Context context) {

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.STR_COUNTRY_NAME);
		busSelect.add(ConstantsUtil.STR_COUNTRY_CT_NUM);
		busSelect.add(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE);
		busSelect.add(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS);
		busSelect.add(ConstantsUtil.STR_COUNTRY_MANU_SITE);
		busSelect.add(ConstantsUtil.STR_COUNTRY_PACK_SITE);
		busSelect.add(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT);
		busSelect.add(ConstantsUtil.STR_COUNTRY_PLANT_REST);
		busSelect.add(ConstantsUtil.STR_COUNTRY_REG_DATE);
		busSelect.add(ConstantsUtil.STR_COUNTRY_REG_STATUS);
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM);
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS);

		return busSelect;
	}

	/**
	 * Basic Bus Selects
	 * 
	 * @param context
	 * @return
	 */

	private StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList(15);


		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_SUPERSEDESONDATE);

		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_ID);
		busSelect.add(ConstantsUtil.ATL_REVISION);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);

		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_ID);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);

		busSelect.add(ConstantsUtil.SELECT_SAP_ID);
		busSelect.add(ConstantsUtil.SELECT_SAP_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SAP_PHASE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TITLE);
		busSelect.add(ConstantsUtil.SELECT_SAP_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);

		busSelect.add(ConstantsUtil.SELECT_SAP_TO_ID);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_PHASE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_TITLE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_CURRENT);

		busSelect.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_NAME);
		busSelect.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_PHASE);
		busSelect.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_TYPE);
		busSelect.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_ID);
		busSelect.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_TITLE);
		busSelect.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_CURRENT);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);

		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);


		busSelect.add(ConstantsUtil.SELECT_ACS_NAME);			
		busSelect.add(ConstantsUtil.SELECT_ACS_TYPE);			
		busSelect.add(ConstantsUtil.SELECT_ACS_REV); 				
		busSelect.add(ConstantsUtil.SELECT_ACS_STATE); 			
		busSelect.add(ConstantsUtil.SELECT_ACS_ID); 				
		busSelect.add(ConstantsUtil.SELECT_ACS_TITLE); 			
		busSelect.add(ConstantsUtil.SELECT_ACS_PHASE); 			
		busSelect.add(ConstantsUtil.SELECT_ACS_SPEC_SUB_TYPE);	


		busSelect.add(ConstantsUtil.SELECT_IAPS_NAME);			
		busSelect.add(ConstantsUtil.SELECT_IAPS_TYPE);			
		busSelect.add(ConstantsUtil.SELECT_IAPS_REV); 				
		busSelect.add(ConstantsUtil.SELECT_IAPS_STATE); 			
		busSelect.add(ConstantsUtil.SELECT_IAPS_ID); 				
		busSelect.add(ConstantsUtil.SELECT_IAPS_TITLE); 			
		busSelect.add(ConstantsUtil.SELECT_IAPS_PHASE); 

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPCLTRACKINGCODE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPCLDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPCLQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPCLUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS);

		//SPEC: <02.10.2021>: Added for Defect : 39310 by Josephine --START

		busSelect.add(ConstantsUtil.REL_ATS_NAME);
		busSelect.add(ConstantsUtil.REL_ATS_ID);
		busSelect.add(ConstantsUtil.REL_ATS_TYPE);
		busSelect.add(ConstantsUtil.REL_ATS_TITLE);
		busSelect.add(ConstantsUtil.REL_ATS_STATE);
		busSelect.add(ConstantsUtil.REL_ATS_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.REL_ATS_REV);

		//SPEC: <02.10.2021>: Added for Defect : 39310 by Josephine --END

		//SPEC: Release SR18x.5.2 - Added for Defect# 39428  by Amman on Feb 15, 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_SAPDESCRIPTION);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39428  by Amman on Feb 15, 2021 -- END

		//SPEC:Added for Defect : 39077 by Jwala --START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		//SPEC:Added for Defect : 39077 by Jwala --END


		return busSelect;
	}

	/**
	 * AddMultiList
	 */
	public StringList addMultiList() {

		StringList slMultiSelects = new StringList();

		slMultiSelects.add(ConstantsUtil.ATL_NAME);
		slMultiSelects.add(ConstantsUtil.ATL_TITLE);
		slMultiSelects.add(ConstantsUtil.ATL_ID);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		slMultiSelects.add(ConstantsUtil.ATL_REVISION);
		slMultiSelects.add(ConstantsUtil.ATL_TYPE);
		slMultiSelects.add(ConstantsUtil.ATL_RELEASE_PHASE);

		slMultiSelects.add(ConstantsUtil.REL_ATS_NAME);
		slMultiSelects.add(ConstantsUtil.REL_ATS_TITLE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_ID);
		slMultiSelects.add(ConstantsUtil.REL_ATS_STATE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_REV);
		slMultiSelects.add(ConstantsUtil.REL_ATS_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_RELEASE_PHASE);

		slMultiSelects.add(ConstantsUtil.SELECT_SAP_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_CURRENT);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);

		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_EXPIRATION_DATE);

		slMultiSelects.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_CURRENT);

		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);


		slMultiSelects.add(ConstantsUtil.SELECT_ACS_NAME);			
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_TYPE);			
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_REV); 				
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_STATE); 			
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_ID); 				
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_TITLE); 			
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_PHASE); 			
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_SPEC_SUB_TYPE);	

		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_NAME);			
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_TYPE);			
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_REV); 				
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_STATE); 			
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_ID); 				
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_TITLE); 			
		slMultiSelects.add(ConstantsUtil.SELECT_SUPERSEDESONDATE);
		slMultiSelects.add(ConstantsUtil.SELECT_MATERIAL_PRODUCED_SAPDESCRIPTION);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);

		return slMultiSelects;
	}

	public void removeMultiList() {

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_RELEASE_PHASE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_REV);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_RELEASE_PHASE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_EXPIRATION_DATE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MATERIAL_PRODUCED_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MATERIAL_PRODUCED_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MATERIAL_PRODUCED_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MATERIAL_PRODUCED_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MATERIAL_PRODUCED_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MATERIAL_PRODUCED_CURRENT);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_NAME);			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_TYPE);			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_REV); 				
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_STATE); 			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_ID); 				
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_TITLE); 			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_PHASE); 			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_SPEC_SUB_TYPE);	


		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_NAME);			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_TYPE);			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_REV); 				
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_STATE); 			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_ID); 				
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_TITLE); 			

		//SPEC: Release SR18x.5.2 - Added for Defect# 39726  by Amman on Feb 15, 2021 -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPERSEDESONDATE);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39726  by Amman on Feb 15, 2021 -- END

		//SPEC: Release SR18x.5.2 - Added for Defect# 39428  by Amman on Feb 15, 2021 -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MATERIAL_PRODUCED_SAPDESCRIPTION);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39428  by Amman on Feb 15, 2021 -- END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END
	}

	/**
	 * BOM Selectables
	 * 
	 * @param context
	 * @return
	 */
	public Map getBOMSelects(Context context) {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		relSelect.addAll(getBomRelSelect(context));
		busSelect.addAll(getBomSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);

		return mapSelecables;
	}

	/**
	 * Method Name : getBomBusSelect Method Description :
	 * 
	 * @param context
	 * @return
	 */
	public static StringList getBomSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_CONNECTION_ID);
		busSelect.add(ConstantsUtil.SELECT_PARENT);
		busSelect.add(ConstantsUtil.SELECT_LEVEL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);

		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);


		return busSelect;
	}

	/**
	 * Method Name : getBomRelSelect Method Description :
	 * 
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);

		relSelect.add("to."+ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET); 			
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM);				
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR);	
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION); 	
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT); 			
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMBINATION_NUMBER);

		return relSelect;
	}

	/**
	 * 	This methodis to get the Final Ingredients
	 * @param context
	 * @param strObjectID
	 * @param resultMap 
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getFinalIngredients(Context context, String strObjectID, Map resultMap) throws Exception 
	{
		StringList slObjectSelect = new StringList();
		slObjectSelect.addElement(DomainConstants.SELECT_ID);
		slObjectSelect.addElement(DomainConstants.SELECT_NAME);
		slObjectSelect.addElement(DomainConstants.SELECT_TYPE);
		slObjectSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slObjectSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_MATERIAL_NAME);
		slObjectSelect.addElement(ConstantsUtil.STR_IPCLASS);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39305  by Ganesh on Date 2/11/2021 -- START
		slObjectSelect.addElement(ConstantsUtil.SELECT_CURRENT);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39305  by Ganesh on Date 2/11/2021 -- END
		//SPEC: Release SR18x.5.2 - Added for Defect# 39305  by Dominic on Date 18/02/2021 -- START
		slObjectSelect.addElement("last.id");
		slObjectSelect.addElement("last.current");
		//SPEC: Release SR18x.5.2 - Added for Defect# 39305  by Dominic on Date 18/02/2021 -- END

		StringList slRelSelect = new StringList();
		slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
		slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
		slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
		slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);

		MapList mlConnectedData = null;
		Map mapTemp = new HashMap();
		DomainObject dObj=null;

		Map<String, String> mpFinalIngr = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbSapDesc = new StringBuilder();
		StringBuilder sbMaterialFunc = new StringBuilder();
		StringBuilder sbTarget = new StringBuilder();
		StringBuilder sbMin = new StringBuilder();
		StringBuilder sbMax = new StringBuilder();
		StringBuilder sbQTYUOM = new StringBuilder();
		StringBuilder sbChg = new StringBuilder();
		//StringBuilder sbFN = new StringBuilder();
		StringBuilder sbCmt = new StringBuilder();

		StringBuilder sbHeaderTrack = new StringBuilder();
		StringBuilder sbPcDesc = new StringBuilder();
		StringBuilder sbHeadeQty = new StringBuilder();
		StringBuilder sbHeaderUOM = new StringBuilder();
		StringBuilder sbDisplayType = new StringBuilder();
		try 
		{

			String sPCTrackcode = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPCLTRACKINGCODE));
			String sPcDesc = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPCLDESCRIPTION));
			String sPCQty = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPCLQUANTITY));
			String sPCUom = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPCLUOM));

			util.formatData(sbHeaderTrack, sPCTrackcode);
			util.formatData(sbPcDesc, sPcDesc);
			util.formatData(sbHeadeQty, sPCQty);
			util.formatData(sbHeaderUOM, sPCUom);


			String sWhere = ConstantsUtil.EMPTY_STRING;
			if (util.isModificatinRequired()) {
				sWhere = "current!=Obsolete";
			}
			SecurityService ss = new SecurityService();
			String sUserCompanies = ss.getUserCauthorities();
			String[] aCompany = sUserCompanies.split(",");
			StringBuilder sbCompany = new StringBuilder();
			StringList slUserOwnership = util.filterOwnerShip(sUserCompanies);
			String sUserlicense = ss.getUserLicense();

			if (aCompany.length > -1) {
				for (int i = 0; i < aCompany.length; i++) {
					if (null != aCompany[i]) {
						String Company = aCompany[i].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					}
				}
			}


			if(null!= strObjectID && !"".equals(strObjectID) && !"null".equals(strObjectID))
			{
				dObj= DomainObject.newInstance(context,strObjectID);

				/*mlConnectedData = (MapList)dObj.getRelatedObjects(context,ConstantsUtil.RELATIONSHIP_PGPRODUCTCOMPOSITION,"*",
					 slObjectSelect,slRelSelect,false,true,(short)1,sWhere,"");

				 */
				mlConnectedData = dObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGPRODUCTCOMPOSITION, ConstantsUtil.QUERY_WILDCARD,
						slObjectSelect, slRelSelect, false, true, (short) 1, sWhere,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

				if(null != mlConnectedData && mlConnectedData.size() > 0)

				{
					mlConnectedData.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER,ConstantsUtil.ASCENDING,ConstantsUtil.INTEGER);


					for(int i=0;i<mlConnectedData.size();i++)
					{
						mapTemp = (Map)mlConnectedData.get(i);
						String id = validator.getStringEquivalentForStringList(mapTemp.get(ConstantsUtil.SELECT_ID));
						String type = validator.getStringEquivalentForStringList(mapTemp.get(ConstantsUtil.SELECT_TYPE));
						String name = validator.getStringEquivalentForStringList(mapTemp.get(ConstantsUtil.SELECT_NAME));
						String state = validator.getStringEquivalentForStringList(mapTemp.get(ConstantsUtil.SELECT_CURRENT));
						String SAPDescription = validator.getStringEquivalentForSubstituteString(mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));

						if(ConstantsUtil.TYPE_PGPPMCONSTITUENT.equalsIgnoreCase(type)){
							SAPDescription = validator.getStringEquivalentForSubstituteString(mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIAL_NAME));
						}

						String MaterialFunction = validator.getStringEquivalentForSubstituteString(mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION));
						String Comment = validator.getStringEquivalentForSubstituteString(mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
						String MinQty = validator.getStringEquivalentForStringList(mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY));

						String QtyUOM = validator.getStringEquivalentForStringList(mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE));
						String Chg = validator.getStringEquivalentForStringList(mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE));

						String MaxQty = validator.getStringEquivalentForStringList(mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY));
						String Qty = validator.getStringEquivalentForStringList(mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY));

						String strClassFied = validator.getStringEquivalentForStringList(mapTemp.get(ConstantsUtil.STR_IPCLASS));
						boolean bHasOwnership = false;

						boolean showData = util.checkHasAccess(context, null, id);

						if (state.equals(ConstantsUtil.STATE_OBSOLETE) || state.equals(ConstantsUtil.STATE_PRELIMINARY) || state.equals(ConstantsUtil.STATE_INWORK)){
							id = ConstantsUtil.NO_ACCESS;
						} 
						if(ConstantsUtil.TYPE_PGPPMCONSTITUENT.equalsIgnoreCase(type)) {
							showData = util.checkHasAccess(context, null, strObjectID);
						}
						if (!showData) {
							id  = ConstantsUtil.NO_ACCESS;
							Chg  = ConstantsUtil.NO_ACCESS;
						}

						util.formatData(sbId, id);
						util.formatData(sbType, type);
						type=getMappedType(type.trim());
						if(type.equalsIgnoreCase("CNT")){
							type="Constituent";
						}

						util.formatData(sbDisplayType, type);
						util.formatData(sbName, name);
						util.formatData(sbSapDesc, SAPDescription);
						util.formatData(sbMaterialFunc, MaterialFunction);
						util.formatData(sbTarget, Qty);

						if("#DENIED!".equalsIgnoreCase(SAPDescription) || "#DENIED!".equalsIgnoreCase(SAPDescription)) {
							MinQty = ConstantsUtil.NO_ACCESS;
						}

						util.formatData(sbMin, MinQty);
						util.formatData(sbChg, Chg);
						util.formatData(sbMax, MaxQty);
						util.formatData(sbQTYUOM, QtyUOM);
						util.formatData(sbCmt, Comment);

					}


					mpFinalIngr.put(ConstantsUtil.ID, sbId.toString());
					mpFinalIngr.put(ConstantsUtil.NAME, sbName.toString());
					mpFinalIngr.put(ConstantsUtil.CHG, sbChg.toString());
					mpFinalIngr.put(ConstantsUtil.SAPDESCRIPTION, sbSapDesc.toString());
					mpFinalIngr.put(ConstantsUtil.TYPE, sbType.toString());
					mpFinalIngr.put(ConstantsUtil.MIN, sbMin.toString());
					mpFinalIngr.put(ConstantsUtil.TARGET, sbTarget.toString());
					mpFinalIngr.put(ConstantsUtil.MAX, sbMax.toString());
					mpFinalIngr.put(ConstantsUtil.UOM, sbQTYUOM.toString());
					mpFinalIngr.put(ConstantsUtil.MF, sbMaterialFunc.toString());
					mpFinalIngr.put(ConstantsUtil.COMMENTS, sbCmt.toString());
					mpFinalIngr.put(ConstantsUtil.TRACKINGCODE, sPCTrackcode.toString());
					mpFinalIngr.put(ConstantsUtil.TOTAL, sPCQty.toString());
					mpFinalIngr.put(ConstantsUtil.DESCRIPTION, sPcDesc.toString());
					mpFinalIngr.put(ConstantsUtil.HEADERUOM, sPCUom.toString());
					mpFinalIngr.put(ConstantsUtil.DISPLAY_TYPE, sbDisplayType.toString());

				}

			}	

		} catch(Exception e)
		{
			LOGGER.error("Error from FormulaCardBO:  getFinalIngredients" + e);
			return new HashMap();
		}
		return mpFinalIngr;
	}



	/**
	 * Method Name : updateRefDocs Method Description : Getting the Reference
	 * Documents of the Part
	 * 
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map updateRefDocs(Context context, Map resultMaps) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();
		CommonDocBO commonDoc = new CommonDocBO();
		FileUtil fileUtil = new FileUtil();
		StringBuilder sbGendocName = new StringBuilder();
		StringBuilder sbGendocPath = new StringBuilder();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);

		boolean bHasOwnerShip = false;

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();

		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}
		String sObjectId = validator.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ID))
				? (String) resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

		Map<String, String> mpRefDoc = new HashMap();
		//SPEC: <29.03.2021>: Guna Commented for Defect 41858 Dev 18x.6   -- START
		/*String objectWhere = "((name ~~RF_* || name ~~DF_* || name ~~QEC_* || name ~~LR_* || name ~~IMG_*) && (revision != Rendition))";
		if (util.isModificatinRequired()) {
			objectWhere = "((name ~~LR_*) && (revision != Rendition))";
		}*/
		//SPEC: <29.03.2021>: Guna Commented for Defect 41858 Dev 18x.6   -- END
		try {
			DomainObject dobCdoc = new DomainObject(sObjectId);
			//SPEC: <29.03.2021>: Guna Modified for Defect 41858 Dev 18x.6   -- START
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <29.03.2021>: Guna Modified for Defect 41858 Dev 18x.6   -- END
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobCdoc.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			Iterator objectListItr = mlRelatedSpecs.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbDispType = new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbDescription = new StringBuilder();
			StringBuilder sbTitle = new StringBuilder();
			StringBuilder sbLangBuffer = new StringBuilder();
			StringBuilder sbSource = new StringBuilder();
			StringBuilder sbIsIRM = new StringBuilder();
			StringBuilder sbGendocFormat = new StringBuilder();
			String sName = ConstantsUtil.EMPTY_STRING;
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sLangName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRev = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String sLangBuffer =ConstantsUtil.EMPTY_STRING;
				String sCSSType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
				String Display_Type = "";

				String strClassFied = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				StringList eachOwnership = validator
						.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE)) {
					continue;
				}

				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}

				// SPEC: Added for 18x.5.2 DEV --Shashank -- START
				Map mpFiles = new HashMap();
				DomainObject doRefDoc = new DomainObject(sId);
				boolean bisIRMDoc = commonDoc.isIRMDoc(sType);
				String sGendocName = "";
				String sGendocPath = "";
				String sGendocPathFormat = "";
				if (bisIRMDoc) {
					mpFiles = fileUtil.getGendocForIRM(context, doRefDoc);
					sGendocName = validator.getStringEquivalentForSubstituteString(
							mpFiles.get(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME));
					sGendocPath = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
				} else {
					mpFiles = fileUtil.getFilesForIPM(context, doRefDoc);
					sGendocName = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_NAME));
					sGendocPath = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
					sGendocPathFormat = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FORMAT_FILE));
				}
				// SPEC: Added for 18x.5.2 DEV --Shashank -- END
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doRefDoc.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				StringList fileNameList =new StringList();
				StringList filePathList =new StringList();

				if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE)) {
					continue;
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- START
				if(bisIRMDoc){
					sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- END
				//SPEC: <29.03.2021>: Guna Added for Defect 41858 Dev 18x.6   -- START
				else{
					sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_NAME));

				}
				//SPEC: <04.05.2021>: Guna Added for 42853 Defect  Dev 18x.6   -- START
				fileNameList =FrameworkUtil.split(sGendocName, ",");
				sGendocName=validator.getEquivalentStringComma(fileNameList);

				filePathList =FrameworkUtil.split(sGendocPath, ",");
				sGendocPath=validator.getEquivalentStringComma(filePathList);
				//SPEC: <04.05.2021>: Guna Added for 42853 Defect  Dev 18x.6   -- END
				if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
					sLangBuffer=sPGLangBuffer;
				else 
					sLangBuffer=sPLangBuffer;
				//SPEC: <30.08.2021>: Guna Modified for 42089 Defect  Dev 18x.6.0.2   -- START
				String	sDocName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				//SPEC: <29.03.2021>: Guna Added for Defect 41858 Dev 18x.6   -- END
				if (!sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR)) {
					//SPEC: <29.03.2021>: Guna Modified for Defect 41858 Dev 18x.6   -- START
					//String sLangBuffer = ConstantsUtil.EMPTY_STRING;
					if(sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)){
						//if(!bisIRMDoc){
						if (sDocName.contains("LR_"))
							//SPEC: <30.08.2021>: Guna Modified for 42089 Defect  Dev 18x.6.0.2   -- END
							sLangBuffer = sRev;
						else
							sLangBuffer = "";
					}
					//SPEC: <29.03.2021>: Guna Modified for Defect 41858 Dev 18x.6   -- END
					//SPEC: Release SR18x.5.2 - Modified for Defect# 38266  by Guna on Date 11/02/2021 -- START
					if ("Reference File".equalsIgnoreCase(sCSSType) || "Reference_File".equalsIgnoreCase(sCSSType)) {
						//SPEC: Release SR18x.5.2 - Modified for Defect# 38266  by Guna on Date 11/02/2021 -- END
						Display_Type = "Reference File";

					} else if ("QEC_File".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Quality Evolution Chart File";

					} else if ("Design_File".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Design File";

					} else if ("Language_Rendition".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Language Rendition";

					} else if ("Image File".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Image File";
					}
					//SPEC: <30.08.2021>: Guna Added for 42089 Defect  Dev 18x.6.0.2   -- START
					else if("Translation File".equalsIgnoreCase(sCSSType) || "Translation_File".equalsIgnoreCase(sCSSType)){
						Display_Type="Translation File";
					}
					//SPEC: <12.10.2021>: Guna Added for Internal Defect  Dev 18x.6.0.2   -- START
					if(UIUtil.isNotNullAndNotEmpty(Display_Type)){
						sType=Display_Type;
					}
					// Modified by Satyam for Defect 51172 -- START
					else {
						Display_Type=sType;
					}
					// Modified by Satyam for Defect 51172 -- END
					//SPEC: <12.10.2021>: Guna Added for Internal Defect  Dev 18x.6.0.2   -- END

					//SPEC: <30.08.2021>: Guna Added for 42089 Defect  Dev 18x.6.0.2   -- END
                  
					//Added by Ganesh for Security Implementation start
					boolean showData = util.checkHasAccess(context, null, sId);
					//SPEC: Release SR18x.6.0.1 Modified by Dominic for REQ 33248 on Date 07/05/2021 --START
					if(!showData && util.isModificatinRequired()){
						continue;
					}
					//SPEC: Release SR18x.6.0.1 Modified by Dominic for REQ 33248 on Date 07/05/2021 --END
					//SPEC: <06.04.2021>: Guna Added for 42137 Defect  Dev 18x.6   -- START
					if(!sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_EXISTS)) {
						//sId = ConstantsUtil.EMPTY_STRING;
						sId = ConstantsUtil.NO_ACCESS;
					}
					//SPEC: <06.04.2021>: Guna Added for 42137 Defect  Dev 18x.6   -- END
					if (showData) 
					{
						util.formatData(sbType, util.mapType(sType));
						util.formatData(sbDispType, util.mapType(Display_Type));
						util.formatData(sbName, sName);
						util.formatData(sbDescription, sDesc);
						util.formatData(sbCurrent, sCurrent);
						util.formatData(sbId, sId);
						util.formatData(sbRev, sRev);
						util.formatData(sbTitle, sTitle);
						//SPEC: <29.03.2021>: Guna Modified for Defect 41858 Dev 18x.6   -- START
						//util.formatData(sbSource, ConstantsUtil.NO_ACCESS);
						util.formatData(sbSource, ConstantsUtil.SOURCE_DIRECT);
						//SPEC: <29.03.2021>: Guna Modified for Defect 41858 Dev 18x.6   -- END
						util.formatData(sbLangBuffer, sLangBuffer);
						util.formatData(sbGendocName, sGendocName);
						util.formatData(sbGendocPath, sGendocPath);
						util.formatData(sbIsIRM, String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, sGendocPathFormat);
					} else {
						util.formatData(sbType, util.mapType(sType));
						util.formatData(sbName, sName);
						util.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
						util.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
						util.formatData(sbId, ConstantsUtil.NO_ACCESS);
						util.formatData(sbRev, ConstantsUtil.NO_ACCESS);
						util.formatData(sbTitle, ConstantsUtil.NO_ACCESS);
						util.formatData(sbSource, ConstantsUtil.NO_ACCESS);
						util.formatData(sbLangBuffer, ConstantsUtil.NO_ACCESS);
						// SPEC: Added for 18x.5.2 DEV --Shashank -- START
						util.formatData(sbGendocName, ConstantsUtil.NO_ACCESS);
						util.formatData(sbGendocPath, ConstantsUtil.NO_ACCESS);
						// SPEC: Added for 18x.5.2 DEV --Shashank -- END

						// ReferenceDocuments On : 02-05-2021 -- START
						util.formatData(sbIsIRM, String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, ConstantsUtil.NO_ACCESS);
						// ReferenceDocuments On : 02-05-2021 -- END
					}

					//Added by Ganesh for Security Implementation end
				}
			}
			mpRefDoc.put(ConstantsUtil.NAME, sbName.toString());
			mpRefDoc.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpRefDoc.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpRefDoc.put(ConstantsUtil.TYPE, sbType.toString());
			mpRefDoc.put(ConstantsUtil.DISPLAY_TYPE, sbDispType.toString());
			mpRefDoc.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpRefDoc.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.LANGUAGE, sbLangBuffer.toString());
			mpRefDoc.put(ConstantsUtil.REVISION, sbRev.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCNAME, sbGendocName.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCPATH, sbGendocPath.toString());
			mpRefDoc.put(ConstantsUtil.ISIRM, sbIsIRM.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCFORMAT, sbGendocFormat.toString());
		} catch (Exception e) {

			LOGGER.error("Exception in Program : FormulaCardBO Method :updateRefDocs " + e);
			e.printStackTrace();
			return new HashMap();
		}

		return mpRefDoc;
	}

	/**
	 * Method Name : getPhaseBOM Method Description :
	 * 
	 * @param context
	 * @param mlEBOMList
	 * @return
	 */
	public Map<String, String> getPhaseBOM(Context context, MapList mlEBOMList, Map resultMap) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		Map MPFinalEBOMSubStitute = new TreeMap();
		Map mpFinalEBOM = new TreeMap();
		Map mpFinalSubstitute = new TreeMap();

		StringValidatorUtil validator = new StringValidatorUtil();

		StringBuilder sbEBOMBaseQty = new StringBuilder();
		StringBuilder sbEBOMFilBaseQty = new StringBuilder();
		StringBuilder sbEBOMBaseUOM = new StringBuilder();

		int index=0;
		Iterator objectListItr = mlEBOMList.iterator();
		Map<String, String> mpHeaderEBOMResult = new HashMap<String, String>();
		try 
		{

			String sHeaderBOMBaseQty = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			String sHeaderFilBaseQty = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
			String sHeaderBaseUOM = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);

			util.formatData(sbEBOMBaseQty, sHeaderBOMBaseQty);
			util.formatData(sbEBOMFilBaseQty, sHeaderFilBaseQty);
			util.formatData(sbEBOMBaseUOM, sHeaderBaseUOM);

			mpHeaderEBOMResult.put(ConstantsUtil.BASEQUANTITY, sbEBOMBaseQty.toString());
			mpHeaderEBOMResult.put(ConstantsUtil.FILEBASEBOMQTY, sbEBOMFilBaseQty.toString());
			mpHeaderEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBaseUOM.toString());

			while (objectListItr.hasNext()) 
			{
				Map<String, String> mpSubstituteResult = new HashMap<String, String>();
				Map<String, String> mpEBOMResult = new HashMap<String, String>();

				StringBuilder sbEBOMId = new StringBuilder();
				StringBuilder sbEBOMType = new StringBuilder();
				StringBuilder sbEBOMDisplayType = new StringBuilder();
				StringBuilder sbEBOMName = new StringBuilder();
				StringBuilder sbEBOMChg = new StringBuilder();
				StringBuilder sbEBOMSapDes = new StringBuilder();
				StringBuilder sbEBOMFileDesc = new StringBuilder();
				StringBuilder sbEBOMSpecSubType = new StringBuilder();
				StringBuilder sbEBOMSubStitute = new StringBuilder();
				StringBuilder sbEBOMMin = new StringBuilder();
				StringBuilder sbEBOMTarget = new StringBuilder();
				StringBuilder sbEBOMMax = new StringBuilder();
				StringBuilder sbEBOMUOM = new StringBuilder();
				StringBuilder sbEBOMMaterialFunc = new StringBuilder();
				StringBuilder sbEBOMPosIndicator = new StringBuilder();
				StringBuilder sbEBOMCmt = new StringBuilder();
				StringBuilder sbEBOMBatch = new StringBuilder();

				StringList slSelects= new StringList();
				slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
				slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
				slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);

				Map mpPhase = (Map) objectListItr.next();
				String sId = (String) mpPhase.get(ConstantsUtil.SELECT_ID);

				DomainObject doFPhaseID = new DomainObject() ;
				MapList mlPhaseEBOMList = new MapList();
				if (UIUtil.isNotNullAndNotEmpty(sId)) 
				{
					//DomainObject doFPP = new DomainObject(sId);

					doFPhaseID = new DomainObject(sId);

					mlPhaseEBOMList = doFPhaseID.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
							ConstantsUtil.QUERY_WILDCARD, getBomSelect(context), getBomRelSelect(context), false, true,
							(short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);


					mlPhaseEBOMList.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER,ConstantsUtil.ASCENDING,ConstantsUtil.INTEGER);


				}

				String sType = (String) mpPhase.get(ConstantsUtil.SELECT_TYPE);
				String sName = (String) mpPhase.get(ConstantsUtil.SELECT_NAME);
				String sDesc = (String) mpPhase.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sChg = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);

				String sSAPDesc =sDesc;
				String sFileDesc = (String) mpPhase.get(ConstantsUtil.SELECT_DESCRIPTION);

				String sDispType="";
				String sSpecSubType = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);

				sSpecSubType ="";

				String sSubstitute = validator.getStringEquivalentForStringList(mpPhase.get(ConstantsUtil.SELECT_SUBSTITUTE));

				String sMin = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);

				//Target Column 
				String sSubTotal = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);
				String sSubTUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
				String sIngrLoss = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
				String sIngrLossUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);

				String sPhaseQTY =ConstantsUtil.EMPTY_STRING;
				String sPhaseUOM =ConstantsUtil.EMPTY_STRING;
				String sTotal =ConstantsUtil.EMPTY_STRING;
				String sPhaseAttrCmt =ConstantsUtil.EMPTY_STRING;

				if(UIUtil.isNotNullAndNotEmpty(sId))
				{
					Map mpQTYVals = doFPhaseID.getInfo(context, slSelects);
					sPhaseQTY = (String) mpQTYVals.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
					sPhaseUOM = (String) mpQTYVals.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
					sPhaseAttrCmt = (String) mpQTYVals.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
					sTotal = sPhaseUOM;
				}
				String sFinalTarget ="Subtotal: "+sSubTotal+" "+sSubTUOM+" Ingredient Loss: "+sIngrLoss+" "+sIngrLossUOM+" Total: "+sPhaseQTY +" "+sTotal;


				//Child
				String sChildTarget = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
				String sMax = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
				String sUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
				String sMaterialFunc = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
				String sTotalBatch = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
				String sTBUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
				String sPosIndicator = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
				String sAttrCmt = validator.getStringEquivalentForStringList(mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT));
				//<SPEC> 03/02/2021- Modified by Govind for Defect #38142 start 
				//sAttrCmt = sPhaseAttrCmt + "Ingridient Loss Comment :"+sAttrCmt;
				sAttrCmt = sPhaseAttrCmt + "Ingredient Loss Comment :"+sAttrCmt; 
				//<SPEC> 03/02/2021- Modified by Govind for Defect #38142 end 

				//<SPEC> 06/23/2021- Modified by Madhana for Defect #43781 Start 
				doFPhaseID = new DomainObject(sId);
				String sRangeMax = (String) doFPhaseID.getAttributeValue(context, ConstantsUtil.ATTRIBUTE_PGMAXQUANTITY); 
				String sRangeMin = (String) doFPhaseID.getAttributeValue(context, ConstantsUtil.ATTRIBUTE_PGMINQUANTITY);

				String sFinalBatch  ="Target: "+sTotalBatch+" Range Min: "+sRangeMin +" Range Max  "+sRangeMax+" UOM: "+sTBUOM;
				//<SPEC> 06/23/2021- Modified by Madhana for Defect #43781 End
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doFPhaseID.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				String strClassFiedParent = validator.getStringEquivalentForStringList(mpPhase.get(ConstantsUtil.STR_IPCLASS));

				sMin="";
				sMax="";


				boolean bHasOwnership = false;
				String sFormulaPropagate = sId;
				/*if (util.isModificatinRequired()) 
				{

					// Formulation part does not have ownership on itself, hence
					// expand to get it from the Cosmetic formulation
					if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = util.getFormulaPropagate(context, sId);
					}

					if (!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}
					if (!bHasOwnership) {

						sId = ConstantsUtil.NO_ACCESS;
						sDispType=ConstantsUtil.NO_ACCESS;
						sChg = ConstantsUtil.NO_ACCESS;
						sSAPDesc = ConstantsUtil.NO_ACCESS;
						sFileDesc = ConstantsUtil.NO_ACCESS;
						sSpecSubType = ConstantsUtil.NO_ACCESS;
						sSubstitute = ConstantsUtil.NO_ACCESS;
						sMin = ConstantsUtil.NO_ACCESS;
						sFinalTarget = ConstantsUtil.NO_ACCESS;
						sMax = ConstantsUtil.NO_ACCESS;
						sUOM = ConstantsUtil.NO_ACCESS;
						sMaterialFunc = ConstantsUtil.NO_ACCESS;
						sPosIndicator = ConstantsUtil.NO_ACCESS;
						sAttrCmt = ConstantsUtil.NO_ACCESS;
						sTBUOM = ConstantsUtil.NO_ACCESS;
					}
				} else 
				{

					StringList slHIRTypes = new StringList();

					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

					boolean showData = true;
					if (slHIRTypes.contains(sType)) {

						String sFormulaClassif = strClassFiedParent;

						if (!sec.isExternalUser()) {
							if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
							}
							if (null != sUserlicense && null != sFormulaClassif
									&& !sUserlicense.contains(sFormulaClassif)) {
								showData = false;
							}
						}

						if (!showData) {

							sId = ConstantsUtil.NO_ACCESS;
							sDispType=ConstantsUtil.NO_ACCESS;
							sChg = ConstantsUtil.NO_ACCESS;
							sSAPDesc = ConstantsUtil.NO_ACCESS;
							sFileDesc = ConstantsUtil.NO_ACCESS;
							sSpecSubType = ConstantsUtil.NO_ACCESS;
							sSubstitute = ConstantsUtil.NO_ACCESS;
							sMin = ConstantsUtil.NO_ACCESS;
							sFinalTarget = ConstantsUtil.NO_ACCESS;
							sMax = ConstantsUtil.NO_ACCESS;
							sUOM = ConstantsUtil.NO_ACCESS;
							sMaterialFunc = ConstantsUtil.NO_ACCESS;
							sPosIndicator = ConstantsUtil.NO_ACCESS;
							sAttrCmt = ConstantsUtil.NO_ACCESS;
							sTBUOM = ConstantsUtil.NO_ACCESS;
						}

					}
				}*/

				//Added by Ganesh for security implementation start
				boolean showData = util.checkHasAccess(context, null, sId);
				if (!showData) {

					sId = ConstantsUtil.NO_ACCESS;
					sChg = ConstantsUtil.NO_ACCESS;

					/*sId = ConstantsUtil.NO_ACCESS;
					sDispType=ConstantsUtil.NO_ACCESS;
					sChg = ConstantsUtil.NO_ACCESS;
					sSAPDesc = ConstantsUtil.NO_ACCESS;
					sFileDesc = ConstantsUtil.NO_ACCESS;
					sSpecSubType = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					sMin = ConstantsUtil.NO_ACCESS;
					sFinalTarget = ConstantsUtil.NO_ACCESS;
					sMax = ConstantsUtil.NO_ACCESS;
					sUOM = ConstantsUtil.NO_ACCESS;
					sMaterialFunc = ConstantsUtil.NO_ACCESS;
					sPosIndicator = ConstantsUtil.NO_ACCESS;
					sAttrCmt = ConstantsUtil.NO_ACCESS;
					sTBUOM = ConstantsUtil.NO_ACCESS;*/
				}
				//Added by Ganesh for Security implemenatation stop

				util.formatData(sbEBOMId, sId);
				util.formatData(sbEBOMType, sType);
				util.formatData(sbEBOMDisplayType, sDispType);
				util.formatData(sbEBOMName, sName);
				util.formatData(sbEBOMChg, sChg);
				util.formatData(sbEBOMSapDes, sSAPDesc);
				util.formatData(sbEBOMFileDesc, sFileDesc);
				util.formatData(sbEBOMSpecSubType, sSpecSubType);
				util.formatData(sbEBOMSubStitute, sSubstitute);
				util.formatData(sbEBOMMin, sMin);
				util.formatData(sbEBOMTarget, sFinalTarget);
				util.formatData(sbEBOMMax, sMax);
				util.formatData(sbEBOMUOM, sUOM);
				util.formatData(sbEBOMMaterialFunc, sMaterialFunc);
				util.formatData(sbEBOMPosIndicator, sPosIndicator);
				util.formatData(sbEBOMCmt,sAttrCmt);
				util.formatData(sbEBOMBatch,sFinalBatch);

				Iterator objectPhaseListItr = mlPhaseEBOMList.iterator();

				//mpSubstituteResult = getFormulaCardSubstitutes(context,mlPhaseEBOMList,sName,sDesc);

				mpSubstituteResult = getFormulaCardSubstitutes(context,mlPhaseEBOMList,sName,sFileDesc,sId,sType);

				while (objectPhaseListItr.hasNext()) 
				{
					Map objectMap = (Map) objectPhaseListItr.next();
					sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
					sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					String sOid = (String) objectMap.get(ConstantsUtil.SELECT_ID);
					sChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
					sSAPDesc = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					sFileDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
					if(!sType.equals(ConstantsUtil.TYPE_PGPHASE)){
						sDispType =getMappedType(sType);
						sSpecSubType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
						String strAttrPgCSSType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
						// Guna Modified for Defect 38208  18x.5.2 Release -- START
						sSpecSubType = getSpecificationSubtype(context, sType, sSpecSubType, strAttrPgCSSType,sOid);
						// Guna Modified for Defect 38208  18x.5.2 Release -- END
					}else{
						//sDispType="";
						sDispType="Fil";
						sSpecSubType="";
					}



					//	sSpecSubType =getMappedType(sSpecSubType);
					sSubstitute = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));

					sMin = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
					sChildTarget = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
					sMax = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
					sUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);

					//sMaterialFunc = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
					sMaterialFunc = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION));
					sPosIndicator = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
					//sAttrCmt = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
					sAttrCmt = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
					sTBUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
					sFinalTarget=sChildTarget;

					//Target Column 

					/*if(sType.equals(ConstantsUtil.TYPE_PGPHASE)){
					 sSubTotal = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);
					 sSubTUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
					 sIngrLoss = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
					 sIngrLossUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);
					 sTotal = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);

					 sFinalTarget ="Subtotal: "+sSubTotal+" "+sSubTUOM+" Ingredient Loss: "+sIngrLoss+" "+sIngrLossUOM+" Total: "+sTotal;

					//Child
					 sChildTarget = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
					 sMax = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
					 sUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
					 sMaterialFunc = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
					 sPosIndicator = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
					 sPhaseAttrCmt = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
					 sAttrCmt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT));
					 sTotalBatch = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
					 sTBUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
					 sAttrCmt = sPhaseAttrCmt + "Ingridient Loss Comment :"+sAttrCmt;
					 sFinalBatch  ="Target: "+sTotalBatch+" Range Min: "+sMin +" Range Max  "+sMax+" UOM: "+sTBUOM;
					}*/
					String	strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));

					/*if (util.isModificatinRequired()) {
						// Formulation part does not have ownership on itself,
						// hence expand to get it from the Cosmetic formulation
						if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaPropagate = util.getFormulaPropagate(context, sOid);
						}

						if (!sFormulaPropagate.isEmpty()) {
							bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
						}
						if (!bHasOwnership) {
							sOid = ConstantsUtil.NO_ACCESS;
							sDispType=ConstantsUtil.NO_ACCESS;
							sChg = ConstantsUtil.NO_ACCESS;
							sSAPDesc = ConstantsUtil.NO_ACCESS;
							sFileDesc = ConstantsUtil.NO_ACCESS;
							sSpecSubType = ConstantsUtil.NO_ACCESS;
							sSubstitute = ConstantsUtil.NO_ACCESS;
							sMin = ConstantsUtil.NO_ACCESS;
							sFinalTarget = ConstantsUtil.NO_ACCESS;
							sMax = ConstantsUtil.NO_ACCESS;
							sUOM = ConstantsUtil.NO_ACCESS;
							sMaterialFunc = ConstantsUtil.NO_ACCESS;
							sPosIndicator = ConstantsUtil.NO_ACCESS;
							sAttrCmt = ConstantsUtil.NO_ACCESS;
							sTBUOM = ConstantsUtil.NO_ACCESS;
						}
					} else {

						StringList slHIRTypes = new StringList();

						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

						boolean showData = true;
						if (slHIRTypes.contains(sType)) {

							String sFormulaClassif = strClassFied;

							if (!sec.isExternalUser()) {
								if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
									sFormulaClassif = util.getFormulaPropagateClassification(context, sOid);
								}
								if (null != sUserlicense && null != sFormulaClassif
										&& !sUserlicense.contains(sFormulaClassif)) {
									showData = false;
								}
							}

							if (!showData) {
								sOid = ConstantsUtil.NO_ACCESS;
								sDispType=ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
								sSAPDesc = ConstantsUtil.NO_ACCESS;
								sFileDesc = ConstantsUtil.NO_ACCESS;
								sSpecSubType = ConstantsUtil.NO_ACCESS;
								sSubstitute = ConstantsUtil.NO_ACCESS;
								sMin = ConstantsUtil.NO_ACCESS;
								sFinalTarget = ConstantsUtil.NO_ACCESS;
								sMax = ConstantsUtil.NO_ACCESS;
								sUOM = ConstantsUtil.NO_ACCESS;
								sMaterialFunc = ConstantsUtil.NO_ACCESS;
								sPosIndicator = ConstantsUtil.NO_ACCESS;
								sAttrCmt = ConstantsUtil.NO_ACCESS;
								sTBUOM = ConstantsUtil.NO_ACCESS;
							}

						}
					}*/
					//Added by Ganesh start
					showData = util.checkHasAccess(context, null, sId);
					if (!showData) {

						sId = ConstantsUtil.NO_ACCESS;
						sChg = ConstantsUtil.NO_ACCESS;

						/*sOid = ConstantsUtil.NO_ACCESS;
						sDispType=ConstantsUtil.NO_ACCESS;
						sChg = ConstantsUtil.NO_ACCESS;
						sSAPDesc = ConstantsUtil.NO_ACCESS;
						sFileDesc = ConstantsUtil.NO_ACCESS;
						sSpecSubType = ConstantsUtil.NO_ACCESS;
						sSubstitute = ConstantsUtil.NO_ACCESS;
						sMin = ConstantsUtil.NO_ACCESS;
						sFinalTarget = ConstantsUtil.NO_ACCESS;
						sMax = ConstantsUtil.NO_ACCESS;
						sUOM = ConstantsUtil.NO_ACCESS;
						sMaterialFunc = ConstantsUtil.NO_ACCESS;
						sPosIndicator = ConstantsUtil.NO_ACCESS;
						sAttrCmt = ConstantsUtil.NO_ACCESS;
						sTBUOM = ConstantsUtil.NO_ACCESS;*/
					}
					//Added by Ganesh stop

					util.formatData(sbEBOMId, sOid);
					util.formatData(sbEBOMType, sType);
					util.formatData(sbEBOMDisplayType, sDispType);
					util.formatData(sbEBOMName, sName);
					util.formatData(sbEBOMChg, sChg);
					util.formatData(sbEBOMSapDes, sSAPDesc);
					util.formatData(sbEBOMFileDesc, sFileDesc);
					util.formatData(sbEBOMSpecSubType, sSpecSubType);
					util.formatData(sbEBOMSubStitute, sSubstitute);
					util.formatData(sbEBOMMin, sMin);
					util.formatData(sbEBOMTarget, sFinalTarget);
					util.formatData(sbEBOMMax, sMax);
					util.formatData(sbEBOMUOM, sUOM);
					util.formatData(sbEBOMMaterialFunc, sMaterialFunc);
					util.formatData(sbEBOMPosIndicator, sPosIndicator);
					util.formatData(sbEBOMCmt,sAttrCmt);
					util.formatData(sbEBOMBatch,sTBUOM);

				}

				mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbEBOMSapDes.toString());
				mpEBOMResult.put(ConstantsUtil.FILEDESCRIPTION, sbEBOMFileDesc.toString());
				mpEBOMResult.put(ConstantsUtil.SS, sbEBOMSpecSubType.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sbEBOMDisplayType.toString());
				mpEBOMResult.put(ConstantsUtil.SUB, sbEBOMSubStitute.toString());
				mpEBOMResult.put(ConstantsUtil.MIN, sbEBOMMin.toString());
				mpEBOMResult.put(ConstantsUtil.TARGET, sbEBOMTarget.toString());
				mpEBOMResult.put(ConstantsUtil.MAX, sbEBOMMax.toString());
				mpEBOMResult.put(ConstantsUtil.UOM, sbEBOMUOM.toString());
				mpEBOMResult.put(ConstantsUtil.MF, sbEBOMMaterialFunc.toString());
				mpEBOMResult.put(ConstantsUtil.PI, sbEBOMPosIndicator.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENT, sbEBOMCmt.toString());
				mpEBOMResult.put(ConstantsUtil.BATCH, sbEBOMBatch.toString());

				mpFinalEBOM.put(String.valueOf(index), mpEBOMResult);
				mpFinalSubstitute.put(String.valueOf(index), mpSubstituteResult);
				index++;
			}

			MPFinalEBOMSubStitute.put(ConstantsUtil.BILLOFMATERIALS, mpFinalEBOM);
			MPFinalEBOMSubStitute.put(ConstantsUtil.SUBSTITUTEPARTS, mpFinalSubstitute);
			MPFinalEBOMSubStitute.put(ConstantsUtil.HEADER, mpHeaderEBOMResult);

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in FormulaCardBO:  getPhaseBOM: " + e);
		}
		return MPFinalEBOMSubStitute;

		//return util.filterMapList(mFinal);
	}

	//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
	/**
	 * Method Name : parseMaplist Method Description :
	 * 
	 * @param context
	 * @param mlEBOMList
	 * @return
	 */
	public Map<String, String> parseMaplist(Context context, MapList mlEBOMList, Map resultMap) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		Map MPFinalEBOMSubStitute = new TreeMap();
		Map mpFinalEBOM = new TreeMap();
		Map mpFinalSubstitute = new TreeMap();

		StringValidatorUtil validator = new StringValidatorUtil();

		StringBuilder sbEBOMBaseQty = new StringBuilder();
		StringBuilder sbEBOMFilBaseQty = new StringBuilder();
		StringBuilder sbEBOMBaseUOM = new StringBuilder();
		//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
		int index=1;
		StringBuilder sbFEBOMId = new StringBuilder();
		StringBuilder sbFEBOMType = new StringBuilder();
		StringBuilder sbFEBOMDisplayType = new StringBuilder();
		StringBuilder sbFEBOMName = new StringBuilder();
		StringBuilder sbFEBOMChg = new StringBuilder();
		StringBuilder sbFEBOMSapDes = new StringBuilder();
		StringBuilder sbFEBOMFileDesc = new StringBuilder();
		StringBuilder sbFEBOMSpecSubType = new StringBuilder();
		StringBuilder sbFEBOMSubStitute = new StringBuilder();
		StringBuilder sbFEBOMMin = new StringBuilder();
		StringBuilder sbFEBOMTarget = new StringBuilder();
		StringBuilder sbFEBOMMax = new StringBuilder();
		StringBuilder sbFEBOMUOM = new StringBuilder();
		StringBuilder sbFEBOMMaterialFunc = new StringBuilder();
		StringBuilder sbFEBOMPosIndicator = new StringBuilder();
		StringBuilder sbFEBOMCmt = new StringBuilder();
		StringBuilder sbFEBOMBatch = new StringBuilder();
		MapList mlEBOMSubList = new MapList();
		//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS

		Iterator objectListItr = mlEBOMList.iterator();
		Map<String, String> mpHeaderEBOMResult = new HashMap<String, String>();
		try 
		{

			String sHeaderBOMBaseQty = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			String sHeaderFilBaseQty = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
			String sHeaderBaseUOM = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);

			util.formatData(sbEBOMBaseQty, sHeaderBOMBaseQty);
			util.formatData(sbEBOMFilBaseQty, sHeaderFilBaseQty);
			util.formatData(sbEBOMBaseUOM, sHeaderBaseUOM);

			mpHeaderEBOMResult.put(ConstantsUtil.BASEQUANTITY, sbEBOMBaseQty.toString());
			mpHeaderEBOMResult.put(ConstantsUtil.FILEBASEBOMQTY, sbEBOMFilBaseQty.toString());
			mpHeaderEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBaseUOM.toString());

			Map objectMap = null;
			Map<String, String> mpSubstituteResult = null;
			Map<String, String> mpEBOMResult = null;
			MapList mlPhaseEBOMList = null;
			int iParentLevel = 0;
			StringList slParentId = new StringList();
			String sParentId = ConstantsUtil.EMPTY_STRING;

			for(int i =0; i<mlEBOMList.size(); i++)
			{
				objectMap = (Map) mlEBOMList.get(i);
				iParentLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));

				mpSubstituteResult = new HashMap<String, String>();
				mpEBOMResult = new HashMap<String, String>();
				mlPhaseEBOMList = new MapList();
				sParentId = ConstantsUtil.EMPTY_STRING;

				StringBuilder sbEBOMId = new StringBuilder();
				StringBuilder sbEBOMType = new StringBuilder();
				StringBuilder sbEBOMDisplayType = new StringBuilder();
				StringBuilder sbEBOMName = new StringBuilder();
				StringBuilder sbEBOMChg = new StringBuilder();
				StringBuilder sbEBOMSapDes = new StringBuilder();
				StringBuilder sbEBOMFileDesc = new StringBuilder();
				StringBuilder sbEBOMSpecSubType = new StringBuilder();
				StringBuilder sbEBOMSubStitute = new StringBuilder();
				StringBuilder sbEBOMMin = new StringBuilder();
				StringBuilder sbEBOMTarget = new StringBuilder();
				StringBuilder sbEBOMMax = new StringBuilder();
				StringBuilder sbEBOMUOM = new StringBuilder();
				StringBuilder sbEBOMMaterialFunc = new StringBuilder();
				StringBuilder sbEBOMPosIndicator = new StringBuilder();
				StringBuilder sbEBOMCmt = new StringBuilder();
				StringBuilder sbEBOMBatch = new StringBuilder();

				StringList slSelects= new StringList();
				slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
				slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
				slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);

				String sPId = (String) objectMap.get(ConstantsUtil.SELECT_ID);

				DomainObject doFPhaseID = new DomainObject() ;

				String sPType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sPName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
				String sSAPDesc =sDesc;
				String sPFileDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				//SPEC: <02.16.2021>: Sumit Added for Defect :39172 ## --START
				sSAPDesc = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				if(!sPType.equals(ConstantsUtil.TYPE_PGPHASE))
					sPFileDesc=sSAPDesc;
				//SPEC: <02.16.2021>: Sumit Added for Defect :39172 ## --ENDS
				String sDispType="";
				String sSpecSubType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);

				sSpecSubType ="";

				String sSubstitute = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));

				String sMin = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);

				//Target Column 
				String sSubTotal = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);
				String sSubTUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
				String sIngrLoss = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
				String sIngrLossUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);

				String sPhaseQTY =ConstantsUtil.EMPTY_STRING;
				String sPhaseUOM =ConstantsUtil.EMPTY_STRING;
				String sTotal =ConstantsUtil.EMPTY_STRING;
				String sPhaseAttrCmt =ConstantsUtil.EMPTY_STRING;
				String sFinalTarget =ConstantsUtil.EMPTY_STRING;

				if(UIUtil.isNotNullAndNotEmpty(sPId) && sPType.equals(ConstantsUtil.TYPE_PGPHASE))
				{
					doFPhaseID = new DomainObject(sPId);
					Map mpQTYVals = doFPhaseID.getInfo(context, slSelects);
					sPhaseQTY = (String) mpQTYVals.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
					sPhaseUOM = (String) mpQTYVals.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
					sPhaseAttrCmt = (String) mpQTYVals.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
					sTotal = sPhaseUOM;

					sFinalTarget ="Subtotal: "+sSubTotal+" "+sSubTUOM+"\n Ingredient Loss: "+sIngrLoss+" "+sIngrLossUOM+"\n Total: "+sPhaseQTY +" "+sTotal;
				}

				//Child
				String sChildTarget = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
				if(!sPType.equals(ConstantsUtil.TYPE_PGPHASE)) {
					sFinalTarget=sChildTarget;
				}
				String sMax = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
				String sUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
				String sMaterialFunc = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
				String sTotalBatch = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
				String sTBUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
				String sPosIndicator = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
				String sAttrCmt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT));
				sAttrCmt = sPhaseAttrCmt + "\n Ingredient Loss Comment :"+sAttrCmt;
				doFPhaseID = new DomainObject(sPId);
				String sRangeMax = (String) doFPhaseID.getAttributeValue(context, ConstantsUtil.ATTRIBUTE_PGMAXQUANTITY); 
				String sRangeMin = (String) doFPhaseID.getAttributeValue(context, ConstantsUtil.ATTRIBUTE_PGMINQUANTITY); 

				String sFinalBatch  ="Target: "+sTotalBatch+"\n Range Min: "+sRangeMin +"\n Range Max:  "+sRangeMax+"\n Unit Of Measure: "+sTBUOM;
				//<SPEC> 06/23/2021- Modified by Madhana for Defect #43781 End 
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doFPhaseID.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				String strClassFiedParent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));

				sMin="";
				sMax="";


				boolean bHasOwnership = false;
				String sFormulaPropagate = sPId;

				boolean showData = util.checkHasAccess(context, null, sPId);
				if (!showData) {

					sPId = ConstantsUtil.NO_ACCESS;
					sChg = ConstantsUtil.NO_ACCESS;
				}
				//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
				mlPhaseEBOMList.add(objectMap);
				if(!sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1) {

					util.formatData(sbFEBOMId, sPId);
					util.formatData(sbFEBOMType, sPType);
					util.formatData(sbFEBOMDisplayType, sDispType);
					util.formatData(sbFEBOMName, sPName);
					util.formatData(sbFEBOMChg, sChg);
					util.formatData(sbFEBOMSapDes, sSAPDesc);
					util.formatData(sbFEBOMFileDesc, sPFileDesc);
					util.formatData(sbFEBOMSpecSubType, sSpecSubType);
					util.formatData(sbFEBOMSubStitute, sSubstitute);
					util.formatData(sbFEBOMMin, sMin);
					util.formatData(sbFEBOMTarget, sFinalTarget);
					util.formatData(sbFEBOMMax, sMax);
					util.formatData(sbFEBOMUOM, sUOM);
					util.formatData(sbFEBOMMaterialFunc, sMaterialFunc);
					util.formatData(sbFEBOMPosIndicator, sPosIndicator);
					util.formatData(sbFEBOMCmt,sAttrCmt);
					util.formatData(sbFEBOMBatch,sFinalBatch);

					if(!mlPhaseEBOMList.isEmpty()) {
						mlEBOMSubList.addAll(mlPhaseEBOMList);
					}

				} else {
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
					util.formatData(sbEBOMId, sPId);
					util.formatData(sbEBOMType, sPType);
					util.formatData(sbEBOMDisplayType, sDispType);
					util.formatData(sbEBOMName, sPName);
					util.formatData(sbEBOMChg, sChg);
					util.formatData(sbEBOMSapDes, sSAPDesc);
					util.formatData(sbEBOMFileDesc, sPFileDesc);
					util.formatData(sbEBOMSpecSubType, sSpecSubType);
					util.formatData(sbEBOMSubStitute, sSubstitute);
					util.formatData(sbEBOMMin, sMin);
					util.formatData(sbEBOMTarget, sFinalTarget);
					util.formatData(sbEBOMMax, sMax);
					util.formatData(sbEBOMUOM, sUOM);
					util.formatData(sbEBOMMaterialFunc, sMaterialFunc);
					util.formatData(sbEBOMPosIndicator, sPosIndicator);
					util.formatData(sbEBOMCmt,sAttrCmt);
					util.formatData(sbEBOMBatch,sFinalBatch);
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
				}
				//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS

				int j = 0;
				int iNextLevel = 0;
				Map objectMaps =null;
				//SPEC: <02.02.2021>: Modified for Defect: 38357 by Sumit --START
				//if(sPType.equals(ConstantsUtil.TYPE_PGPHASE) || iParentLevel == 1){
				if(sPType.equals(ConstantsUtil.TYPE_PGPHASE)){
					sParentId=sFormulaPropagate;
					//SPEC: <02.02.2021>: Modified for Defect: 38357 by Sumit --ENDS

					for(j =i+1; j<mlEBOMList.size(); j++)
					{
						iNextLevel = 0;
						objectMaps = (Map) mlEBOMList.get(j);
						int iCurrLevel = Integer.parseInt((String) objectMaps.get(ConstantsUtil.SELECT_LEVEL));
						if(j < mlEBOMList.size()-1) {
							Map objectNxtMaps = (Map) mlEBOMList.get(j+1);
							iNextLevel = Integer.parseInt((String) objectNxtMaps.get(ConstantsUtil.SELECT_LEVEL));
						}
						if((iParentLevel+1 == iCurrLevel) && sPType.equals(ConstantsUtil.TYPE_PGPHASE)) {

							mlPhaseEBOMList.add(objectMaps);
							String sType = (String) objectMaps.get(ConstantsUtil.SELECT_TYPE);
							String sName = (String) objectMaps.get(ConstantsUtil.SELECT_NAME);
							String sOid = (String) objectMaps.get(ConstantsUtil.SELECT_ID);
							sChg = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
							sSAPDesc = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							String sFileDesc = (String) objectMaps.get(ConstantsUtil.SELECT_DESCRIPTION);
							if(!sType.equals(ConstantsUtil.TYPE_PGPHASE)){
								sDispType =getMappedType(sType);
								sSpecSubType = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
								String strAttrPgCSSType = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
								// Guna Modified for Defect 38208  18x.5.2 Release -- START
								sSpecSubType = getSpecificationSubtype(context, sType, sSpecSubType, strAttrPgCSSType,sOid);
								// Guna Modified for Defect 38208  18x.5.2 Release -- END
								//SPEC: <02.16.2021>: Sumit Added for Defect :39172 ## --START
								sFileDesc=sSAPDesc;
								//SPEC: <02.16.2021>: Sumit Added for Defect :39172 ## --ENDS
							}else{
								sDispType="Fil";
								sSpecSubType="";
							}

							sSubstitute = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.SELECT_SUBSTITUTE));

							sMin = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
							sChildTarget = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
							sMax = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
							sUOM = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);

							//sMaterialFunc = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
							sMaterialFunc = validator.getStringEquivalentForSubstituteString(objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION));
							sPosIndicator = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
							//sAttrCmt = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
							sAttrCmt = validator.getStringEquivalentForSubstituteString(objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
							sTBUOM = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
							sFinalTarget=sChildTarget;

							String	strClassFied = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.STR_IPCLASS));

							showData = util.checkHasAccess(context, null, sOid);
							if (!showData) {

								sOid = ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
							}

							util.formatData(sbEBOMId, sOid);
							util.formatData(sbEBOMType, sType);
							util.formatData(sbEBOMDisplayType, sDispType);
							util.formatData(sbEBOMName, sName);
							util.formatData(sbEBOMChg, sChg);
							util.formatData(sbEBOMSapDes, sSAPDesc);
							util.formatData(sbEBOMFileDesc, sFileDesc);
							util.formatData(sbEBOMSpecSubType, sSpecSubType);
							util.formatData(sbEBOMSubStitute, sSubstitute);
							util.formatData(sbEBOMMin, sMin);
							util.formatData(sbEBOMTarget, sFinalTarget);
							util.formatData(sbEBOMMax, sMax);
							util.formatData(sbEBOMUOM, sUOM);
							util.formatData(sbEBOMMaterialFunc, sMaterialFunc);
							util.formatData(sbEBOMPosIndicator, sPosIndicator);
							util.formatData(sbEBOMCmt,sAttrCmt);
							util.formatData(sbEBOMBatch,sTBUOM);

						}
						//SPEC: <01.21.2021>: Modified for Defect : 38181 by Sumit --START
						if(iParentLevel+1 > iNextLevel || iParentLevel == iCurrLevel) {
							//SPEC: <01.21.2021>: Added for Defect : 38181 by Sumit --ENDS	
							break;
						}
					}

					//Get Substitutes
					//SPEC: <02.02.2021>: Commented for Defect: 38357 by Sumit --START
					//mpSubstituteResult = getFormulaCardSubstitutes(context,mlPhaseEBOMList,sPName,sPFileDesc,sPId,sPType);
					//SPEC: <02.02.2021>: Commented for Defect: 38357 by Sumit --START
					mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
					mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
					mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
					mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbEBOMSapDes.toString());
					mpEBOMResult.put(ConstantsUtil.FILEDESCRIPTION, sbEBOMFileDesc.toString());
					mpEBOMResult.put(ConstantsUtil.SS, sbEBOMSpecSubType.toString());
					mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
					mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sbEBOMDisplayType.toString());
					mpEBOMResult.put(ConstantsUtil.SUB, sbEBOMSubStitute.toString());
					mpEBOMResult.put(ConstantsUtil.MIN, sbEBOMMin.toString());
					mpEBOMResult.put(ConstantsUtil.TARGET, sbEBOMTarget.toString());
					mpEBOMResult.put(ConstantsUtil.MAX, sbEBOMMax.toString());
					mpEBOMResult.put(ConstantsUtil.UOM, sbEBOMUOM.toString());
					mpEBOMResult.put(ConstantsUtil.MF, sbEBOMMaterialFunc.toString());
					mpEBOMResult.put(ConstantsUtil.PI, sbEBOMPosIndicator.toString());
					mpEBOMResult.put(ConstantsUtil.COMMENT, sbEBOMCmt.toString());
					mpEBOMResult.put(ConstantsUtil.BATCH, sbEBOMBatch.toString());

				}
				//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --START
				if(!mpEBOMResult.isEmpty() && validator.isNotNullOrEmpty(sParentId) && (!slParentId.contains(sParentId) || (slParentId.contains(sParentId) && !sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1))) {
					//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --ENDS
					slParentId.add(sParentId);
					mpFinalEBOM.put(String.valueOf(index), mpEBOMResult);
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
					mpSubstituteResult = getFormulaCardSubstitutes(context,mlPhaseEBOMList,sPName,sPFileDesc,sPId,sPType);
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
					if(!mpSubstituteResult.isEmpty()) {
						mpFinalSubstitute.put(String.valueOf(index), mpSubstituteResult);
					}
					index++;
				}
			}
			//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
			mpEBOMResult = new HashMap();
			if(null != sbFEBOMId && sbFEBOMId.length()>0) {
				mpEBOMResult.put(ConstantsUtil.ID, sbFEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbFEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbFEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbFEBOMSapDes.toString());
				mpEBOMResult.put(ConstantsUtil.FILEDESCRIPTION, sbFEBOMFileDesc.toString());
				mpEBOMResult.put(ConstantsUtil.SS, sbFEBOMSpecSubType.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbFEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sbFEBOMDisplayType.toString());
				mpEBOMResult.put(ConstantsUtil.SUB, sbFEBOMSubStitute.toString());
				mpEBOMResult.put(ConstantsUtil.MIN, sbFEBOMMin.toString());
				mpEBOMResult.put(ConstantsUtil.TARGET, sbFEBOMTarget.toString());
				mpEBOMResult.put(ConstantsUtil.MAX, sbFEBOMMax.toString());
				mpEBOMResult.put(ConstantsUtil.UOM, sbFEBOMUOM.toString());
				mpEBOMResult.put(ConstantsUtil.MF, sbFEBOMMaterialFunc.toString());
				mpEBOMResult.put(ConstantsUtil.PI, sbFEBOMPosIndicator.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENT, sbFEBOMCmt.toString());
				mpEBOMResult.put(ConstantsUtil.BATCH, sbFEBOMBatch.toString());

				if(!mpEBOMResult.isEmpty()) {
					mpFinalEBOM.put(String.valueOf(0), mpEBOMResult);
				}
			}
			//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS

			MPFinalEBOMSubStitute.put(ConstantsUtil.BILLOFMATERIALS, mpFinalEBOM);
			MPFinalEBOMSubStitute.put(ConstantsUtil.SUBSTITUTEPARTS, mpFinalSubstitute);
			MPFinalEBOMSubStitute.put(ConstantsUtil.HEADER, mpHeaderEBOMResult);

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in FormulaCardBO:  parseMaplist: " + e);
		}
		return MPFinalEBOMSubStitute;
	}
	//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --ENDS

	/* * Getting the Substitutes of Formula Card
	 * @param context
	 * @param mapList
	 * @param sDesc 
	 * @param sFilName 
	 * @return
	 * @throws Exception
	 */

	public Map<String, String> getFormulaCardSubstitutes(Context context, MapList mapList, String sFilName, String sFilDesc,String sFilId, String sFilType) throws Exception 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil  util = new BusObjectAttribUtil();

		Map mpFinal = new TreeMap();

		try 
		{

			Iterator objectListItr = mapList.iterator();
			int j=0;
			while (objectListItr.hasNext()) 
			{
				Map<String, String> mpEBOMResult = new HashMap<String, String>();
				StringBuilder sbSubPartType = new StringBuilder();
				StringBuilder sbSubPartDisplayType = new StringBuilder();
				StringBuilder sbSubPartName = new StringBuilder();
				StringBuilder sbSubPartId = new StringBuilder();
				StringBuilder sbSubPartTitle = new StringBuilder();
				StringBuilder sbSubPartSpecSubType = new StringBuilder();	
				StringBuilder sbSubPartValidUntiltDt = new StringBuilder();
				StringBuilder sbSubstituteMinQTY = new StringBuilder();
				StringBuilder sbSubstituteChg = new StringBuilder();
				StringBuilder sbSubstituteSCN = new StringBuilder();
				StringBuilder sbSubstituteMaxQTY = new StringBuilder();
				StringBuilder sbSubstituteTarget = new StringBuilder();
				StringBuilder sbSubstituteUOM = new StringBuilder();
				StringBuilder sbSubstitutePI = new StringBuilder();	
				StringBuilder sbSubstituteMF = new StringBuilder();
				StringBuilder sbSubstituteCMT = new StringBuilder();

				StringBuilder sbFilType = new StringBuilder();
				StringBuilder sbFilID = new StringBuilder();
				StringBuilder sbFilName = new StringBuilder();
				StringBuilder sbFilDesc = new StringBuilder();
				StringBuilder sbSubForType = new StringBuilder();
				StringBuilder sbSubForName = new StringBuilder();
				StringBuilder sbSubForId = new StringBuilder();
				StringBuilder sbSubForDesc = new StringBuilder();

				Map objectMap = (Map) objectListItr.next();

				if (objectMap.containsKey(ConstantsUtil.SELECT_SUBSTITUTE))
				{
					if (!objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME)) {
						continue;
					}

					String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME).getClass().getSimpleName();
					if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
					{

						String sSubstituteForPartId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sSubstituteForPartType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
						String sSubstituteForPartName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String sSubstituteForPartTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));

						String sSubstitutePartId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
						String sSubstituteType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
						String sSubstituteName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));

						String sSubstituteChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
						String sSubstituteSCN=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
						String sSubstituteTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));

						String sSubstituteDisplayType =getMappedType(sSubstituteType.trim());
						//SPEC: <01.21.2021>: Added for Defect : 38182 by Sumit --START
						sSubstituteType=util.mapType(sSubstituteType);
						//SPEC: <01.21.2021>: Added for Defect : 38182 by Sumit --ENDS
						String sSubstituteAssemblyType =getSpecificationSubtypeForSubstitutes(context,sSubstitutePartId,sSubstituteType);

						String sSubstituteMinQty =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY));
						String sSubstituteTarget=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET));
						String sSubstituteMaxQty =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY));

						//Modified by Jwala for the defect 44140 - START
						//String sSubstituteUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM));
						String sSubstituteUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
						//Modified by Jwala for the defect 44140 - END

						String sSubstitutePI =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR));
						String sSubstituteMF =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION));

						String sSubstituteValidDate =validator.DateFormatter(validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
						String sSubstituteComment =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));

						boolean bSubstituteHasAccess = util.checkHasAccess(context,null,sSubstitutePartId);

						if(!bSubstituteHasAccess) {
							sSubstitutePartId    = ConstantsUtil.NO_ACCESS;
							sSubstituteChg = ConstantsUtil.NO_ACCESS;
						}

						util.formatData(sbSubPartId, sSubstitutePartId);
						util.formatData(sbSubPartName, sSubstituteName);
						util.formatData(sbSubPartTitle, sSubstituteTitle);
						util.formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
						util.formatData(sbSubPartValidUntiltDt, sSubstituteValidDate);
						util.formatData(sbSubstituteChg, sSubstituteChg);

						util.formatData(sbFilName, sFilName);
						util.formatData(sbFilDesc, sFilDesc);
						util.formatData(sbFilType, sFilType);
						util.formatData(sbFilID, sFilId);
						util.formatData(sbSubForDesc, sSubstituteForPartTitle);
						util.formatData(sbSubForId, sSubstituteForPartId);
						util.formatData(sbSubForType, sSubstituteForPartType);
						util.formatData(sbSubForName, sSubstituteForPartName);

						util.formatData(sbSubPartDisplayType, sSubstituteDisplayType);
						util.formatData(sbSubPartType, sSubstituteType);
						util.formatData(sbSubstituteMinQTY, sSubstituteMinQty);
						util.formatData(sbSubstituteSCN, sSubstituteSCN);
						util.formatData(sbSubstituteMaxQTY, sSubstituteMaxQty);
						util.formatData(sbSubstituteTarget, sSubstituteTarget);
						util.formatData(sbSubstituteUOM, sSubstituteUOM);
						util.formatData(sbSubstitutePI, sSubstitutePI);
						util.formatData(sbSubstituteMF, sSubstituteMF);
						util.formatData(sbSubstituteCMT, sSubstituteComment);


						mpEBOMResult.put(ConstantsUtil.HEADERSAPDESC, sbSubForDesc.toString());
						mpEBOMResult.put(ConstantsUtil.USEDINFORMULATION, sbFilName.toString());
						mpEBOMResult.put(ConstantsUtil.FIL_TYPE, sbFilType.toString());
						mpEBOMResult.put(ConstantsUtil.FIL_ID, sbFilID.toString());
						mpEBOMResult.put(ConstantsUtil.FILDESC, sbFilDesc.toString());
						mpEBOMResult.put(ConstantsUtil.SF_ID, sbSubForId.toString());
						mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbSubForType.toString());
						mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbSubForName.toString());

						mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sbSubPartDisplayType.toString());
						mpEBOMResult.put(ConstantsUtil.TYPE, sbSubPartType.toString());
						mpEBOMResult.put(ConstantsUtil.ID, sbSubPartId.toString());
						mpEBOMResult.put(ConstantsUtil.NAME, sbSubPartName.toString());
						mpEBOMResult.put(ConstantsUtil.CHG, sbSubstituteChg.toString());
						mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbSubPartTitle.toString());
						mpEBOMResult.put(ConstantsUtil.SS, sbSubPartSpecSubType.toString());
						mpEBOMResult.put(ConstantsUtil.COMBINATIONNUMBER, sbSubstituteSCN.toString());
						mpEBOMResult.put(ConstantsUtil.MIN, sbSubstituteMinQTY.toString());
						mpEBOMResult.put(ConstantsUtil.TARGET, sbSubstituteTarget.toString());
						mpEBOMResult.put(ConstantsUtil.MAX, sbSubstituteMaxQTY.toString());
						mpEBOMResult.put(ConstantsUtil.UOM, sbSubstituteUOM.toString());
						mpEBOMResult.put(ConstantsUtil.MF, sbSubstituteMF.toString());
						mpEBOMResult.put(ConstantsUtil.PI, sbSubstitutePI.toString());
						mpEBOMResult.put(ConstantsUtil.VALIDUNTILDATE, sbSubPartValidUntiltDt.toString());
						mpEBOMResult.put(ConstantsUtil.COMMENTS, sbSubstituteCMT.toString());
						mpFinal.put(j, util.filterMapList(mpEBOMResult));
						j++;
					}else
					{

						String sSubstituteForPartId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sSubstituteForPartType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
						String sSubstituteForPartName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String sSubstituteForPartTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));

						StringList slSubstituteId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
						StringList slSubstituteType = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
						StringList slSubstituteName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
						StringList slSubstituteChg=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
						StringList slSubstituteSCN=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
						StringList slSubstituteTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						StringList slSubstituteMinQty =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY));
						StringList slSubstituteTarget =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET));
						StringList slSubstituteMaxQty =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY));
						StringList slSubstituteUOM =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM));
						StringList slSubstitutePI =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR));
						StringList slSubstituteMF =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION));
						StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
						StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));


						for(int i =0; i<slSubstituteId.size(); i++) 
						{
							String sSubstitutePartId = validator.getStringEquivalentForStringList(slSubstituteId.getElement(i));										
							String sSubstitutePartType=validator.getStringEquivalentForStringList(slSubstituteType.getElement(i));		

							String sSubstituteChg = validator.getStringEquivalentForStringList(slSubstituteChg.getElement(i));										
							String sSubstituteSCN=validator.getStringEquivalentForStringList(slSubstituteSCN.getElement(i));										
							String sSubstituteName =validator.getStringEquivalentForStringList(slSubstituteName.getElement(i));											
							String sSubstituteTitle =validator.getStringEquivalentForStringListWithComma(slSubstituteTitle.getElement(i));								

							String sSubstituteDisplayType =getMappedType(sSubstitutePartType.trim());
							//SPEC: <01.21.2021>: Added for Defect : 38182 by Sumit --START
							sSubstitutePartType=util.mapType(sSubstitutePartType);
							//SPEC: <01.21.2021>: Added for Defect : 38182 by Sumit --ENDS
							String sSubstituteAssemblyType =getSpecificationSubtypeForSubstitutes(context,sSubstitutePartId,sSubstitutePartType);
							String sSubstituteMinQty =validator.getStringEquivalentForStringList(slSubstituteMinQty.getElement(i));										
							String sSubstituteTarget=validator.getStringEquivalentForStringList(slSubstituteTarget.getElement(i));										
							String sSubstituteMaxQty =validator.getStringEquivalentForStringListWithComma(slSubstituteMaxQty.getElement(i));								
							String sSubstituteUOM =validator.getStringEquivalentForStringList(slSubstituteUOM.getElement(i));											
							String sSubstitutePI =validator.getStringEquivalentForStringListWithComma(slSubstitutePI.getElement(i));									
							String sSubstituteMF =validator.getStringEquivalentForStringListWithComma(slSubstituteMF.getElement(i));									
							String sSubstituteValidDate =validator.DateFormatter(validator.getStringEquivalentForStringListWithComma(slUntilDate.getElement(i)));	
							String sSubstituteComment =validator.getStringEquivalentForStringListWithComma(slComments.getElement(i));		

							boolean bSubstituteHasAccess = util.checkHasAccess(context,null,sSubstitutePartId);

							if(!bSubstituteHasAccess) {
								sSubstitutePartId    = ConstantsUtil.NO_ACCESS;
								sSubstituteChg = ConstantsUtil.NO_ACCESS;
							}

							util.formatData(sbSubPartId, sSubstitutePartId);
							util.formatData(sbSubPartTitle, sSubstituteTitle);
							util.formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
							util.formatData(sbSubPartValidUntiltDt, sSubstituteValidDate);
							util.formatData(sbSubstituteChg, sSubstituteChg);

							util.formatData(sbSubPartDisplayType, sSubstituteDisplayType);
							util.formatData(sbSubPartType, sSubstitutePartType);
							util.formatData(sbSubPartName, sSubstituteName);
							util.formatData(sbSubstituteMinQTY, sSubstituteMinQty);
							util.formatData(sbSubstituteSCN, sSubstituteSCN);
							util.formatData(sbSubstituteMaxQTY, sSubstituteMaxQty);
							util.formatData(sbSubstituteTarget, sSubstituteTarget);
							util.formatData(sbSubstituteUOM, sSubstituteUOM);
							util.formatData(sbSubstitutePI, sSubstitutePI);
							util.formatData(sbSubstituteMF, sSubstituteMF);
							util.formatData(sbSubstituteCMT, sSubstituteComment);

						}
						util.formatData(sbSubForDesc, sSubstituteForPartTitle);
						util.formatData(sbFilName, sFilName);
						util.formatData(sbFilDesc, sFilDesc);
						util.formatData(sbFilType, sFilType);
						util.formatData(sbFilID, sFilId);
						util.formatData(sbSubForName, sSubstituteForPartName);
						util.formatData(sbSubForId, sSubstituteForPartId);
						util.formatData(sbSubForType, sSubstituteForPartType);

						mpEBOMResult.put(ConstantsUtil.HEADERSAPDESC, sbSubForDesc.toString());
						mpEBOMResult.put(ConstantsUtil.USEDINFORMULATION, sbFilName.toString());
						mpEBOMResult.put(ConstantsUtil.FIL_TYPE, sbFilType.toString());
						mpEBOMResult.put(ConstantsUtil.FIL_ID, sbFilID.toString());
						mpEBOMResult.put(ConstantsUtil.FILDESC, sbFilDesc.toString());
						mpEBOMResult.put(ConstantsUtil.SF_ID, sbSubForId.toString());
						mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbSubForType.toString());
						mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbSubForName.toString());

						mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sbSubPartDisplayType.toString());
						mpEBOMResult.put(ConstantsUtil.TYPE, sbSubPartType.toString());
						mpEBOMResult.put(ConstantsUtil.ID, sbSubPartId.toString());
						mpEBOMResult.put(ConstantsUtil.NAME, sbSubPartName.toString());
						mpEBOMResult.put(ConstantsUtil.CHG, sbSubstituteChg.toString());
						mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbSubPartTitle.toString());
						mpEBOMResult.put(ConstantsUtil.SS, sbSubPartSpecSubType.toString());
						mpEBOMResult.put(ConstantsUtil.COMBINATIONNUMBER, sbSubstituteSCN.toString());
						mpEBOMResult.put(ConstantsUtil.MIN, sbSubstituteMinQTY.toString());
						mpEBOMResult.put(ConstantsUtil.TARGET, sbSubstituteTarget.toString());
						mpEBOMResult.put(ConstantsUtil.MAX, sbSubstituteMaxQTY.toString());
						mpEBOMResult.put(ConstantsUtil.UOM, sbSubstituteUOM.toString());
						mpEBOMResult.put(ConstantsUtil.MF, sbSubstituteMF.toString());
						mpEBOMResult.put(ConstantsUtil.PI, sbSubstitutePI.toString());
						mpEBOMResult.put(ConstantsUtil.VALIDUNTILDATE, sbSubPartValidUntiltDt.toString());
						mpEBOMResult.put(ConstantsUtil.COMMENTS, sbSubstituteCMT.toString());

						mpFinal.put(j, util.filterMapList(mpEBOMResult));
						j++;


					}


				}

			}

		} catch (Exception e) {
			LOGGER.error("Exception in Formula Card BO: getFormulaSubstitutes : "+ e);
			return new HashMap();
		}
		return mpFinal;
	}






	/**
	 * Getting the Substitutes of Formula Card
	 * @param context
	 * @param mapList
	 * @param sDesc 
	 * @param sFilName 
	 * @return
	 * @throws Exception
	 */

	/*	public Map<String, String> getFormulaCardSubstitutes(Context context, MapList mapList, String sFilName, String sFilDesc) throws Exception 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil  util = new BusObjectAttribUtil();
		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

		StringBuilder sbFilName = new StringBuilder();
		StringBuilder sbFilDesc = new StringBuilder();

		util.formatData(sbFilName, sFilName);
		util.formatData(sbFilDesc, sFilDesc);

		Map mpFinal = new TreeMap();
		try 
		{
			SecurityService sec = new SecurityService();
			String sComp = sec.getUserCauthorities();
			StringList slUserOwnership = util.filterOwnerShip(sComp);
			String sUserlicense = sec.getUserLicense();

			Iterator objectListItr = mapList.iterator();
			int j=0;
			while (objectListItr.hasNext()) 
			{

				Map<String, String> mpEBOMResult = new HashMap<String, String>();
				StringBuilder sbSubPartType = new StringBuilder();
				StringBuilder sbSubPartName = new StringBuilder();
				StringBuilder sbSubPartId = new StringBuilder();
				StringBuilder sbSubPartTitle = new StringBuilder();
				StringBuilder sbSubPartSpecSubType = new StringBuilder();	
				StringBuilder sbSubPartValidUntiltDt = new StringBuilder();
				StringBuilder sbSubstituteMinQTY = new StringBuilder();
				StringBuilder sbSubstituteChg = new StringBuilder();
				StringBuilder sbSubstituteSCN = new StringBuilder();
				StringBuilder sbSubstituteMaxQTY = new StringBuilder();
				StringBuilder sbSubstituteTarget = new StringBuilder();
				StringBuilder sbSubstituteUOM = new StringBuilder();
				StringBuilder sbSubstitutePI = new StringBuilder();	
				StringBuilder sbSubstituteMF = new StringBuilder();
				StringBuilder sbSubstituteCMT = new StringBuilder();


				StringBuilder sbSubForType = new StringBuilder();
				StringBuilder sbSubForName = new StringBuilder();
				StringBuilder sbSubForId = new StringBuilder();
				StringBuilder sbSubForTitle = new StringBuilder();



				Map objectMap = (Map) objectListItr.next();

				if (objectMap.containsKey(ConstantsUtil.SELECT_SUBSTITUTE))
				{
					String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
					String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);


					String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
					boolean isExternal =util.isModificatinRequired(); 
					String sFormulaPropagate =sId;
					if (isExternal)
					{
						if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							 sFormulaPropagate = util.getFormulaPropagate(context, sFormulaPropagate);
						}
						boolean bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
						if (!bHasOwnership) 

						//util.formatData(sbSubForId, ConstantsUtil.NO_ACCESS);
						//util.formatData(sbSubForTitle, ConstantsUtil.NO_ACCESS);

							continue;
					}else if (!isExternal) 
					{
						if (slHIRTypes.contains(sType)) 
						{
							String sFormulaClassif = strClassFied;
							if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
							}

							if (null != sUserlicense && null != sFormulaClassif
									&& !sUserlicense.contains(sFormulaClassif)) {

								//util.formatData(sbSubForId, ConstantsUtil.NO_ACCESS);
								//util.formatData(sbSubForTitle, ConstantsUtil.NO_ACCESS);
								continue;
							}

						}

					}
					String sHasSubstitute = validator.getStringEquivalentForStringList((String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));

					if (sHasSubstitute.contains("No") || sHasSubstitute.contains("NO")) {
						continue;
					}

					util.formatData(sbSubForType, util.mapType(sType));
					util.formatData(sbSubForName, sName);
					util.formatData(sbSubForId, sId);
					util.formatData(sbSubForTitle, sTitle);

					StringList slSubType = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE)));
					StringList sltrValidUntilDt = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
					StringList slSubstituteName = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME)));
					StringList slSubstituteType = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)));
					StringList slSubstituteSCN = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER)));
					StringList slSubstituteMinQTY = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY)));
					StringList slSubstituteMaxQTY = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY)));
					StringList slSubstituteTarget = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET)));
					StringList slSubstituteUOM = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM)));
					StringList slSubstitutePI = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR)));
					StringList slSubstituteMF = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION)));
					//StringList slSubstituteCMT = util.getStringList(validator.getStringEquivalentForSubstituteString(
						//	objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT)));

					StringList slSubstituteCMT = new StringList();

					if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT)){

						String clClass = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT).getClass().getSimpleName();
						if (clClass.equals(ConstantsUtil.STRING)) 
						{
							String sSubstituteCMT = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT))?(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT) : ConstantsUtil.EMPTY_STRING;
							//sSubstituteCMT.replace(",", "&");
							slSubstituteCMT= util.getStringList(sSubstituteCMT);
						}else
						{
							slSubstituteCMT = validator.isNotNullOrEmpty((StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						}

					}

					StringList slSubstituteTitle = new StringList();

				if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE)){

					String clClass = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE).getClass().getSimpleName();
					if (clClass.equals(ConstantsUtil.STRING)) 
					{
						String sSubstituteTitle = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE))?(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE) : ConstantsUtil.EMPTY_STRING;
						slSubstituteTitle=util.getStringList(sSubstituteTitle);
					}else
					{
						slSubstituteTitle = validator.isNotNullOrEmpty((StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
					}

				}

					StringList slSubstitutePart = util.getStringList(validator
							.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID)));
					StringList slSubstitutePartCHG = util.getStringList(validator
							.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG)));

						for (int i = 0; i < slSubstituteName.size(); i++) 
						{
							if (UIUtil.isNotNullAndNotEmpty(sHasSubstitute)
									&& (sHasSubstitute.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)
											|| sHasSubstitute.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE))) 
							{
								String sSubstituteAssemblyType = util.getValueFromStringList(slSubType,i);
								String sSubstituteUntilDate = util.getValueFromStringList(sltrValidUntilDt,i);
								String sSubstituteName = util.getValueFromStringList(slSubstituteName,i);
								String sSubstituteType = util.getValueFromStringList(slSubstituteType,i);
								String sSubstituteTitle = util.getValueFromStringList(slSubstituteTitle,i);
								String sSubstitutePartId = util.getValueFromStringList(slSubstitutePart,i);

								String sSubstituteMinQTY = util.getValueFromStringList(slSubstituteMinQTY,i);
								String sSubstituteSCN = util.getValueFromStringList(slSubstituteSCN,i);
								String sSubstituteMaxQTY = util.getValueFromStringList(slSubstituteMaxQTY,i);
								String sSubstituteTarget = util.getValueFromStringList(slSubstituteTarget,i);
								String sSubstituteUOM = util.getValueFromStringList(slSubstituteUOM,i);
								String sSubstitutePI = util.getValueFromStringList(slSubstitutePI,i);
								String sSubstituteMF = util.getValueFromStringList(slSubstituteMF,i);
								String sSubstituteCMT = util.getValueFromStringList(slSubstituteCMT,i);
								String sSubstituteChg = util.getValueFromStringList(slSubstitutePartCHG,i);

								sSubstituteType = util.mapType(sSubstituteType);

								util.formatData(sbSubPartType, sSubstituteType);
								util.formatData(sbSubPartName, sSubstituteName);


								boolean bSubstuteHasAccess = false;
								if (isExternal)
								{
									if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										sSubstitutePartId = util.getFormulaPropagate(context, sSubstitutePartId);
									}
									bSubstuteHasAccess = util.checkOwnerShip(context, slUserOwnership, sSubstitutePartId);
									if (!bSubstuteHasAccess) 

										util.formatData(sbSubPartId, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubPartTitle, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubPartSpecSubType, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubPartValidUntiltDt, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteChg, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteMinQTY, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteSCN, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteMaxQTY, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteTarget, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteUOM, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstitutePI, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteMF, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteCMT, ConstantsUtil.NO_ACCESS);

										continue;
								}else if (!isExternal) 
								{
									if (slHIRTypes.contains(sType)) 
									{
										DomainObject dobSubstitute = new DomainObject(sSubstitutePartId);
										String sSubstituteIPClass = validator.getStringEquivalentForStringList(
												objectMap.get(ConstantsUtil.STR_IPCLASS));

										String sSubFormulalassif = sSubstituteIPClass;
										if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
											sSubFormulalassif = util.getFormulaPropagateClassification(context, sSubstitutePartId);
										}

										if (null != sUserlicense && null != sSubFormulalassif
												&& !sUserlicense.contains(sSubFormulalassif))
										{
											util.formatData(sbSubPartId, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubPartTitle, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubPartSpecSubType, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubPartValidUntiltDt, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteChg, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteMinQTY, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteSCN, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteMaxQTY, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteTarget, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteUOM, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstitutePI, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteMF, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteCMT, ConstantsUtil.NO_ACCESS);

											continue;
										}

									}

								}

								util.formatData(sbSubPartId, sSubstitutePartId);
								util.formatData(sbSubPartTitle, sSubstituteTitle);
								util.formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
								util.formatData(sbSubPartValidUntiltDt, sSubstituteUntilDate);

								util.formatData(sbSubstituteChg, sSubstituteChg);
								util.formatData(sbFilName, sFilName);
								util.formatData(sbFilDesc, sFilDesc);
								util.formatData(sbSubstituteMinQTY, sSubstituteMinQTY);
								util.formatData(sbSubstituteSCN, sSubstituteSCN);
								util.formatData(sbSubstituteMaxQTY, sSubstituteMaxQTY);
								util.formatData(sbSubstituteTarget, sSubstituteTarget);
								util.formatData(sbSubstituteUOM, sSubstituteUOM);
								util.formatData(sbSubstitutePI, sSubstitutePI);
								util.formatData(sbSubstituteMF, sSubstituteMF);
								util.formatData(sbSubstituteCMT, sSubstituteCMT);

							}

						}
				} 

				mpEBOMResult.put(ConstantsUtil.SF_ID, sbSubForId.toString());
				mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbSubForType.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbSubForName.toString());
				mpEBOMResult.put(ConstantsUtil.USEDINFORMULATION, sFilName.toString());
				mpEBOMResult.put(ConstantsUtil.HEADERSAPDESC, sbSubForTitle.toString());
				mpEBOMResult.put(ConstantsUtil.FILDESC, sFilDesc.toString());

				mpEBOMResult.put(ConstantsUtil.TYPE, sbSubPartType.toString());
				mpEBOMResult.put(ConstantsUtil.ID, sbSubPartId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbSubPartName.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbSubstituteChg.toString());
				mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbSubPartTitle.toString());
				mpEBOMResult.put(ConstantsUtil.SS, sbSubPartSpecSubType.toString());
				mpEBOMResult.put(ConstantsUtil.COMBINATIONNUMBER, sbSubstituteSCN.toString());
				mpEBOMResult.put(ConstantsUtil.MIN, sbSubstituteMinQTY.toString());
				mpEBOMResult.put(ConstantsUtil.TARGET, sbSubstituteTarget.toString());
				mpEBOMResult.put(ConstantsUtil.MAX, sbSubstituteMaxQTY.toString());
				mpEBOMResult.put(ConstantsUtil.UOM, sbSubstituteUOM.toString());
				mpEBOMResult.put(ConstantsUtil.MF, sbSubstituteMF.toString());
				mpEBOMResult.put(ConstantsUtil.PI, sbSubstitutePI.toString());
				mpEBOMResult.put(ConstantsUtil.VALIDUNTILDATE, sbSubPartValidUntiltDt.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbSubstituteCMT.toString());

				mpFinal.put(j, util.filterMapList(mpEBOMResult));
				j++;

			}

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in Formula Card : getFormulaSubstitutes : "+ e);
			return new HashMap();
		}
		return mpFinal;
		//return util.filterMapList(mpFinal);
	}*/

	public HashMap getPartSpecifications(Context context,String sObjectID, boolean bStruct) throws Exception 
	{
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		EnoviaVendorSpecsServiceImpl vend = new EnoviaVendorSpecsServiceImpl();

		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbDisplay = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();

		String	sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
				+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;

		Pattern sTypePattern;

		if (bStruct) 
		{
			sTypePattern=util.getTypePattern(true);
		}else{
			sTypePattern=util.getTypePattern(false);
		}
		//SPEC: Release SR18x.5.2 - Added for Defect# 39181  by Dominic on Date 10/02/2021 -- START
		sTypePattern.addPattern(ConstantsUtil.tIRMS);
		sTypePattern.addPattern(ConstantsUtil.tPMP);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39181  by Dominic on Date 10/02/2021 -- END
		//SPEC: Release SR18x.5.2 - Added for Defect# 39473  by Dominic on Date 11/02/2021 -- START
		sTypePattern.addPattern(ConstantsUtil.TYPE_PGCONSUMERDESIGNBASIS);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39473  by Dominic on Date 11/02/2021 -- END
		//SPEC: Release SR18x.5.2 - Added for Defect# 39397  by Amman on Feb 12, 2021 -- START
		sTypePattern.addPattern(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39397  by Amman on Feb 12, 2021 -- START
		//SPEC: Release SR18x.5.2 - Added for Defect# 39293  by Dominic on Date 18/02/2021 -- START
		sTypePattern.addPattern(ConstantsUtil.tIAPS);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39293  by Dominic on Date 18/02/2021 -- END

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();
		// Guna Added for Defect 35928  18x.5.2 Release -- START
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		// Guna Added for Defect 35928  18x.5.2 Release -- END
		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		// Guna modified for Defect 35928  18x.5.2 Release -- START
		/*if (isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}*/

		//<SPEC> 04/02/2021 Modified by Govind for Defect#38816 start
		/*if (sUserType.equals(ConstantsUtil.PG) || sct.isStaffAUGUser()) {
			sWhere = "current!=Obsolete";
		}else{
			sWhere = "current==Release";
		} */
		//SPEC: Release SR18x.5.2 - Modified for Defect# 39182  by Dominic on Date 10/02/2021 -- START
		//sWhere= "current==Release || current==Obsolete";
		sWhere= "current==Release";
		//SPEC: Release SR18x.5.2 - Modified for Defect# 39182  by Dominic on Date 10/02/2021 -- END
		//<SPEC> 04/02/2021 Modified by Govind for Defect#38816 end

		// Guna modified for Defect 35928 18x.5.2 Release -- END
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, sTypePattern.getPattern(),
					slPartSpecSelects, null, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			//SPEC: 06-23-2021: Added for 18x.6.0.1 Defect# 43778 by Sanjeeva -- START
			Map mpTempMap = new HashMap();
			String strSubType = "";
			//SPEC: 06-23-2021: Added for 18x.6.0.1 Defect# 43778 by Sanjeeva -- END

			for (int j = 0; j < mapList.size(); j++) 
			{
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);
				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));

				//String sDisplay =getMappedType(strType);
				String sDisplay =util.getMappedTypeData(context,strType);
				String strName = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));

				String strSource = util.getSource(context, strId);

				mpTempMap.put(ConstantsUtil.ID, strId);
				mpTempMap.put(DomainConstants.SELECT_TYPE, strType);
				//Map mpSubType=vend.getSpecificationSubtype(context,mpEachObj);
				Map mpSubType=vend.getSpecificationSubtype(context,mpTempMap);

				strSubType = (String) mpSubType.get(strType);
				String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED) || strType.equalsIgnoreCase("pgConsumerDesignBasis")){
					strId_Result=ConstantsUtil.NO_ACCESS;
				}
				if (strType.equals(ConstantsUtil.TYPE_PGCONSUMERDESIGNBASIS))
				{
					strId_Result=ConstantsUtil.NO_ACCESS;
				}
				if (strType.equals(ConstantsUtil.tIAPS))
				{
					sDisplay=util.mapType(strType);
				}
				boolean showData = util.checkHasAccess(context, sUserType, strId);
				if(!showData && util.isModificatinRequired()){
					continue;
				}
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for REQ 33248 on Date 17/05/2021 --END
				if (util.isModificatinRequired()) {
					if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION))
					{

						String strCSSType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE));

						if (bStruct) {
							if(!strCSSType.equals("TAMU"))
								continue;
						}
						if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {

							sbType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbDisplay.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							//modified by Ganesh for defect 38816 ----->end
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbDisplay.append(sDisplay).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							// Modified by Jwala for the defect 43144 -- START
							//String strTitle = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							String strTitle = validator.getStringEquivalentForSubstituteStringTitle(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							// Modified by Jwala for the defect 43144 -- END
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);

							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						}

					} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
							|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {

						if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {

							sbType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbDisplay.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							//modified by Ganesh for defect 38816 ----->end
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						} else {
							String sView = util.updateReferences(context, strId);
							LOGGER.info("COMMON DOC SERVICE  SOP VIEW:" + sView + "User :" + sUserType);

							if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
									&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {

								sbType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbDisplay.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								//modified by Ganesh for defect 38816 ----->end
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {

								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbDisplay.append(sDisplay).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForSubstituteStringTitle(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);

								sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

							}
						}

					} else {
						//bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						//Added by Ganesh Start
						bHasOwnerShip = util.checkHasAccess(context, sUserType, strId);
						//Added by Ganesh Stop
						if (bHasOwnerShip) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbDisplay.append(sDisplay).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteStringTitle(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);

							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

						} else {

							sbType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbDisplay.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							//modified by Ganesh for defect 38816 ----->end
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					}

				} else
				{
					if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
						strId_Result=ConstantsUtil.NO_ACCESS;
					}

					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbDisplay.append(sDisplay).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteStringTitle(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
					} else {

						sbType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbDisplay.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						//modified by Ganesh for defect 38816 ----->end
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

					}
				}
				//Added by Ganesh stop

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.DISPLAY_TYPE, sbDisplay.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in FormulaPartBO : getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}




	public String getMappedType(String sType){

		try
		{
			Map mapCodeMapping = new HashMap();
			mapCodeMapping.put("pgApprovedSupplierList", "ASL");
			mapCodeMapping.put("pgArtwork", "ART");
			mapCodeMapping.put("pgBaseFormula","BSF");
			mapCodeMapping.put("ECR","CR");
			mapCodeMapping.put("pgCommonPerformanceSpecification", "CPST");
			mapCodeMapping.put("pgConsumerDesignBasis","CDB");
			mapCodeMapping.put("pgFinishedProduct","FP");
			mapCodeMapping.put("pgIllustration", "ILST");
			mapCodeMapping.put("pgLogisticSpec", "LOG");
			mapCodeMapping.put("pgMakingInstructions","MI");
			mapCodeMapping.put("pgMasterPackingMaterial","MPMS");
			mapCodeMapping.put("pgMasterRawMaterial", "MRMS");
			mapCodeMapping.put("pgMasterFinishedProduct","MPS");
			mapCodeMapping.put("pgPackingMaterial","MATL");
			mapCodeMapping.put("pgRawMaterial","MATL");
			mapCodeMapping.put("Shared Table","CPS");
			mapCodeMapping.put("pgNonGCASPart", "NGCAS");
			mapCodeMapping.put("pgPackingInstructions", "PI");
			mapCodeMapping.put("pgPackingSubassembly","PSUB");
			mapCodeMapping.put("pgProcessStandard", "PROS");
			mapCodeMapping.put("pgApplianceProduct", "APP");
			mapCodeMapping.put("pgAssembledProduct","ASP");
			mapCodeMapping.put("pgFormulatedProduct","FC");
			mapCodeMapping.put("pgQualitySpecification", "QUAL");
			mapCodeMapping.put("pgStackingPattern", "SPS");
			mapCodeMapping.put("pgStandardOperatingProcedure","SOP");
			mapCodeMapping.put("pgSupplierInformationSheet", "SIS");
			mapCodeMapping.put("pgTestMethod", "TM");
			mapCodeMapping.put("Safety And Regulatory Characteristic","SRS");
			mapCodeMapping.put("pgFormulatedMaterial","FMATL");
			mapCodeMapping.put("pgMaterial","MATL");		
			mapCodeMapping.put("Finished Product Part", "FPP");
			mapCodeMapping.put("pgConsumerUnitPart", "COP");
			mapCodeMapping.put("pgCustomerUnitPart", "CUP");
			mapCodeMapping.put("pgInnerPackUnitPart", "IP");
			mapCodeMapping.put("pgTransportUnitPart", "TUP");
			mapCodeMapping.put("pgMasterConsumerUnitPart", "MCOP");
			mapCodeMapping.put("pgMasterCustomerUnitPart", "MCUP");
			mapCodeMapping.put("pgMasterInnerPackUnitPart", "MIP");
			mapCodeMapping.put("pgAncillaryPackagingMaterialPart", "APMP");
			mapCodeMapping.put("pgPromotionalItemPart", "PIP");
			mapCodeMapping.put("Formulation Part", "FOP");
			mapCodeMapping.put("Packaging Material Part", "PMP");
			mapCodeMapping.put("Raw Material", "RMP");
			mapCodeMapping.put("pgMasterPackagingMaterialPart", "MPMP");
			mapCodeMapping.put("Packaging Assembly Part", "PAP");
			mapCodeMapping.put("pgMasterPackagingAssemblyPart", "MPAP");
			mapCodeMapping.put("pgPackingInstructions", "PI");
			mapCodeMapping.put("pgAuthorizedTemporarySpecification", "ATS");
			mapCodeMapping.put("pgStackingPattern", "SPS");
			mapCodeMapping.put("pgPPMConstituent", "CNT");
			mapCodeMapping.put("pgOnlinePrintingPart", "OPP");
			mapCodeMapping.put("pgFabricatedPart","FAB");
			mapCodeMapping.put("pgAncillaryRawMaterialPart","ARMP");
			mapCodeMapping.put("pgAssembledProductPart","APP");
			mapCodeMapping.put("pgAuthorizedConfigurationStandard","ACS");
			mapCodeMapping.put("pgDeviceProductPart","DPP");
			mapCodeMapping.put("Formula Technical Specification","IAPS");
			mapCodeMapping.put("pgMasterProductPart","MPP");
			mapCodeMapping.put("pgMasterRawMaterialPart","MRMP");
			mapCodeMapping.put("Formulation Process","FOPR");
			mapCodeMapping.put("Making Instruction","MI");

			if (ConstantsUtil.TYPE_PGPHASE.equals(sType)) {
				return "";
			}else{

				return	(String)mapCodeMapping.get(sType);
			}

		}catch(Exception e){
			LOGGER.error("Exception in Formula Card BO: getMappedType : "+ e);
			return sType;
		}
	}

	public MapList getExtendedPerformChar(Context context, DomainObject doFop, String sRevision, String sName,
			Map resultMaps) {
		MapList mlPerformChars = new MapList();
		MapList mlFinalList  = new MapList();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			StringList objectSelects = util.createSelects(ConstantsUtil.SELECT_ID, ConstantsUtil.SELECT_NAME,
					ConstantsUtil.SELECT_REVISION, ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC,
					ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING, ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP,
					ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING,
					ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGTEXT,
					ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING,
					ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM,
					ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT,
					ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT,
					ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET, ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET,
					ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET,
					ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT,
					ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT,
					ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE, ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST,
					ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE, ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA,
					ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED, ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR,
					ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS, ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP,
					ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION, ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS,
					ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER, ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN,
					ConstantsUtil.SELECT_NAME, ConstantsUtil.SELECT_TYPE, ConstantsUtil.STR_REF_DOC,ConstantsUtil.SELECT_REF_DOC_TO_CSS,
					ConstantsUtil.SELECT_REF_DOC_TO_ID, ConstantsUtil.SELECT_REF_DOC_TO_IPCLASS,
					ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS, ConstantsUtil.SELECT_REF_DOC_TO_TYPE,
					ConstantsUtil.TITLE, ConstantsUtil.PERFORMCHAR_ID, ConstantsUtil.PERFORMCHAR_TYPE,
					ConstantsUtil.STR_PARTFAMILY_TITLE, ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS,
					ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE, ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC,
					ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE,
					ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE, ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE,
					ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE,ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME,ConstantsUtil.SELECT_ATTRIBUTE_CPSID
					);
			//START :: gaikwad.tg
			/*StringList relSelects = util.createSelects(ConstantsUtil.SELECT_RELATIONSHIP_ID,
					ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,
					ConstantsUtil.SELECT_ATTRIBUTE_PGINHERITANCETYPE);
			String typePattern = ConstantsUtil.TYPE__PERFORMANCE_CHAR + "," + ConstantsUtil.TYPE_NOTES_CHAR + ","
					+ ConstantsUtil.TYPE_PACKING_UNIT_CHAR;

			mlPerformChars = doFop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EXTENDEDDATA,
					ConstantsUtil.TYPE__PERFORMANCE_CHAR, objectSelects, relSelects, false, true, (short) 0, null, null,
					0);*/

			StringList relSelects = new StringList();
			relSelects.add("id[connection]");
			relSelects.add("from.name");
			relSelects.add("to.name");
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);

			String relPattern = ConstantsUtil.RELATIONSHIP_EXTENDEDDATA + "," + ConstantsUtil.RELATIONSHIP_SHARED_TABLE + "," + ConstantsUtil.RELATIONSHIP_SHAREDCHARACTERISTIC+ "," + "Extended Data";

			String typePattern = ConstantsUtil.TYPE_SHARED_TABLE + "," + ConstantsUtil.TYPE__PERFORMANCE_CHAR;

			boolean isShared = Boolean.valueOf(doFop.getInfo(context, "relationship[" + ConstantsUtil.RELATIONSHIP_SHARED_TABLE + "]")).booleanValue();
			if (isShared) {
				mlPerformChars = doFop.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects, false, true, (short)2, null, null, 0);
			}
			else {
				mlPerformChars = doFop.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects, false, true, (short)1, null, null, 0);
			} 
			mlFinalList = getFormatedMapList(context, mlPerformChars);

			//END :: gaikwad.tg
			if (mlFinalList.isEmpty()) {
				return new MapList();
			}
			mlPerformChars = util.getPath(mlFinalList, sName, sRevision);

		} catch (Exception e) {
			LOGGER.error("Unable to get data in FormulaCardBO : getExtendedPerformChar " + e);
			return new MapList();
		}


		return mlFinalList;
	}
	//START :: gaikwad.tg
	/**
	 * Method Name 			: getFormatedMapList
	 * Method Description 	:
	 * @param resultMapList
	 * @return
	 */
	public MapList getFormatedMapList(Context context, MapList objList)  throws Exception
	{

		MapList outputList = new MapList();
		Iterator<Map> sharedmapItr = objList.iterator();
		HashMap<Object, Object> sharedmap = new HashMap<>();
		while (sharedmapItr.hasNext()) {
			Map perMap = sharedmapItr.next();
			String mapType = (String)perMap.get("type");
			String tableSeqNo = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
			String tabName = (String)perMap.get("name");

			if (mapType.equals(ConstantsUtil.TYPE_SHARED_TABLE)) 
			{
				Vector<Map> charList = new Vector();
				//charList.add(tableSeqNo);
				charList.add(perMap);
				sharedmap.put(tabName, charList);
			} 
		} 


		StringList tabList = new StringList();
		Set sharedTabNames = new HashSet();
		sharedTabNames.addAll(sharedmap.keySet());
		Integer sortNo = Integer.valueOf(0);
		Iterator<Map> objListItr = objList.iterator();

		while (objListItr.hasNext()) 
		{
			Map<String, String> perMap = objListItr.next();
			String seq = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);

			if (!"".equals(seq) && seq != null) 
			{
				sortNo = Integer.valueOf(Integer.parseInt(seq) * 100);
			}

			perMap.put("sortNo", "" + sortNo);
			String relation = perMap.get("relationship");
			if (relation.equals(ConstantsUtil.RELATIONSHIP_SHAREDCHARACTERISTIC)) {
				String tableName = perMap.get("from.name");
				Vector<Map> charList = (Vector)sharedmap.get(tableName);
				String tabSeqNo = "0";
				Map mTempMap1 = new HashMap();

				if (charList != null && !charList.isEmpty())
				{
					mTempMap1 = charList.get(0);
					tabSeqNo = (String) mTempMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
				}

				if (sharedTabNames.contains(tableName) && null != tabSeqNo && !tabSeqNo.isEmpty())
				{
					sharedTabNames.remove(tableName);
				}

				String perMapSeqNo = perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
				sortNo = Integer.valueOf(Integer.parseInt(tabSeqNo) * 100 + Integer.parseInt(perMapSeqNo));
				perMap.put("sortNo", "" + sortNo);
			} 
			if (!relation.equals("Shared Table"))
			{
				outputList.add(perMap);
			}
		}


		for (Iterator<String> emptySharedTableItr = sharedTabNames.iterator(); emptySharedTableItr.hasNext(); )
		{
			String tableName = emptySharedTableItr.next();
			Vector<Map> charList = (Vector)sharedmap.get(tableName);
			String tabSeqNo = "0";
			Map mTempMap = new HashMap();

			if (charList != null && !charList.isEmpty())
			{
				mTempMap = charList.get(0);
				tabSeqNo = (String) mTempMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
			}

			sortNo = Integer.valueOf(Integer.parseInt(tabSeqNo) * 100);
			Map perMap = (Map)charList.get(1);
			perMap.put("sortNo", "" + sortNo);
			outputList.add(perMap);
		} 

		try 
		{
			outputList.sort("sortNo", "ascending", "Integer");
		}
		catch (Exception ex) 
		{
			ex.printStackTrace();
		} 

		if (outputList.size() > 0)
		{
			return pgGetCharacteristicList(context, outputList);
		}

		return outputList;
	}

	/**
	 * Method Name 			: pgGetCharacteristicList
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public MapList pgGetCharacteristicList(Context context, MapList inputList) throws Exception 
	{
		Iterator<Map> objListItr = inputList.iterator();
		int nCount = 0;
		MapList outputList = new MapList();
		while (objListItr.hasNext()) 
		{
			Map<String, String> perMap = objListItr.next();
			nCount++;
			perMap.put("nCount", "" + nCount);
			outputList.add(perMap);
		} 
		return outputList;
	}
	//END :: gaikwad.tg
	/**
	 * Method Name 			: getEDList
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public String getOriginatorUserName(String sAttrVal,String ldapuser,String ldappwd) {

		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();

		String strValue=ConstantsUtil.EMPTY_STRING;
		StringTokenizer newValues=null;
		StringList strList=new StringList();

		if(null!=sAttrVal && (!sAttrVal.isEmpty())){
			sAttrVal = BbUtil.getLDAPInfo(sAttrVal.trim(), true,ldapuser,ldappwd);
		}

		return sAttrVal;

	}

	// Guna Modified for Defect 38208  18x.5.2 Release -- START
	public String getSpecificationSubtype(Context context,String strType,String strAttrPgAssemblyType , String strAttrPgCSSType, String sOid) throws Exception
	{
		// Guna Modified for Defect 38208  18x.5.2 Release -- END
		Map mapDataMapping = new HashMap();
		mapDataMapping.put("pgPackingMaterial","Packaging");
		mapDataMapping.put("pgRawMaterial","Raw");
		// Guna Added for Defect 38208  18x.5.2 Release -- START
		//SPEC: <01.21.2021>: Added for Defect : 38181 by Sumit --START
		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
		if(busUtil.isOfDSOOrigin(context, sOid)){

			if(UIUtil.isNullOrEmpty(strAttrPgAssemblyType)){
				strAttrPgAssemblyType = "";
			}
			mapDataMapping.put(strType, strAttrPgAssemblyType);
		}

		//mapDataMapping.put(strType,strAttrPgAssemblyType);
		//SPEC: <01.21.2021>: Added for Defect : 38181 by Sumit --ENDS
		// Guna Added for Defect 38208  18x.5.2 Release -- END
		// Guna Modified for Defect 38208  18x.5.2 Release -- START
		else{
			if ("pgFinishedProduct".equals(strType))
			{
				if("".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgFinishedProduct","Finished Product");
				}
				else if("FWIP-Finished Work in Process".equals(strAttrPgAssemblyType)) {
					mapDataMapping.put("pgFinishedProduct","FWIP-Finished Work in Process");			
				}
				else if("Purchased Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgFinishedProduct","Purchased Subassembly");	
				}
				else if("Purchased and/or Produced Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgFinishedProduct","Purchased and/or Produced Subassembly");	
				}				
			} else if ("pgQualitySpecification".equals(strType))
			{
				if(!UIUtil.isNullOrEmpty(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification",strAttrPgCSSType);
				}
				else
				{
					if(!UIUtil.isNullOrEmpty(strAttrPgAssemblyType)){

						String strSpecSubType ="";
						if(strAttrPgAssemblyType.equalsIgnoreCase("Sampling"))
						{
							strSpecSubType = "SMPL";
						} 
						else if(strAttrPgAssemblyType.equalsIgnoreCase("Cleaning/Inspection/Lubrication"))
						{
							strSpecSubType = "CIL";
						}
						mapDataMapping.put("pgQualitySpecification",strSpecSubType);
					}
				}
			} else if ("pgTestMethod".equals(strType))
			{   
				if ("TAMU".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgTestMethod","TAMU");
				}
				else{
					mapDataMapping.put("pgTestMethod","");
				}
			}
			else if ("pgPackingSubassembly".equals(strType))
			{
				if("Purchased Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgPackingSubassembly","Purchased Subassembly");	
				}
				else if("Purchased and/or Produced Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgPackingSubassembly","Purchased and/or Produced Subassembly");	
				}				
			}
		}
		// Guna Added for Defect 38208  18x.5.2 Release -- END

		String strSpecSubType = (String)mapDataMapping.get(strType);
		if(strSpecSubType != null)
		{
			strSpecSubType =strSpecSubType;
		}
		else
		{
			strSpecSubType="";
		}

		return strSpecSubType;
	}

	public Map updatePerformCharcteristic(Context context, MapList mlFinalList, Map resultMap)
	{

		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		String sType = validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.SELECT_TYPE))
				? (String) resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

		StringBuilder sCPS = new StringBuilder();
		StringBuilder sCPSName = new StringBuilder();
		StringBuilder sCPSId = new StringBuilder();

		StringBuilder schg = new StringBuilder();
		StringBuilder sCharcteristic = new StringBuilder();
		StringBuilder sbPathId = new StringBuilder();
		StringBuilder sbPathType = new StringBuilder();
		StringBuilder sCharSpec = new StringBuilder();
		StringBuilder sPath = new StringBuilder();
		StringBuilder sTMNActual = new StringBuilder();
		StringBuilder sTMNActualID = new StringBuilder();
		StringBuilder sTMNActualType = new StringBuilder();
		StringBuilder sTMName = new StringBuilder();
		StringBuilder sTMLogic = new StringBuilder();
		StringBuilder sMethodOrigin = new StringBuilder();
		StringBuilder sMethodNumber = new StringBuilder();
		StringBuilder sMethodSpecific = new StringBuilder();
		StringBuilder sTMNameID = new StringBuilder();
		StringBuilder sTMNameType = new StringBuilder();
		StringBuilder sSampling = new StringBuilder();
		StringBuilder sSubGroup = new StringBuilder();

		StringBuilder sPlantTesting = new StringBuilder();
		StringBuilder sPlantRetesting = new StringBuilder();
		StringBuilder sTestingUOM = new StringBuilder();

		StringBuilder sLowerSpecLimit = new StringBuilder();
		StringBuilder sLowerRoutineReleaseLimit = new StringBuilder();
		StringBuilder sPGLowerTarget = new StringBuilder();
		StringBuilder sPGTarget = new StringBuilder();
		StringBuilder sPGUpperTarget = new StringBuilder();
		StringBuilder sUpperRoutineRL = new StringBuilder();
		StringBuilder sPGUpperSpecLimit = new StringBuilder();

		StringBuilder sUnitOfMeasure = new StringBuilder();
		StringBuilder sPGReportNear = new StringBuilder();
		StringBuilder sPGReportType = new StringBuilder();
		StringBuilder sReleseCriteria = new StringBuilder();

		StringBuilder sPGACtionRequired = new StringBuilder();
		StringBuilder sCriticalFactor = new StringBuilder();
		StringBuilder sPGBasis = new StringBuilder();

		StringBuilder sPTestGroup = new StringBuilder();
		StringBuilder sPApplication = new StringBuilder();
		StringBuilder sPMTitle = new StringBuilder();

		Iterator objectListItr = mlFinalList.iterator();
		Map<String, String> mpFinal = new HashMap<String, String>();

		/*
		 * if(mlFinalList.size()==0) { return new HashMap(); }
		 */

		 //SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- START
		boolean isExternal=util.isModificatinRequired();
		//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- END

		try {

			while (objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				//SPEC: Release SR18x.6.0 - #Defect-40162 Added by gaikwad.tg on Date 09 April 2021 -- START
				boolean bshowTML = false;
				//SPEC: Release SR18x.6.0 - #Defect-40162 Added by gaikwad.tg on Date 09 April 2021 -- END
				//START :: gaikwad.tg
				String sForCPSType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
						? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

				String sForCPSName = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_NAME))
						? (String) objectMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;

				String sForCPSId = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
						? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- START
				/*if (sForCPSType.equalsIgnoreCase("Shared Table"))
				{
					sCPS.append(sForCPSType).append("|");
					sCPSName.append(sForCPSName).append("|");
					sCPSId.append(sForCPSId).append("|");
				}			
				else
				{
					String sCPSCharName = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME))
							? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME) : ConstantsUtil.EMPTY_STRING;
					String sCPSCharType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE))
							? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE) : ConstantsUtil.EMPTY_STRING;
					String sCPSCharID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID))
							? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID) : ConstantsUtil.EMPTY_STRING;

							sCPS.append(sCPSCharType).append("|");
							sCPSName.append(sCPSCharName).append("|");
							sCPSId.append(sCPSCharID).append("|");
				}*/
				//END :: gaikwad.tg
				String sPathId = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_ID));
				//modified by for Defect 38256 Release 18x.5.2---->start
				boolean showData1 = util.checkHasAccess(context, null, sPathId);
				if(!showData1)
				{
					sPathId = ConstantsUtil.NO_ACCESS;
				}
				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- END
				String sPchg = validator
						.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE))
						? ((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE))
								: ConstantsUtil.EMPTY_STRING;

				/*				String sPCharcteristic = validator
						.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC))
								? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC)
								: ConstantsUtil.EMPTY_STRING;
				String sPCharSpec = validator.isNotNullOrEmpty(
						(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS))
								? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS)
								: ConstantsUtil.EMPTY_STRING;*/

				String sPCharcteristic = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC));
				//SPEC: Release SR18x.6.0.1 Added by Dominic for Defect 43975 on Date 05/07/2021 --START
				if(UIUtil.isNullOrEmpty(sPCharcteristic)&&validator.isNotNullOrEmpty(sForCPSName))
				{
					sPCharcteristic=" ";
				}
				//SPEC: Release SR18x.6.0.1 Added by Dominic for Defect 43975 on Date 05/07/2021 --END		
				String sPCharSpec = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS));	


				String sPPath = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.PATH))
						? (String) objectMap.get(ConstantsUtil.PATH)
								: ConstantsUtil.EMPTY_STRING;

				String sPTMName = ConstantsUtil.EMPTY_STRING;
				String sPTMNameActual = ConstantsUtil.EMPTY_STRING;
				String sPTMNameID = ConstantsUtil.EMPTY_STRING;
				String sPTMNameActualID = ConstantsUtil.EMPTY_STRING;
				String sPTMNameActualType = ConstantsUtil.EMPTY_STRING;
				String sPTMType = ConstantsUtil.EMPTY_STRING;
				//SPEC: Release SR18x.5.2 - Added for Defect# 39386  by gaikwad.tg on Date 16 Feb 2021 -- START
				String strATTR_PG_ORIGINATINGSOURCE = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				if(UIUtil.isNullOrEmpty(strATTR_PG_ORIGINATINGSOURCE))
				{
					String strID = (String) resultMap.get(ConstantsUtil.SELECT_ID);
					DomainObject dobject = DomainObject.newInstance(context, strID);
					strATTR_PG_ORIGINATINGSOURCE = dobject.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39386  by gaikwad.tg on Date 16 Feb 2021 -- END
				boolean sClass = objectMap.containsKey(ConstantsUtil.SELECT_REF_DOC_TONAME);
				if (sClass) {
					String sClassName = objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME).getClass().getSimpleName();

					if (sClassName.equals(ConstantsUtil.STRING)) {

						String sTamu = validator
								.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_CSS))
								? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_CSS)
										: ConstantsUtil.EMPTY_STRING;

						if (util.isModificatinRequired())
						{
							sPTMName = validator
									.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
									? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
											: ConstantsUtil.EMPTY_STRING;
							sPTMType = validator
									.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
									? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
											: ConstantsUtil.EMPTY_STRING;
							String sTMHasSharedAccess = validator.isNotNullOrEmpty((String) objectMap
									.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS))
									? (String) objectMap
											.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS)
											: ConstantsUtil.EMPTY_STRING;
							sPTMNameID = validator
									.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
									? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
											: ConstantsUtil.EMPTY_STRING;
							boolean showData = util.checkHasAccess(context, null, sPTMNameID);
							boolean strTempCurrentIsRelease = util.checkIfReleased(context, sPTMNameID);
							if (!showData || !strTempCurrentIsRelease) {

								util.formatData(sTMNActual, ConstantsUtil.EMPTY_STRING);
								util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
								util.formatData(sTMNActualType, ConstantsUtil.EMPTY_STRING);

								util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
								util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
								util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);

							}
							else
							{
								if(!strTempCurrentIsRelease)
									sPTMNameID = ConstantsUtil.NO_ACCESS;
								if (sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION) || sPTMType.equals(ConstantsUtil.TYPE_TESTMETHOD) || sPTMType.equals(ConstantsUtil.TYPE_PGTESTMETHOD)) 
								{
									if ("DSO".equals(strATTR_PG_ORIGINATINGSOURCE) && !sPTMType.equals("pgTestMethod")) {
										util.formatData(sTMNActual, sPTMName);
										util.formatData(sTMNActualID, sPTMNameID);
										util.formatData(sTMNActualType, sPTMType);
									}
									else if (sTamu.equals("TAMU") && ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess)) 
									{
										//SPEC: Release SR18x.5.2 - Added for Defect# 39386  by gaikwad.tg on Date 16 Feb 2021 -- END
										util.formatData(sTMNActual, sPTMName);
										//util.formatData(sTMNActualID, sPTMNameActual);
										util.formatData(sTMNActualID, sPTMNameID);
										util.formatData(sTMNActualType, sPTMType);
									}else if(!ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess) && sTamu.equals("TAMU")) {
										util.formatData(sTMNActual, sPTMName);
										util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
										util.formatData(sTMNActualType, sPTMType);

									}
									else
									{
										util.formatData(sTMNActual, ConstantsUtil.EMPTY_STRING);
										util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
										util.formatData(sTMNActualType, ConstantsUtil.EMPTY_STRING);
									}

									if (ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess) && !sTamu.equals("TAMU"))  {
										//SPEC: Release SR18x.5.2 - Added for Defect# 39386  by gaikwad.tg on Date 16 Feb 2021 -- END
										util.formatData(sTMName, sPTMName);
										util.formatData(sTMNameID, sPTMNameID);
										util.formatData(sTMNameType, sPTMType);

									} else {
										//SPEC: Release SR18x.5.2 - Added for Defect# 39386  by gaikwad.tg on Date 16 Feb 2021 -- START
										util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
										util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
										util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
									}
								} else if (sPTMType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)  || ConstantsUtil.TYPE_PG_TMRD_TYPES.contains(sPTMType)) 
								{
									sPTMNameActual = validator
											.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
											? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
													: ConstantsUtil.EMPTY_STRING;
									sPTMNameActualType = validator
											.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
											? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
													: ConstantsUtil.EMPTY_STRING;
									sTMHasSharedAccess = validator.isNotNullOrEmpty((String) objectMap
											.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS))
											? (String) objectMap.get(
													ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS)
													: ConstantsUtil.EMPTY_STRING;
									sPTMNameActualID = validator
											.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
											? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
													: ConstantsUtil.EMPTY_STRING;

									showData = util.checkHasAccess(context, null, sPTMNameActualID);
									//SPEC: Release SR18x.6.0.1 - Added for Defect# 43145  by gaikwad.tg on Date 25 May 2021 -- START
									boolean strTempCurrentIsRelease1 = util.checkIfReleased(context, sPTMNameActualID);			
									if(!strTempCurrentIsRelease1)
										sPTMNameActualID = ConstantsUtil.NO_ACCESS;

									if (showData && strTempCurrentIsRelease1) {
										util.formatData(sTMNActual, sPTMNameActual);
										util.formatData(sTMNActualID, sPTMNameActualID);
										util.formatData(sTMNActualType, sPTMType);

										util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
										util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
										util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
									} 
									else {
										util.formatData(sTMNActual, ConstantsUtil.EMPTY_STRING);
										util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
										util.formatData(sTMNActualType, ConstantsUtil.EMPTY_STRING);

										util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
										util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
										util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
									}
								}
								else {
									util.formatData(sTMNActual, ConstantsUtil.EMPTY_STRING);
									util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
									util.formatData(sTMNActualType, ConstantsUtil.EMPTY_STRING);

									util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
									util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
									util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
								}
							}
						} else 
						{
							sPTMType = validator
									.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
									? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
											: ConstantsUtil.EMPTY_STRING;
							if (sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION) || sPTMType.equals(ConstantsUtil.TYPE_TESTMETHOD) || sPTMType.equals(ConstantsUtil.TYPE_PGTESTMETHOD)) 
							{
								sPTMName = validator
										.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
										? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
												: ConstantsUtil.EMPTY_STRING;
								sPTMNameID = validator
										.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
										? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
												: ConstantsUtil.EMPTY_STRING;

								boolean 	showData = util.checkHasAccess(context, null, sPTMNameID);
								boolean strTempCurrentIsRelease1 = util.checkIfReleased(context, sPTMNameID);			

								if (!showData || !strTempCurrentIsRelease1) {
									sPTMNameID=ConstantsUtil.EMPTY_STRING;
								}
								if (("DSO".equals(strATTR_PG_ORIGINATINGSOURCE) && !sPTMType.equals("pgTestMethod")) || sTamu.equals("TAMU") ) {

									util.formatData(sTMNActual, sPTMName);
									util.formatData(sTMNActualID, sPTMNameID);
									util.formatData(sTMNActualType, sPTMType);

								}else
								{
									util.formatData(sTMNActual, ConstantsUtil.EMPTY_STRING);
									util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
									util.formatData(sTMNActualType, ConstantsUtil.EMPTY_STRING);
								}


								if (!sTamu.equals("TAMU")) {
									util.formatData(sTMName, sPTMName);
									util.formatData(sTMNameID, sPTMNameID);
									util.formatData(sTMNameType, sPTMType);

								} 
								else
								{
									util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
									util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
									util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
								}
							} else 
							{

								sPTMNameActual = validator
										.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
										? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
												: ConstantsUtil.EMPTY_STRING;
								sPTMNameActualType = validator
										.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
										? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
												: ConstantsUtil.EMPTY_STRING;
								sPTMNameActualID = validator
										.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
										? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
												: ConstantsUtil.EMPTY_STRING;


								boolean 	showData = util.checkHasAccess(context, null, sPTMNameActualID);
								boolean strTempCurrentIsRelease1 = util.checkIfReleased(context, sPTMNameID);

								if (!showData || !strTempCurrentIsRelease1) {
									sPTMNameActualID=ConstantsUtil.EMPTY_STRING;
								}

								util.formatData(sTMNActual, sPTMNameActual);
								util.formatData(sTMNActualID, sPTMNameActualID);
								util.formatData(sTMNActualType, sPTMNameActualType);

								util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
								util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
								util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
							}
						}
					} else {

						StringList slTMName = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME);
						StringList slTMType = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
						StringList slsChildObjectID = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID);
						StringList slTamuList = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_CSS);
						StringList slTMHasSharedAccess = (StringList) objectMap
								.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS);
						if (util.isModificatinRequired()) {
							Map<String, StringList> mpTemp = new HashMap<String, StringList>();
							mpTemp.put(ConstantsUtil.TYPE, slTMType);
							mpTemp.put(ConstantsUtil.NAME, slTMName);
							mpTemp.put(ConstantsUtil.SECURITY, slTMHasSharedAccess);
							mpTemp.put(ConstantsUtil.ID, slsChildObjectID);
							mpTemp.put(ConstantsUtil.tTM, slTamuList);
							//It will check the Object is sharable or not
							Map mpTemp1 = util.showOrHideSOPAndTM(context, mpTemp);
							slTMName = (StringList) mpTemp1.get(ConstantsUtil.NAME);
							slTMType = (StringList) mpTemp1.get(ConstantsUtil.TYPE);
							slsChildObjectID = (StringList) mpTemp1.get(ConstantsUtil.ID);
							slTamuList = (StringList) mpTemp1.get(ConstantsUtil.tTM);

						}

						Map mpTemp2 = util.removeTestMethodTamuNew(slTMName, slTMType, slsChildObjectID,slTamuList, strATTR_PG_ORIGINATINGSOURCE);
						StringList slTMFilteredName = (StringList) mpTemp2.get(ConstantsUtil.TMFILNAME);
						if(UIUtil.isNotNullAndNotEmpty(slTMFilteredName.toString()))
						{
							StringList slTMTestName = FrameworkUtil.split(slTMFilteredName.toString(), ConstantsUtil.SYMBL_COMMA);
							if(slTMTestName!= null && !slTMTestName.isEmpty() && slTMTestName.size()>1)
								bshowTML = true;

						}
						StringList slTMFilterID = (StringList) mpTemp2.get(ConstantsUtil.TMFILID);
						StringList slTMFilterType = (StringList) mpTemp2.get(ConstantsUtil.TMFILTYPE);
						slTMType = (StringList) mpTemp2.get(ConstantsUtil.BASETYPE);
						slTMName = (StringList) mpTemp2.get(ConstantsUtil.BASENAME);
						slsChildObjectID = (StringList) mpTemp2.get(ConstantsUtil.BASEID);
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- START
						if(isExternal)
						{
							Map mpTest1 =checkAccessForTMExternalUser(context, slTMFilterID, slTMFilteredName, slTMFilterType);
							slTMFilteredName = (StringList) mpTest1.get("name");
							slTMFilterID = (StringList) mpTest1.get("id");
							slTMFilterType = (StringList) mpTest1.get("type");

							Map mpTest2 =checkAccessForTMExternalUser(context,slsChildObjectID, slTMName, slTMType);
							//SPEC: Release SR18x.6.0.1 - Req#33248 Modified  by gaikwad.tg on Date 18 May 2021 -- START
							slTMType = (StringList) mpTest2.get("type");
							slTMName = (StringList) mpTest2.get("name");
							slsChildObjectID = (StringList) mpTest2.get("id");
							//SPEC: Release SR18x.6.0.1 - Req#33248 Modified  by gaikwad.tg on Date 18 May 2021 -- END
						}
						else
						{
							slTMFilterID =checkAccessForTM(context,slTMFilterID);
							slsChildObjectID =checkAccessForTM(context,slsChildObjectID);
						}
						sPTMName = validator.isNotNullOrEmpty(slTMName.toString()) ? slTMName.toString()
								: ConstantsUtil.EMPTY_STRING;
						sPTMName = sPTMName.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

						sPTMNameID = validator.isNotNullOrEmpty(slsChildObjectID.toString())
								? slsChildObjectID.toString()
										: ConstantsUtil.EMPTY_STRING;
						sPTMNameID = sPTMNameID.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

						sPTMType = validator.isNotNullOrEmpty(slTMType.toString()) ? slTMType.toString()
								: ConstantsUtil.EMPTY_STRING;
						sPTMType = sPTMType.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

						util.formatData(sTMNActual, sPTMName);

						util.formatData(sTMNActualID, sPTMNameID);
						util.formatData(sTMNActualType, sPTMType);

						sPTMNameActual = validator.isNotNullOrEmpty(slTMFilteredName.toString())
								? slTMFilteredName.toString()
										: ConstantsUtil.EMPTY_STRING;
						sPTMNameActual = sPTMNameActual
								.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

						sPTMNameActualID = validator.isNotNullOrEmpty(slTMFilterID.toString()) ? slTMFilterID.toString()
								: ConstantsUtil.EMPTY_STRING;
						sPTMNameActualID = sPTMNameActualID
								.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

						sPTMNameActualType = validator.isNotNullOrEmpty(slTMFilterType.toString())
								? slTMFilterType.toString()
										: ConstantsUtil.EMPTY_STRING;
						sPTMNameActualType = sPTMNameActualType
								.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
								.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

						util.formatData(sTMName, sPTMNameActual);
						util.formatData(sTMNameID, sPTMNameActualID);
						util.formatData(sTMNameType, sPTMNameActualType);

					}

				} else 
				{

					util.formatData(sTMName, sPTMNameActual);
					util.formatData(sTMNameID, sPTMNameActualID);
					util.formatData(sTMNameType, sPTMNameActualType);

					util.formatData(sTMNActual, sPTMName);
					util.formatData(sTMNActualID, sPTMNameID);
					util.formatData(sTMNActualType, sPTMType);
				}
				if (sForCPSType.equalsIgnoreCase("Shared Table"))
				{
					sCPS.append(sForCPSType).append("|");
					sCPSName.append(sForCPSName).append("|");
					sCPSId.append(sForCPSId).append("|");
				}			
				else
				{
					String sCPSCharName = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME))
							? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME) : ConstantsUtil.EMPTY_STRING;
					String sCPSCharType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE))
							? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE) : ConstantsUtil.EMPTY_STRING;
					String sCPSCharID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID))
							? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID) : ConstantsUtil.EMPTY_STRING;

					sCPS.append(sCPSCharType).append("|");
					sCPSName.append(sCPSCharName).append("|");
					sCPSId.append(sCPSCharID).append("|");
				}


				String sPathType = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_TYPE));

				String sPTMLogic = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC));
				String sPMethodOrigin = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN));

				String sPMethodNumber = validator.getStringEquivalentForSubstituteString(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER));
				String sPMethodSpecific = validator.getStringEquivalentForSubstituteString(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS));

				String sPSampling = validator.getStringEquivalentForSubstituteString(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING));
				String sPSubGroup = validator
						.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP));

				String sPPlantTesting = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING));

				String sPPlantRetesting = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING));

				String sPTestingUOM = validator
						.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM));


				String sPlantTestingText = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGTEXT));
				String sPLowerSpecLimit =validator.getStringEquivalentForStringListWithComma(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT));
				String sPLowerRoutineReleaseLimit = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT));

				String sPPGLowerTarget = validator
						.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET));
				String sPPGTarget = validator
						.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET));
				String sPPGUpperTarget = validator
						.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET));
				String sPUpperRoutineRL = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT));

				String sPPGUpperSpecLimit =validator.getStringEquivalentForStringListWithComma(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT));
				String sPUnitOfMeasure = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE));
				String sPPGReportNear = validator.getStringEquivalentForStringListWithComma(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST));
				String sPPGReportType = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE));

				String sPReleseCriteria = validator.getStringEquivalentForSubstituteString(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA));

				String sPPGACtionRequired = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED));
				String sPCriticalFactor = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR));
				String sPPGBasis = validator.getStringEquivalentForSubstituteString(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS));
				String sTestGroup = validator
						.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP));
				String sApplication = validator.getStringEquivalentForSubstituteString(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION));

				String sTitle = ConstantsUtil.EMPTY_STRING;

				boolean bPresent = objectMap.containsKey(ConstantsUtil.PERFORMCHAR_MPT_TITLE);
				//SPEC: Release SR18x.6.0 - Added  by Manikanta for defect 41917 on Date 31/03/2021 -- START
				if (bPresent) {
					String sObjectId = (String)resultMap.get(ConstantsUtil.SELECT_ID);
					//SPEC: Release SR18x.6.1 - Modified by Manikanta for defect 43502 on Date 15/06/2021 -- START
					String sObjectName = (String)resultMap.get(ConstantsUtil.SELECT_NAME);
					if(!sPPath.contains(sObjectName)){
						sTitle=util.GetPerformCharcteristicMPT(context, sObjectId);
					}
				} 
				String sParentType = ((String) resultMap.get(ConstantsUtil.SELECT_TYPE));
				if(("pgFinishedProduct").equalsIgnoreCase(sParentType)) {
					util.formatData(sPlantTesting, sPPlantTesting);
					util.formatData(sPlantRetesting, sPlantTestingText);
				}
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 31, 2021 for Defect 41922 -- END

				sPPlantTesting = pgGetPlantTestingData(sPTestingUOM,sPPlantTesting,sPlantTestingText);

				util.formatData(sbPathId, sPathId);
				util.formatData(sbPathType, sPathType);
				util.formatData(sPath, sPPath);

				util.formatData(schg, sPchg);
				util.formatData(sCharcteristic, sPCharcteristic);
				util.formatData(sCharSpec, sPCharSpec);

				if (bshowTML)
					util.formatData(sTMLogic, sPTMLogic);
				else
					util.formatData(sTMLogic, DomainConstants.EMPTY_STRING);
				util.formatData(sMethodOrigin, sPMethodOrigin);
				util.formatData(sMethodNumber, sPMethodNumber);
				util.formatData(sMethodSpecific, sPMethodSpecific);

				util.formatData(sSampling, sPSampling);
				util.formatData(sSubGroup, sPSubGroup);

				if(!("pgFinishedProduct").equalsIgnoreCase(sParentType)) {
					util.formatData(sPlantTesting, sPPlantTesting);
					util.formatData(sPlantRetesting, sPPlantRetesting);
				}
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 31, 2021 for Defect 41922 -- END

				util.formatData(sTestingUOM, sPTestingUOM);

				util.formatData(sLowerSpecLimit, sPLowerSpecLimit);
				util.formatData(sLowerRoutineReleaseLimit, sPLowerRoutineReleaseLimit);
				util.formatData(sPGLowerTarget, sPPGLowerTarget);
				util.formatData(sPGTarget, sPPGTarget);
				util.formatData(sPGUpperTarget, sPPGUpperTarget);
				util.formatData(sUpperRoutineRL, sPUpperRoutineRL);
				util.formatData(sPGUpperSpecLimit, sPPGUpperSpecLimit);

				util.formatData(sUnitOfMeasure, sPUnitOfMeasure);
				util.formatData(sPGReportNear, sPPGReportNear);
				util.formatData(sPGReportType, sPPGReportType);
				util.formatData(sReleseCriteria, sPReleseCriteria);
				util.formatData(sPGACtionRequired, sPPGACtionRequired);
				util.formatData(sCriticalFactor, sPCriticalFactor);
				util.formatData(sPGBasis, sPPGBasis);

				util.formatData(sPTestGroup, sTestGroup);
				util.formatData(sPApplication, sApplication);
				util.formatData(sPMTitle, sTitle);

			}
			mpFinal.put(ConstantsUtil.CHG, schg.toString());
			mpFinal.put(ConstantsUtil.CHARACTERISTICCH, sCharcteristic.toString());
			mpFinal.put(ConstantsUtil.CS, sCharSpec.toString());
			if ((sType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)
					|| sType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) && util.isModificatinRequired()) {
				mpFinal.put(ConstantsUtil.CHARP, sPath.toString());
			} else if (!sType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)
					&& !sType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) {
				mpFinal.put(ConstantsUtil.CHARP, sPath.toString());
			}

			mpFinal.put(ConstantsUtil.REF, sTMNActual.toString());
			mpFinal.put(ConstantsUtil.REFID, sTMNActualID.toString());
			mpFinal.put(ConstantsUtil.REFTYPE, sTMNActualType.toString());

			mpFinal.put(ConstantsUtil.PATH_ID, sbPathId.toString());
			mpFinal.put(ConstantsUtil.PATH_TYPE, sbPathType.toString());

			mpFinal.put(ConstantsUtil.TMTYPE, sTMNameType.toString());
			mpFinal.put(ConstantsUtil.TESTMETHODNAME, sTMName.toString());
			mpFinal.put(ConstantsUtil.TESTMETHODNAMEID, sTMNameID.toString());

			mpFinal.put(ConstantsUtil.TML, sTMLogic.toString());
			mpFinal.put(ConstantsUtil.ORIGIN, sMethodOrigin.toString());
			mpFinal.put(ConstantsUtil.TM, sMethodNumber.toString());
			mpFinal.put(ConstantsUtil.SP, sMethodSpecific.toString());

			mpFinal.put(ConstantsUtil.SAMPLINGSM, sSampling.toString());
			mpFinal.put(ConstantsUtil.SG, sSubGroup.toString());

			mpFinal.put(ConstantsUtil.PLANTTESTING, sPlantTesting.toString());
			mpFinal.put(ConstantsUtil.RT, sPlantRetesting.toString());
			mpFinal.put(ConstantsUtil.UOM, sTestingUOM.toString());

			mpFinal.put(ConstantsUtil.LOWERSPECLIMIT, sLowerSpecLimit.toString());
			mpFinal.put(ConstantsUtil.LRRL, sLowerRoutineReleaseLimit.toString());
			mpFinal.put(ConstantsUtil.LTGT, sPGLowerTarget.toString());
			mpFinal.put(ConstantsUtil.TGT, sPGTarget.toString());
			mpFinal.put(ConstantsUtil.UTGT, sPGUpperTarget.toString());
			mpFinal.put(ConstantsUtil.URRL, sUpperRoutineRL.toString());
			mpFinal.put(ConstantsUtil.USL, sPGUpperSpecLimit.toString());

			mpFinal.put(ConstantsUtil.UNITOF, sUnitOfMeasure.toString());
			mpFinal.put(ConstantsUtil.RTN, sPGReportNear.toString());
			mpFinal.put(ConstantsUtil.RTT, sPGReportType.toString());
			mpFinal.put(ConstantsUtil.RELEASECRITERIA, sReleseCriteria.toString());

			mpFinal.put(ConstantsUtil.ACTIONREQUIRED, sPGACtionRequired.toString());
			mpFinal.put(ConstantsUtil.CAPSCR, sCriticalFactor.toString());
			mpFinal.put(ConstantsUtil.BA, sPGBasis.toString());

			mpFinal.put(ConstantsUtil.TESTGROUP, sPTestGroup.toString());
			mpFinal.put(ConstantsUtil.AP, sPApplication.toString());
			mpFinal.put(ConstantsUtil.MPT, sPMTitle.toString());

			mpFinal.put(ConstantsUtil.CPS, sCPS.toString());
			mpFinal.put(ConstantsUtil.CPSNAME, sCPSName.toString());
			mpFinal.put(ConstantsUtil.CPSID, sCPSId.toString());

		} catch (Exception e) {
			LOGGER.error("Exception from FormulaCardBO:  updatePerformCharcteristic" + e);
			return new HashMap();
		}
		//return mpFinal = filterMapList(mpFinal);

		return mpFinal;
	}

	private String pgGetPlantTestingData(String sReTestUOM,String sPPlantTesting,String sPlantTestingText) {

		StringBuilder sbInter = new StringBuilder();

		if((null!=sReTestUOM)&&(sReTestUOM.equalsIgnoreCase("DAYS"))){
			sReTestUOM = "D";
		}else if((null!=sReTestUOM)&&(sReTestUOM.equalsIgnoreCase("WEEKS"))){
			sReTestUOM = "W";
		}else if((null!=sReTestUOM)&&(sReTestUOM.equalsIgnoreCase("MONTHS"))){
			sReTestUOM = "M";
		}else if((null!=sReTestUOM)&&((sReTestUOM.equalsIgnoreCase("YEARS") || (sReTestUOM.equalsIgnoreCase("YEAR"))))){
			sReTestUOM = "Y";
		}
		sbInter.append(sPPlantTesting).append(" ").append(sPlantTestingText).append(" ").append(sReTestUOM);

		return sbInter.toString();
	}


	/**
	 * 	  	
	 * @param context
	 * @param strID
	 * @param strType
	 * @return
	 * @throws Exception
	 */

	public String getSpecificationSubtypeForSubstitutes(Context context,String strID,String strType) throws Exception
	{
		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
		long startTime = System.currentTimeMillis();
		Map mapDataMapping = null;

		String strAttributeName = PropertyUtil.getSchemaProperty("attribute_pgAssemblyType");
		String strAttributeCSSType = PropertyUtil.getSchemaProperty("attribute_pgCSSType");
		String strTypepgFinishedProduct = PropertyUtil.getSchemaProperty("type_pgFinishedProduct");
		String strTypepgQualitySpecification = PropertyUtil.getSchemaProperty("type_pgQualitySpecification");
		String strAttrPgAssemblyType = ""; 
		String strTypepgTestMethod= PropertyUtil.getSchemaProperty("type_pgTestMethod");		

		String strSpecSubTypeValue = DomainConstants.EMPTY_STRING;  
		String strRelPgPDTemplatestopgPLIAssemblyType = DomainConstants.EMPTY_STRING;
		String strSelect = DomainConstants.EMPTY_STRING;

		Map mapObject = null;
		String strRootNode="";
		String strSpecSubType = "";
		String strAttrPgCSSType = "";
		boolean isContextPush = false;

		ContextUtil.pushContext(context, "User Agent", "", "");
		isContextPush = true;

		mapDataMapping = new HashMap();
		mapDataMapping.put("pgPackingMaterial","Packaging");
		DomainObject dom = new DomainObject(strID);
		boolean isDSO = busUtil.isOfDSOOrigin(context, strID);

		if (strTypepgFinishedProduct.equals(strType) || ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY.equals(strType))
		{
			strAttrPgAssemblyType = dom.getInfo(context, "attribute["+strAttributeName+"]");

			if("".equals(strAttrPgAssemblyType)){

				mapDataMapping.put("pgFinishedProduct","Finished Product");
			}
			else if("FWIP-Finished Work in Process".equals(strAttrPgAssemblyType)) {
				mapDataMapping.put("pgFinishedProduct","FWIP-Finished Work in Process");			
			}

			else if("Purchased Subassembly".equals(strAttrPgAssemblyType)){
				mapDataMapping.put("pgPackingSubassembly","Purchased Subassembly");	
			}
			else if("Purchased and/or Produced Subassembly".equals(strAttrPgAssemblyType)){
				mapDataMapping.put("pgPackingSubassembly","Purchased and/or Produced Subassembly");	
			}else{
				mapDataMapping.put("pgFinishedProduct",strAttrPgAssemblyType);	
			}				
		}

		if (strTypepgQualitySpecification.equals(strType) && !isDSO){
			strAttrPgCSSType = dom.getInfo(context, "attribute["+strAttributeCSSType+"]");

			if("AMAT".equals(strAttrPgCSSType)) {
				mapDataMapping.put("pgQualitySpecification","Approval Matrix");			
			}
			else if ("CBA".equals(strAttrPgCSSType)){
				mapDataMapping.put("pgQualitySpecification","Current Best Approach");	
			}
			else if ("GPMS".equals(strAttrPgCSSType)){
				mapDataMapping.put("pgQualitySpecification","General Packaging Material Specification");	
			}
			else if ("GPS".equals(strAttrPgCSSType)){
				mapDataMapping.put("pgQualitySpecification","General Packing Standard");	
			}
			else if ("IAS".equals(strAttrPgCSSType)){
				mapDataMapping.put("pgQualitySpecification","Incoming Acceptance Specification");	
			}
			else if ("MOC".equals(strAttrPgCSSType)){
				mapDataMapping.put("pgQualitySpecification","Material of Construction");	
			}
			else if ("QAC".equals(strAttrPgCSSType)){
				mapDataMapping.put("pgQualitySpecification","Quality Acceptance Criteria");
			}
			else if ("RMPI".equals(strAttrPgCSSType)){
				mapDataMapping.put("pgQualitySpecification","Raw Material Plant Instruction");	
			}else{
				mapDataMapping.put("pgQualitySpecification",strAttrPgCSSType);
			}		

		}
		if(ConstantsUtil.TYPE_PGRAWMATERIAL.equals(strType) || "Raw Material IRMS".equals(strType)){
			if(!isDSO){
				mapDataMapping.put("pgRawMaterial","Raw");					
				mapDataMapping.put("Raw Material IRMS","Raw");					
			}
		}
		if (isDSO){
			if(ConstantsUtil.TYPE_FORMULATIONPART.equals(strType)){
				strSpecSubTypeValue =  (String)dom.getInfo(context,"to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
			} else {
				strSpecSubTypeValue =  (String)dom.getInfo(context,"attribute["+strAttributeName+"]");
			}
		}else {
			strSpecSubTypeValue= "";
		}


		if (strTypepgTestMethod.equals(strType))
		{   
			strAttrPgCSSType = dom.getInfo(context, "attribute["+strAttributeCSSType+"]");
			if ("TAMU".equals(strAttrPgCSSType)){
				mapDataMapping.put("pgTestMethod","TAMU");
			}
			else {
				mapDataMapping.put("pgTestMethod","");
			}

		}								

		strSpecSubType = (String)mapDataMapping.get(strType);
		if(strSpecSubType != null)
		{
			strSpecSubType=strSpecSubType;
		}
		else if(UIUtil.isNotNullAndNotEmpty(strSpecSubTypeValue))
		{
			strSpecSubType=strSpecSubTypeValue;
		}
		else
		{
			strSpecSubType="";
		}
		dom.close(context);
		long endTime = System.currentTimeMillis();
		if(isContextPush){
			ContextUtil.popContext(context);
			isContextPush = false;
		}


		return strSpecSubType;

	}


	/**
	 * Method Name 			: getCountryClearanceResult
	 * Method Description 	: 
	 * @param resultMaps
	 * @return
	 */
	public Map getCountryClearanceResult(Context context, String sContextObjectId)
	{

		Map<String, String> mapCountryClearanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringBuilder sbMarketName = new StringBuilder();
		StringBuilder sbClearanceNum = new StringBuilder();
		StringBuilder sbOveralClearence = new StringBuilder();
		StringBuilder sbGPSApproval = new StringBuilder();
		StringBuilder sbManuSite = new StringBuilder();
		StringBuilder sbPackSite = new StringBuilder();
		StringBuilder sbComments = new StringBuilder();
		StringBuilder sbRestrictions = new StringBuilder();
		StringBuilder sbRegExpDate = new StringBuilder();
		StringBuilder sbRegStatus = new StringBuilder();
		StringBuilder sbMPDTNumber = new StringBuilder();
		StringBuilder sbPRODRegClass = new StringBuilder();
		StringBuilder sbRegrewlleadTime = new StringBuilder();
		StringBuilder sbRegirewlStatus = new StringBuilder();
		StringBuilder sbRegProductName = new StringBuilder();

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_NAME);

		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALLEADTIME);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALSTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME);

		try
		{

			MapList mapList;

			DomainObject doDPP = new DomainObject(sContextObjectId);

			mapList = doDPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE, ConstantsUtil.SYMBL_ASTERISK,
					busSelect, relSelect, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			doDPP.close(context);
			mapList.sort(DomainConstants.SELECT_NAME, "ascending", "String");

			for (int i = 0; i < mapList.size(); i++) 
			{
				Map resultMaps = (Map) mapList.get(i);

				String strMarketName    =  validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_NAME));
				String strClearanceNum    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER));
				String strOveralClearence    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS));
				String strGPSApproval   =  validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS));
				String strComments    =  validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT));
				String strRestrictions    =  validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION));
				String strRegExpDate    = validator.DateFormatter(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE)));
				String strRegStatus    =  validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS));
				strRegStatus=strRegStatus.replace(ConstantsUtil.REGISTRATIONRELEASEDAPP, ConstantsUtil.REGISTRATIONAPPROVEDAPP);

				util.formatData(sbMarketName, strMarketName);
				util.formatData(sbClearanceNum, strClearanceNum);
				util.formatData(sbOveralClearence, strOveralClearence);
				util.formatData(sbGPSApproval, strGPSApproval);
				util.formatData(sbComments, strComments);
				util.formatData(sbRestrictions, strRestrictions);
				util.formatData(sbRegExpDate, strRegExpDate);
				util.formatData(sbRegStatus, strRegStatus);

				mapCountryClearanceResult.put(ConstantsUtil.COUNTRY_NAME, sbMarketName.toString());
				mapCountryClearanceResult.put(ConstantsUtil.CLEARANCE_NUMBER, sbClearanceNum.toString());
				mapCountryClearanceResult.put(ConstantsUtil.OVERALL_CLEARENCE, sbOveralClearence.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PSRAAPPROVALSTATUS, sbGPSApproval.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REG_STATUS, sbRegStatus.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REG_EXP_DATE, sbRegExpDate.toString());
				mapCountryClearanceResult.put(ConstantsUtil.RESTRICTIONS, sbRestrictions.toString());
				mapCountryClearanceResult.put(ConstantsUtil.CLEAR_COMMENT, sbComments.toString());


			}

		}catch(Exception e){

			LOGGER.error("Error from FormulaCardBO:  getCountryClearanceResult"+e);
			return new HashMap();
		}

		return mapCountryClearanceResult;
	}



	/**
	 * Method Name 			: getSecurityClass
	 * Method Description 	: 
	 * @param objectMap
	 * @return
	 */

	public static Map<String,String> getSecurityClass(Context context, String Id, String sType) {
		Map<String,String> mpSecuritySetting = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util =new BusObjectAttribUtil();
		MapList mlCLass;

		StringList slSelects = new StringList();
		slSelects.add(ConstantsUtil.SELECT_NAME);
		slSelects.add(ConstantsUtil.SELECT_ID);
		slSelects.add(ConstantsUtil.SELECT_CURRENT);
		slSelects.add(ConstantsUtil.SELECT_TYPE);
		slSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slSelects.add(ConstantsUtil.LIBRARY_CLASS);


		try 
		{
			DomainObject domObject = new DomainObject(Id);
			mlCLass = domObject.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, sType, slSelects,
					null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domObject.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			Iterator itr = mlCLass.iterator();
			Map mpClass = new HashMap();

			StringBuilder sbName = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbDesc = new StringBuilder();
			StringBuilder sbState = new StringBuilder();
			StringBuilder sbLibrary = new StringBuilder();
			StringBuilder sbClassPath = new StringBuilder();

			while(itr.hasNext())
			{
				mpClass = (Map)itr.next();
				String sClassName=validator.getStringEquivalentForStringListWithComma(mpClass.get(ConstantsUtil.SELECT_NAME));
				String sClasscurrent=validator.getStringEquivalentForStringListWithComma(mpClass.get(ConstantsUtil.SELECT_CURRENT));
				String sClassType=validator.getStringEquivalentForStringListWithComma(mpClass.get(ConstantsUtil.SELECT_TYPE));
				String sClassDesc=validator.getStringEquivalentForStringListWithComma(mpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sClassId= validator.getStringEquivalentForStringListWithComma(mpClass.get(ConstantsUtil.SELECT_ID));

				util.formatData(sbType, sClassType);
				util.formatData(sbName, sClassName);
				util.formatData(sbDesc, sClassDesc);
				util.formatData(sbState, sClasscurrent);
			}

			mpSecuritySetting.put(ConstantsUtil.NAME, sbName.toString());
			mpSecuritySetting.put(ConstantsUtil.TYPE, sbType.toString());
			mpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
			mpSecuritySetting.put(ConstantsUtil.STATE, sbState.toString());


		}catch(Exception e){
			LOGGER.error("Error from FormulaCardBO: updateSecurity"+e);
			return new HashMap();
		}
		return  util.filterMapList(mpSecuritySetting);
	}





	private static String getClassPath(Context context, String sClassId, String sClassName) 
	{

		StringList selectStmts      = new StringList(2);
		selectStmts.addElement(DomainConstants.SELECT_ID);
		selectStmts.addElement(DomainConstants.SELECT_NAME);
		StringBuilder sbClassPath = new StringBuilder();
		try 
		{
			DomainObject domObj = new DomainObject(sClassId);
			MapList parentClasses   = (MapList)domObj.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_SUBCLASS,  // relationship pattern
					ConstantsUtil.QUERY_WILDCARD,         // type pattern
					selectStmts,        // Object selects
					null,               // relationship selects
					true,               // from
					false,              // to
					(short)0,           // expand level
					null,               // object where
					null,               // relationship where
					0);                 // limit
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domObj.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			parentClasses.sort(ConstantsUtil.SELECT_LEVEL,"descending","Integer");
			Iterator itr            = parentClasses.iterator();

			while (itr.hasNext())
			{
				Map parentClassMap      = (Map) itr.next();
				String parentclassName  = (String)parentClassMap.get(DomainConstants.SELECT_NAME);
				sbClassPath.append(parentclassName+"->"+sClassName).append(ConstantsUtil.SYMBL_NEWLINE);
			}

		}catch(Exception e){
			LOGGER.error("Error from FormulaCardBO: getClassPath"+e);
			return new String();
		}
		return  sbClassPath.toString();
	}

	/**
	 * 
	 * @param context
	 * @param sACSType
	 * @return
	 */
	public String getDisplayType(Context context,String sACSType) 
	{
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList slType=util.getStringList(sACSType);
		StringBuilder sbFinalType= new StringBuilder();

		try
		{
			for (int i = 0; i < slType.size(); i++) {
				String sFinalType=util.getMappedTypeData(context, slType.get(i));
				util.formatData(sbFinalType,sFinalType);
			}
		}catch(Exception e){
			LOGGER.error("Error from FormulaCardBO :  getDisplayType : " + e);
		}
		return util.replaceSquareBracketsOnly(sbFinalType.toString());
	}

	/**
	 * 
	 * @param slTMFilterID
	 * @return
	 */

	private StringList checkAccessForTM(Context context,StringList slTMFilterID) 
	{
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList slTMActualSecurityCheck = new StringList();
		try
		{
			for (int i = 0; i < slTMFilterID.size(); i++) 
			{
				String strOID = slTMFilterID.get(i);
				boolean 	bHasAccess = util.checkHasAccess(context, null, strOID);
				if (!bHasAccess) {
					strOID =ConstantsUtil.EMPTY_STRING;
				} 
				slTMActualSecurityCheck.add(strOID);
			}
		}catch(Exception e){
			LOGGER.error("Error from FormulaCardBO :  checkAccessForTM : " + e);
			new StringList();
		}
		return slTMActualSecurityCheck;
	}

	/**
	 * @param context
	 * @param doFC
	 * @param c 
	 * @param b 
	 * @return
	 */
	public Map getRelatedACS(Context context, DomainObject doFC, boolean bTo, boolean bFrom) 
	{
		StringBuilder sbPartType = new StringBuilder();
		StringBuilder sbPartID = new StringBuilder();
		StringBuilder sbPartName = new StringBuilder();
		StringBuilder sbPartState = new StringBuilder();
		StringBuilder sbPartTitle = new StringBuilder();

		StringBuilder sbPartRev = new StringBuilder();
		StringBuilder sbPartSpecSub = new StringBuilder();
		StringBuilder sbPartDisplay = new StringBuilder();


		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mpAcs = new HashMap();

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		MapList mapList;

		StringBuffer sbWhereCond = new StringBuffer();
		sbWhereCond.append("(");
		sbWhereCond.append(DomainObject.SELECT_CURRENT);

		sbWhereCond.append("==");
		sbWhereCond.append(ConstantsUtil.STATE_RELEASE);
		sbWhereCond.append(")");
		try 
		{
			mapList = doFC.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGAUTHORIZEDCONFIGURATIONSTANDARD,
					ConstantsUtil.SYMBL_ASTERISK, busSelect, null, bTo, bFrom, (short) 1, sbWhereCond.toString(),
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			Iterator objectListItr = mapList.iterator();
			while (objectListItr.hasNext()) 
			{
				Map mpTemp = (Map) objectListItr.next();
				String sPartType = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_TYPE)));
				String sDisplayType=busUtil.mapType(busUtil.getMappedTypeData(context,sPartType));
				sPartType=busUtil.mapType(sPartType);
				String sPartID = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_ID)));
				String sPartName = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_NAME)));
				String sPartState = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_CURRENT)));
				String sPartRev = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_REVISION)));
				String sPartTitle = validator	.getStringEquivalentForStringListWithComma((mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
				String sSpecSubType = busUtil.getSpecificationSubtype(context,sPartID);

				boolean bHasAccess =busUtil.checkHasAccess(context, null, sPartID);

				if (!bHasAccess || (!sPartState.equals(ConstantsUtil.RELEASE) && !sPartState.equals(ConstantsUtil.RELEASED) )) {
					sPartID= ConstantsUtil.NO_ACCESS;
				}

				busUtil.formatData(sbPartType, sPartType);
				busUtil.formatData(sbPartID, sPartID);
				busUtil.formatData(sbPartName, sPartName);
				busUtil.formatData(sbPartState, sPartState);
				busUtil.formatData(sbPartRev, sPartRev);
				busUtil.formatData(sbPartSpecSub, sSpecSubType);
				busUtil.formatData(sbPartDisplay, sDisplayType);
				busUtil.formatData(sbPartTitle, sPartTitle);

				mpAcs.put(ConstantsUtil.NAME, sbPartName.toString());
				mpAcs.put(ConstantsUtil.ID, sbPartID.toString());
				mpAcs.put(ConstantsUtil.TYPE, sbPartType.toString());
				mpAcs.put(ConstantsUtil.DISPLAY_TYPE,sbPartDisplay.toString());
				mpAcs.put(ConstantsUtil.REVISION, sbPartRev.toString());
				mpAcs.put(ConstantsUtil.STATE, sbPartState.toString());
				mpAcs.put(ConstantsUtil.SAPDESCRIPTION, sbPartTitle.toString());
				mpAcs.put(ConstantsUtil.SPECIFICATIONSUBTYPE,sbPartSpecSub.toString());
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FormulaCardBO -  Method :getRelatedACS " + e);
			return new HashMap();
		}
		return mpAcs;
	}

	//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- START
	/**
	 * 
	 * @param slTMFilterID
	 * @return
	 */

	private Map checkAccessForTMExternalUser(Context context,StringList slTMFilterID, StringList slTMFilterName, StringList slTMFilterType) 
	{
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList slTMActualSecurityCheck = new StringList();
		StringList slTMName = new StringList();
		StringList slTMType = new StringList();
		Map mpTempMap = new HashMap<>();
		try
		{
			for (int i = 0; i < slTMFilterID.size(); i++) 
			{
				String strOID = slTMFilterID.get(i);
				String strName = slTMFilterName.get(i);
				String strType = slTMFilterType.get(i);

				boolean bHasAccess = util.checkHasAccess(context, null, strOID);

				if (bHasAccess) {
					slTMActualSecurityCheck.add(strOID);
					slTMName.add(strName);
					slTMType.add(strType);
				} 

			}

			mpTempMap.put("id", slTMActualSecurityCheck);
			mpTempMap.put("name", slTMName);
			mpTempMap.put("type", slTMType);

		}catch(Exception e){
			LOGGER.error("Error from FormulaCardBO :  checkAccessForTM : " + e);
			new HashMap();
		}
		return mpTempMap;
	}	
	//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- END  	
}
