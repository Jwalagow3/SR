/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaSEPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.ManufacturingEquivalentPartBO;
import com.pg.us.specanywhere_enovia.bo.PQRBO;
import com.pg.us.specanywhere_enovia.bo.PackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.SupplierEquivalentPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaSEPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class EnoviaSEPServiceImpl  implements EnoviaSEPService{

	private static Logger LOGGER = Logger.getLogger(EnoviaSEPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	//Added by Jwala for Enovia Profiling -- START
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	//Added by Jwala for Enovia Profiling -- END
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String, String>> getSEPdata(String objId, Environment env) throws Exception {

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("SEP CONTEXT ELAPSED TIME : "+swContext.getTime());
		
		try 
		{
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
				
			SupplierEquivalentPartBO SEP = new SupplierEquivalentPartBO();
			DomainObject doSEP = SEP.getSepDO(context,objId);
			String strState = doSEP.getInfo(context, DomainConstants.SELECT_CURRENT);
			
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strState.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				else if(!strState.equals(ConstantsUtil.RELEASE)) {

					HashMap<String, String> errorMap = new HashMap<String, String>();
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strState.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			
			//SPEC: Release SR18x.6.0 - Added for 33481 by gaikwad.tg on Date 20 March 2021 -- START
			if(bManufacturerView)
			bSupplierView = true;
			//SPEC: Release SR18x.6.0 - Added for 33481 by gaikwad.tg on Date 20 March 2021 -- END
			
			
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			
			if(null==doSEP) {
				Map<String,String> ERROR = new HashMap<String,String>();
				ERROR.put("ERROR", "OBJECT NOT FOUND : "+objId);
				hmAttrib.put("ERROR", ERROR);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			Map BusinessObjectSelectableMap = SEP.getSupplierEquivalentPartSelectables(context);
			Map<String, StringList> ChilsObjectSelectableMap = SEP.getSepRelatedObjsSelectableMap(context);
			StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);

			DeviceProductPartBO DPPBO = new DeviceProductPartBO();
			
			StopWatch swnfo = new StopWatch();
			swnfo.start();
			slSelects.add(ConstantsUtil.CERTIFICATION_NAME);
			//Map resultMaps = doSEP.getInfo(context, slSelects);
			Map resultMaps = doSEP.getInfo(context, slSelects,SEP.addMultiSelects());
			swnfo.stop();
			LOGGER.info("SEP GET INFO ELAPSED TIME : "+swnfo.getTime());
			String strMaterialCertification=	validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.CERTIFICATION_NAME));
			strMaterialCertification = strMaterialCertification.replace("|", ",");
			
			
			boolean isExternal=util.isModificatinRequired();
			boolean showMaterialAndComp = false;
			boolean showSubstanceAndMaterial = false;
			Map<String,String> mpMaterialComposition = new HashMap<String,String>();
			Map<String,String> mpGPSAssessments = new HashMap<String,String>();
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- END
			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpReachResult = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String, String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpEnterpriseParts = new HashMap<String,String>();
			Map<String,String> mpEquivalentMep = new HashMap<String,String>();
			Map<String,String> mpCertification = new HashMap<String,String>();
			Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- START
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			
			RawMaterialPartBO RawBO = new RawMaterialPartBO();
			BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- END
			
			//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
			Map<String,String> mpMaterialResult = new HashMap<String,String>();
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
			Map<String,String> mpPackCert = new HashMap<>();
			String sType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

			//Header Content
			StopWatch sHeader = new StopWatch();
			sHeader.start();
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			mpHeaderResult.put(ConstantsUtil.NAME, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			//SPEC: 07-26-2022: Commented for SR22x.0_NovemberCW by Dominic -- START
			//mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
			//SPEC: 07-26-2022: Commented for SR22x.0_NovemberCW by Dominic -- END
			//Added by Pooja for 22x Defect 50409 -- START
			String sHasATSAttrVal = BbUtil.checkHasATSForSIS(context,resultMaps);
			mpHeaderResult.put(ConstantsUtil.HASATS, sHasATSAttrVal);
			//Added by Pooja for 22x Defect 50409 -- END
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			
			if(!bManufacturerView && !bSupplierView){
				mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
			}
			
			mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			String sClassification = util.getClassification(resultMaps);
			mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));
			sHeader.stop();
			LOGGER.info("SEP HEADER ELAPSED TIME : "+sHeader.getTime());


			//Attribute Data
			StopWatch swAttr = new StopWatch();
			swAttr.start();
			String lastUpdatedUser = ConstantsUtil.EMPTY_STRING;
			swAttr.stop();
			LOGGER.info("SEP GET HISTORY ELAPSED TIME : "+swAttr.getTime());
			
			
			StopWatch swAttrib = new StopWatch();
			swAttrib.start();
			
			if(bAllInfoView || bSupplierView || bManufacturerView) {
				mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				
				
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: Release SR18x.5.2: Modified for Defect 38524 by Amman ## -- START
				//mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
				PQRBO pqrBO = new PQRBO();
				mpAttribResult.put(ConstantsUtil.OWNER, pqrBO.getOriginatorName(context,resultMaps,ldapuser,ldappwd));
				//SPEC: Release SR18x.5.2: Modified for Defect 38524 by Amman ## -- END
				
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				String sClassifictaion = util.getClassification(resultMaps);
			
				//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- START
				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- END
				
				//Vendor
				//Modified by jwala for the ADO defect #7839 -- START 
				MapList mlObjList = commonBo.getVendorInfo(context, doSEP,ConstantsUtil.RELATIONSHIP_SUPPLYRESPONSIBILITY);
				//Modified by jwala for the ADO defect #7839 -- END 
				
				Iterator objectListItr = mlObjList.iterator();
				while (objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();
					
					String strVendor   = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORGANIZATION_NAME));
					String strVendorId = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORGANIZATIONID));
					strVendor = strVendor+ConstantsUtil.SYMBL_TILDA+strVendorId;
					mpAttribResult.put(ConstantsUtil.VENDOR, strVendor);
					mpAttribResult.put(ConstantsUtil.VENDORID, strVendorId);
					mpAttribResult.put(ConstantsUtil.VENDOR_STREET_ADDRESS, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ADDRESS)));
					mpAttribResult.put(ConstantsUtil.VENDOR_STREET_ADDRESS_NUMBER, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHOUSENUMBER)));
					mpAttribResult.put(ConstantsUtil.VENDOR_CITY, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CITY)));
					mpAttribResult.put(ConstantsUtil.VENDOR_STATE, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATEREGION)));
					mpAttribResult.put(ConstantsUtil.VENDOR_MARKET, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COUNTRY)));
						mpAttribResult.put(ConstantsUtilIRM.VENDOORZIPPOSTALCODE, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_POSTALCODE)));
					break;
				}
             	mpAttribResult.put(ConstantsUtilIRM.VENDORTYPE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.STR_RELATIONSHIP_PGMEPTOPGPLIVENDORTYPEFORMEP)));

				//Reference Docs
				StopWatch swReference= new StopWatch();
				swReference.start();
				StringList slRefDocSelects = SEP.getRefDocBusSelect(context);
				MapList mlRefDocs = doSEP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
						ConstantsUtil.SYMBL_ASTERISK, slRefDocSelects, new StringList(), false, true, (short) 1,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				if(mlRefDocs.size()>0) {
					mapReferenceDocs =	util.parseRefDoclist(context, mlRefDocs);
				}
				swReference.stop();
				LOGGER.info("SEP  Reference ELAPSED TIME : "+swReference.getTime());
				
			}
			//Added by Ketan for Req. no. 47200 -- START
			if(!bSupplierView) {
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION))));
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS))));
			}
			//Added by Ketan for Req. no. 47200 -- END
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- START
			if(bSupplierView || bAllInfoView)
			{
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.FRANCHISE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE)));
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				
			}
			boolean isRM = false;
			if(bAllInfoView || bSupplierView) {
				if(!bSupplierView)
				{
					
					
					mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING); //Modified by Ketan for Internal Defect
					
					mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				
					mpAttribResult.put(ConstantsUtil.TRADENAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET)))?(String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET) : ConstantsUtil.EMPTY_STRING);
					
					//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
					mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
					//Commented by Ketan for Req. no. 47200
					//mpAttribResult.put(ConstantsUtil.MATERIALRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION) : ConstantsUtil.EMPTY_STRING);
					//mpAttribResult.put(ConstantsUtil.MATERIALRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
					//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
					
					swAttrib.stop();
					LOGGER.info("SEP GET Attribute ELAPSED TIME : "+swAttrib.getTime());
					
					//SPEC: Release SR18x.6.0 - Added for ExternalDefect# by gaikwad.tg on Date 29 April 2021 -- END
		
				}
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				//Organization Data
				StopWatch swOrganization = new StopWatch();
				swOrganization.start();
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)));
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)));
				swOrganization.stop();
				LOGGER.info("SEP Organization ELAPSED TIME : "+swOrganization.getTime());
	
				
				//Reach
				mpReachResult.put(ConstantsUtil.STATUS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS)));
				mpReachResult.put(ConstantsUtil.REGISTRATIONNUMBER, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER)));
				mpReachResult = util.filterMapList(mpReachResult);
				//Lifecycle
				String sPhysicalId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID));
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = util.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("SEP  LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- START
				String strCOCAName = (String) mpLifeCycleApproval.get(ConstantsUtil.CO);
				String strEnvClass = (String) resultMaps.get(ConstantsUtilIRM.SELECTABLE_RELATIONSHIP_PGMATERIALTOPGPLIENVCLASS);
				String strPOAImpactConf = (String) resultMaps.get(ConstantsUtilIRM.SELECTABLE_ATTRIBUTE_PG_POA_IMPACT_CONFIRMATION);
				mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty(strCOCAName))?strCOCAName : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LEGACY_ENV_CLASS, (validator.isNotNullOrEmpty(strEnvClass))?strEnvClass : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.POAIMPCONF, (validator.isNotNullOrEmpty(strPOAImpactConf))?strPOAImpactConf : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- END
				
				//RelatedSpec
				StopWatch swRelatedSpec = new StopWatch();
				swRelatedSpec.start();
				mpRelatedSpecResult = util.updatePartSpec(context, resultMaps);
				swRelatedSpec.stop();
				LOGGER.info("SEP  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());
	
				//SPEC: <06.07.2022>: Satyam Added for Internal Defect  -- START
				if(!bSupplierView) {
					//Ownership
					StopWatch swOwnerShip = new StopWatch();
					swOwnerShip.start();
					mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)));
					mapOwnerShipResult.put(ConstantsUtil.SEGMENT, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.strSegment)));
					mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, validator.DateFormatter(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MODIFIED))));
					mapOwnerShipResult.put(ConstantsUtil.APPROVERS,validator.getStringEquivalentForStringList(mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)));
					mapOwnerShipResult.put(ConstantsUtil.COOWNERS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS)));
					mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
					swOwnerShip.stop();
					LOGGER.info("SEP  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());
				}
				//SPEC: <06.07.2022>: Satyam Added for Internal Defect  -- END
	
				//Security
				StopWatch swSecurity = new StopWatch();
				swSecurity.start();
				mpSecurity =commonBo.updateSecurity(context,resultMaps);
				swSecurity.stop();
				//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- START
				if (mpSecurity.containsKey(ConstantsUtil.HASCLASSACCESS)) {
					mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				}
				//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- END
				LOGGER.info("SEP  Security ELAPSED TIME : "+swSecurity.getTime());

				
				/**
				 *  Enterprise Parts
				 */
				StopWatch swEnterprise = new StopWatch();
				swEnterprise.start();
				StringList busSelect = new StringList();
				busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
				busSelect.add(ConstantsUtil.SELECT_NAME);
				busSelect.add(ConstantsUtil.SELECT_REVISION);
				busSelect.add(ConstantsUtil.SELECT_TYPE);
				busSelect.add(ConstantsUtil.SELECT_CURRENT);
				busSelect.add(ConstantsUtil.SELECT_POLICY);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);//Added by Pooja, Req - 45670
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
				busSelect.add(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
				busSelect.add(ConstantsUtil.SELECT_ID);
				
				StringList relSelect = new StringList();
				relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME);
				relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE);
				relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION);
				relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRID);
				relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRTYPE);
				relSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
				
				StringBuilder sbName = new StringBuilder();
				StringBuilder sbRev = new StringBuilder();
				StringBuilder sbType = new StringBuilder();
				StringBuilder sbDesc = new StringBuilder();
				StringBuilder sbState = new StringBuilder();
				StringBuilder sbSupName = new StringBuilder();
				StringBuilder sbSupRev = new StringBuilder();
				StringBuilder sbSupType = new StringBuilder();
				StringBuilder sbSupDesc = new StringBuilder();
				StringBuilder sbSupState = new StringBuilder();
				
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
				StringBuilder sbId = new StringBuilder();
				StringBuilder sbSupId = new StringBuilder();
				StringBuilder sbSupManufacturer = new StringBuilder();
				StringBuilder sbPQRName = new StringBuilder();
				StringBuilder sbPQRRev = new StringBuilder();
				StringBuilder sbPQRType = new StringBuilder();
				StringBuilder sbPQRState = new StringBuilder();
				StringBuilder sbPQRId = new StringBuilder();
				StringBuilder sbTitle = new StringBuilder();
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
				
				Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
				relPattern.addPattern(ConstantsUtil.RELATIONSHIP_MANUFACTUREREQUIVALENT);
				//SPEC: Release SR18x.5.2: Added for Defect 36564 by Jwala ## -- START
				 Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PGPROMOTIONALITEMPART);
				  typePattern.addPattern(ConstantsUtil.TYPE_PACKAGINGMATERIALPART);
				  typePattern.addPattern(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART);
				  typePattern.addPattern(ConstantsUtil.TYPE_PGONLINEPRINTINGPART);
				  typePattern.addPattern(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART);
				  typePattern.addPattern(ConstantsUtil.TYPE_FABRICATEDPART);
				  typePattern.addPattern(ConstantsUtil.TYPE_PGRAWMATERIAL);
				  typePattern.addPattern(ConstantsUtil.TYPE_RAWMATERIALPART);
				  typePattern.addPattern(ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART);
				  typePattern.addPattern(ConstantsUtil.TYPE_SOFTWAREPART);
				  typePattern.addPattern(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				  typePattern.addPattern(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
				  
				//SPEC: Release SR18x.5.2: Added for Defect 36564 by Jwala ## -- END

					//SPEC: <07.04.2022>: Guna Modified for Req 35586 22x Release  -- START
				  String strWhere ="current !="+ConstantsUtil.STATE_OBSOLETE+" && current !="+ConstantsUtilIRM.STATE_LOCKED+"";
					//SPEC: <07.04.2022>: Guna Modified for Req 35586 22x Release  -- END
				//SPEC: <08.04.2022>: Guna Modified for Req 42491 22x Release  -- START
				  if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM) || sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP)) {
				  strWhere ="current =="+ConstantsUtil.STATE_RELEASE+" && current !="+ConstantsUtilIRM.STATE_LOCKED+"";
				  }
				//SPEC: <08.04.2022>: Guna Modified for Req 42491 22x Release  -- END
				  
				  MapList mlEnterpriseParts = doSEP.getRelatedObjects(context, relPattern.getPattern(),
						  typePattern.getPattern(), busSelect, relSelect, true, true, (short) 1,
						  strWhere, ConstantsUtil.EMPTY_STRING, 500);
				  int size=mlEnterpriseParts.size();
					if (size == 500) {
						String[] sError = ConstantsUtilIRM.E109.split(ConstantsUtil.SYMBL_COLON);
						mpHeaderResult.put(ConstantsUtil.ERROR, sError[1].toString());
					}

				  mlEnterpriseParts.sort(DomainConstants.SELECT_NAME, "ascending", "String");

				  Iterator entPartsListItr = mlEnterpriseParts.iterator();
				  while (entPartsListItr.hasNext()) {
					  Map objectMap = (Map) entPartsListItr.next();

					  String sPolicy = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_POLICY));

					  if(sPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT)) {
						  String supDesc = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
						  String supCurrent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
						  String supManfacturer=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
						  String supId = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						//Added by Pooja, Req - 45670 - Start
						  String supTitle=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//Added by Pooja, Req - 45670 - END
						if (!supCurrent.equalsIgnoreCase("Release")
								&& !supCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED)) {

							supId = ConstantsUtil.NO_ACCESS;
						}
						boolean showData = util.checkHasAccess(context, sUserType, validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID)));
						if (!showData) {
							supId = ConstantsUtil.NO_ACCESS;
							supCurrent = ConstantsUtil.NO_ACCESS;
							supManfacturer = ConstantsUtil.NO_ACCESS;
							supDesc = ConstantsUtil.NO_ACCESS;
						}
						if (UIUtil.isNotNullAndNotEmpty(supCurrent) && supCurrent.equalsIgnoreCase(ConstantsUtil.STATE_PRELIMINARY))
						{
							supCurrent = ConstantsUtil.STATE_INWORK;
						}
						if(isExternal && supId.equalsIgnoreCase(ConstantsUtil.NO_ACCESS))
						continue;
							
						formatData(sbSupName,validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME)));
						formatData(sbSupRev, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION)));
						formatData(sbSupType, util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE))));
						formatData(sbSupDesc, supDesc);
						formatData(sbSupId, supId);
						formatData(sbDesc, supDesc);
						formatData(sbSupState, supCurrent);
						formatData(sbSupManufacturer, supManfacturer);
						formatData(sbTitle, supTitle);//Added by Pooja, Req - 45670
						// modified by Ganesh for defect 39125 ---->end
					  }else {
						  
						  if(objId.equalsIgnoreCase((String)objectMap.get(ConstantsUtil.SELECT_ID))) {
							 continue;
						  }
							boolean isShowParent = true;
							String supTempId = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
							String supTempCurrent = util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT)));
							String supTempDesc = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
							
							boolean showData = util.checkHasAccess(context, sUserType, validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID)));
							if (!showData) {
								supTempId = ConstantsUtil.NO_ACCESS;
								supTempCurrent = ConstantsUtil.NO_ACCESS;
								supTempDesc = ConstantsUtil.NO_ACCESS;
								isShowParent = false;
							}
							else
							{
								if(!(supTempCurrent.equals(ConstantsUtil.RELEASE)|| supTempCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED)))
									supTempId = ConstantsUtil.NO_ACCESS;
							}
							if(isExternal && supTempId.equalsIgnoreCase(ConstantsUtil.NO_ACCESS))
							continue;
							
						  String strPQRIdClassType = validator.getClassType(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID));
						  
						  if(strPQRIdClassType.equalsIgnoreCase(ConstantsUtil.STRING)||strPQRIdClassType.equalsIgnoreCase(ConstantsUtil.EMPTY_STRING)) 
						  {
							//SPEC: 13-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50594-- START
							  if(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE)).equalsIgnoreCase(ConstantsUtil.STATE_FROZEN) && isExternal) {
								  continue;
							  }
							//SPEC: 13-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50594-- END

							  //SPEC: Release SR18x.6.0 - Added for Defect# 41942 by gaikwad.tg on Date 30 March 2021 -- START
							  String sTempPQRID = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID));
							  String sTempPQRType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRTYPE));
							  String sTempPQRName = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME));
							  String sTempPQRRev = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION));
							  String sTempPQRState = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE));

							  sTempPQRState = sTempPQRState.replace(ConstantsUtil.RELEASED, ConstantsUtil.APPROVED);

							  if(supTempId.equalsIgnoreCase(ConstantsUtil.NO_ACCESS))
								  sTempPQRID = ConstantsUtil.NO_ACCESS;

							  if(sTempPQRState.equalsIgnoreCase(ConstantsUtil.RELEASED)||sTempPQRState.equalsIgnoreCase(ConstantsUtil.APPROVED)||sTempPQRState.equalsIgnoreCase(ConstantsUtil.QUALIFICATION_STATE_QUALIFIED)) {
								  formatData(sbPQRId,isShowParent ? sTempPQRID : ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRType,isShowParent ? sTempPQRType : ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRName,isShowParent ? sTempPQRName : ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRRev,isShowParent ? sTempPQRRev : ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRState,isShowParent ? sTempPQRState : ConstantsUtil.NO_ACCESS); 
							  }
							//SPEC: 14-09-2022: Dominic Added for SR22x.0_NovemberCW Defect 50594-- START
							  else if(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE)).equalsIgnoreCase(ConstantsUtil.STATE_FROZEN)) {
									
									  formatData(sbPQRId,DomainConstants.EMPTY_STRING);
									  formatData(sbPQRType,DomainConstants.EMPTY_STRING);
									  formatData(sbPQRName,DomainConstants.EMPTY_STRING);
									  formatData(sbPQRRev,DomainConstants.EMPTY_STRING);
									  formatData(sbPQRState,DomainConstants.EMPTY_STRING);
							 }
							//SPEC: 14-09-2022: Dominic Added for SR22x.0_NovemberCW Defect 50594-- END
							  else {
								
								  formatData(sbPQRId,ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRType,isShowParent ? sTempPQRType : ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRName,isShowParent ? sTempPQRName : ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRRev,isShowParent ? sTempPQRRev : ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRState,isShowParent ? sTempPQRState : ConstantsUtil.NO_ACCESS); 
								  //SPEC: Release SR18x.6.0 - Added for Defect# 41942 by gaikwad.tg on Date 30 March 2021 -- END
								//}
							  }
						  }
						  
						  else
						  {
							  String strPQRId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID));
							  String strPQRType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRTYPE));
							  String strPQRName = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME));
							  String strPQRRev = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION));
							  String strPQRState = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE)).replace(ConstantsUtil.RELEASED, ConstantsUtil.APPROVED);
							  
							  String[] slPQRId = strPQRId.split(ConstantsUtil.SYMBL_COMMA);
							  String[] slPQRType = strPQRType.split(ConstantsUtil.SYMBL_COMMA);
							  String[] slPQRName = strPQRName.split(ConstantsUtil.SYMBL_COMMA);
							  String[] slPQRRev = strPQRRev.split(ConstantsUtil.SYMBL_COMMA);
							  String[] slPQRState = strPQRState.split(ConstantsUtil.SYMBL_COMMA);
							  
							  StringList sPQRId = new StringList();
							  StringList sPQRType = new StringList();
							  StringList sPQRName = new StringList();
							  StringList sPQRRev = new StringList();
							  StringList sPQRState = new StringList();
							  
							  for(int i=0;i<slPQRId.length;i++) {
								  if(i!=0) {
									  slPQRId[i] = slPQRId[i].substring(1);
									  slPQRType[i] = slPQRType[i].substring(1);
									  slPQRName[i] = slPQRName[i].substring(1);
									  slPQRRev[i] = slPQRRev[i].substring(1);
									  slPQRState[i] = slPQRState[i].substring(1);
								  }
								//SPEC: 13-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50594-- START
								  if(slPQRState[i].equalsIgnoreCase(ConstantsUtil.STATE_FROZEN) && isExternal) {
									  continue;
								  }
								//SPEC: 13-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50594-- END
								//SPEC: Release SR18x.6.0 - Added for Defect# 41942 by gaikwad.tg on Date 30 March 2021 -- START
								  slPQRState[i].replace(ConstantsUtil.RELEASED, ConstantsUtil.APPROVED);
								  
								  if(supTempId.equalsIgnoreCase(ConstantsUtil.NO_ACCESS))
									  slPQRId[i] = ConstantsUtil.NO_ACCESS;
								  
								  if(slPQRState[i].equalsIgnoreCase(ConstantsUtil.RELEASED) || slPQRState[i].equalsIgnoreCase(ConstantsUtil.APPROVED) || slPQRState[i].equalsIgnoreCase(ConstantsUtil.QUALIFICATION_STATE_QUALIFIED)) {
									  sPQRId.add(isShowParent ? slPQRId[i] : ConstantsUtil.NO_ACCESS);
									  sPQRType.add(isShowParent ? slPQRType[i] : ConstantsUtil.NO_ACCESS);
									  sPQRName.add(isShowParent ? slPQRName[i] : ConstantsUtil.NO_ACCESS);
									  sPQRRev.add(isShowParent ? slPQRRev[i] : ConstantsUtil.NO_ACCESS);
									  sPQRState.add(isShowParent ? slPQRState[i] : ConstantsUtil.NO_ACCESS);
								  }
								  else {
									
									  sPQRId.add(ConstantsUtil.NO_ACCESS);
									  sPQRType.add(isShowParent ? slPQRType[i] : ConstantsUtil.NO_ACCESS);
									  sPQRName.add(isShowParent ? slPQRName[i] : ConstantsUtil.NO_ACCESS);
									  sPQRRev.add(isShowParent ? slPQRRev[i] : ConstantsUtil.NO_ACCESS);
									  sPQRState.add(isShowParent ? slPQRState[i] : ConstantsUtil.NO_ACCESS);
								  //SPEC: Release SR18x.6.0 - Added for Defect# 41942 by gaikwad.tg on Date 30 March 2021 -- END
									//}
								  }
							  }
							  //SPEC: Release SR18x.6.0.1 - Added for Defect# 43157  by gaikwad.tg on Date 26 May 2021 -- START
							//SPEC: 14-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50594-- START
							  if((slPQRId.length>0 && sPQRId.isEmpty()) || (validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE)).equalsIgnoreCase(ConstantsUtil.STATE_FROZEN))) {
							//SPEC: 14-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50594-- END
								sPQRId.add(DomainConstants.EMPTY_STRING);
								sPQRType.add(DomainConstants.EMPTY_STRING);
								sPQRName.add(DomainConstants.EMPTY_STRING);
								sPQRRev.add(DomainConstants.EMPTY_STRING);
								sPQRState.add(DomainConstants.EMPTY_STRING); 
							  }
							  //SPEC: Release SR18x.6.0.1 - Added for Defect# 43157  by gaikwad.tg on Date 26 May 2021 -- END
							  formatData(sbPQRId,sPQRId.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING));
							  formatData(sbPQRType,sPQRType.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING));
							  formatData(sbPQRName,sPQRName.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING));
							  formatData(sbPQRRev,sPQRRev.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING));
							  formatData(sbPQRState,sPQRState.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING));
							//SPEC: Release SR18x.6.0 - #Defect-42888 Added  by gaikwad.tg on Date 03 May 2021 -- END (Reverting changes made for Internal Defect)
						  }
						  
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- START
						  formatData(sbName,validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME)));
						  formatData(sbRev, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION)));
						  formatData(sbType, util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE))));
						  formatData(sbDesc, supTempDesc);
						  formatData(sbState, supTempCurrent);
						  formatData(sbId,supTempId);
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- END
					  }
				}
				mpEnterpriseParts.put(ConstantsUtil.NAME, sbName.toString());
				mpEnterpriseParts.put(ConstantsUtil.REVISION, sbRev.toString());
				mpEnterpriseParts.put(ConstantsUtil.TYPE, sbType.toString());
				mpEnterpriseParts.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
				mpEnterpriseParts.put(ConstantsUtil.STATE, sbState.toString());
				
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
				mpEnterpriseParts.put(ConstantsUtil.ID, sbId.toString());
				mpEnterpriseParts.put(ConstantsUtil.PQRNAME, sbPQRName.toString());
				mpEnterpriseParts.put(ConstantsUtil.PQRSTATE, sbPQRState.toString());
				mpEnterpriseParts.put(ConstantsUtil.PQRREVISION, sbPQRRev.toString());
				mpEnterpriseParts.put(ConstantsUtil.PQRID, sbPQRId.toString());
				mpEnterpriseParts.put(ConstantsUtil.PQRTYPE, sbPQRType.toString());
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
				
				swEnterprise.stop();
				LOGGER.info("SEP  ENTERPRISE ELAPSED TIME : "+swEnterprise.getTime());
				
				
				/**
				 * Equivalent SEP
				 */
				mpEquivalentMep.put(ConstantsUtil.NAME, sbSupName.toString());
				mpEquivalentMep.put(ConstantsUtil.REVISION, sbSupRev.toString());
				mpEquivalentMep.put(ConstantsUtil.TYPE, sbSupType.toString());
				mpEquivalentMep.put(ConstantsUtil.DESCRIPTION, sbSupDesc.toString());
				mpEquivalentMep.put(ConstantsUtil.STATE, sbSupState.toString());
				mpEquivalentMep.put(ConstantsUtilIRM.ALLOWED_MEP_TITLE, sbTitle.toString());//Added by Pooja, Req - 45670
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
				mpEquivalentMep.put(ConstantsUtil.MANUFACTURER, sbSupManufacturer.toString());
				mpEquivalentMep.put(ConstantsUtil.ID, sbSupId.toString());
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43132 on Date 26/05/2021 --START
				mpEquivalentMep.put(ConstantsUtil.SUPPLIER, sbSupManufacturer.toString());
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43132 on Date 26/05/2021 --END
				
				
				/**
				 * Certification
				 */
				// Guna Added for Defect 37250  18x.5.2 Release -- START
				// Added by Jwala for the req 4945 - START
				if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					StopWatch swCert = new StopWatch();
					swCert.start();
					//Modified by Subhajit for Defect 50614
					MapList mlCertifications = SEP.getCertifications(context, objId, mpHeaderResult);
					StringBuilder sbCertName = new StringBuilder();
					StringBuilder sbCertRev = new StringBuilder();
					StringBuilder sbCertType = new StringBuilder();
					StringBuilder sbCertDesc = new StringBuilder();
					StringBuilder sbCertState = new StringBuilder();
					StringBuilder sbCertifications = new StringBuilder();
					StringBuilder sbStatus = new StringBuilder();
					StringBuilder sbCExpirationDate = new StringBuilder();
					StringBuilder sbCertId = new StringBuilder();
					//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- START
					StringBuilder sbCertSource = new StringBuilder();
					//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- END
					Iterator itrCerts = mlCertifications.iterator();
					while (itrCerts.hasNext()) {
						Map objectMap = (Map) itrCerts.next();
						String strCertification  =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_VALUE));
						StringTokenizer tokenize = new StringTokenizer(strCertification,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						String strStatus =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_STATUS));
						String strExpireDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_EXPIRATION_DATE));

						StringTokenizer statusTokenize = new StringTokenizer(strStatus,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						StringTokenizer expireDateTokenize = new StringTokenizer(strExpireDate,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- START
						String strCertificationSource  =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_CERTIFICATION_SOURCE));
						StringTokenizer sourceTokenize = new StringTokenizer(strCertificationSource,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- END
						while(tokenize.hasMoreTokens())
						{
							String strCert  = tokenize.nextToken().toString().trim();
							//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- START
							String strCertSource =ConstantsUtil.EMPTY_STRING;
							if(sourceTokenize.hasMoreTokens()) {
								strCertSource =sourceTokenize.nextToken().toString().trim();
							}
							//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- END
							// SPEC :: Added by Jwala for  Defect#41799 -- START
							String strCurrent = (String)objectMap.get(ConstantsUtil.SELECT_CURRENT).toString();
							if(!strCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) && !strCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- START
								if(isExternal)
									continue;
								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- END
								formatData(sbCertId,ConstantsUtil.NO_ACCESS);
							}else{
								formatData(sbCertId, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID)));
							}
							// SPEC :: Added by Jwala for  Defect#41799 -- END

							formatData(sbCertName,validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME)));
							formatData(sbCertRev, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION)));
							formatData(sbCertType, util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE))));
							formatData(sbCertDesc, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION)));
							formatData(sbCertState, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT)));
							formatData(sbCertifications, strCert);
							//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- START
							formatData(sbCertSource,strCertSource);
							//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- END
							if(statusTokenize.hasMoreTokens() && expireDateTokenize.hasMoreTokens()){
								formatData(sbStatus,statusTokenize.nextToken().toString().trim());
								formatData(sbCExpirationDate,expireDateTokenize.nextToken().toString().trim());
							}else{
								formatData(sbStatus,ConstantsUtil.EMPTY_STRING);
								formatData(sbCExpirationDate,ConstantsUtil.EMPTY_STRING);
							}


						}
					}
					mpCertification.put(ConstantsUtil.NAME, sbCertName.toString());	
					mpCertification.put(ConstantsUtil.REVISION, sbCertRev.toString());
					mpCertification.put(ConstantsUtil.TYPE, sbCertType.toString());
					mpCertification.put(ConstantsUtil.DESCRIPTION, sbCertDesc.toString());
					mpCertification.put(ConstantsUtil.STATE, sbCertState.toString());
					mpCertification.put(ConstantsUtil.ID, sbCertId.toString());
					mpCertification.put(ConstantsUtil.CERTIFICATION, sbCertifications.toString());
					mpCertification.put(ConstantsUtil.STATUS, sbStatus.toString());
					mpCertification.put(ConstantsUtil.EXPIRATIONDATE, sbCExpirationDate.toString());
					//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- START
					mpCertification.put(ConstantsUtilIRM.CERTIFICATIONSOURCE, sbCertSource.toString());
					//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- END
					swCert.stop();
					LOGGER.info("SEP CERTIFICATION ELAPSED TIME : "+swCert.getTime());
					// Guna Added for Defect 37250  18x.5.2 Release -- END
				}
				// Added by Jwala for the req 4945 - END
				/**
				 * Materials & Composition SECTION
				 */
				
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
				//Condition To check for access to Material & Composition category
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- START
				String strType = (String) resultMaps.get(ConstantsUtil.SELECT_TYPE);
				String strAttrIntMatFor = (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR);
				String strArchstatus = (String) resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGILMARCHIVALSTATUS);
				String strPolClass = (String) resultMaps.get(ConstantsUtilIRM.SELECT_POLICYCLASSIFICATION);
				String strpolicy = (String) resultMaps.get(ConstantsUtil.SELECT_POLICY);
				String sContextObjectId = (String) resultMaps.get(ConstantsUtil.SELECT_ID);
				String sFromTYpeSuppEq = (String) resultMaps.get(ConstantsUtilIRM.SELECT_SUPPLIEREQUIVALENT_FROM_TYPE);
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 22 April 2021 -- START (FOr Internal Defect)
				String sFromTYpeManuEq = (String) resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGEQUIVALENT_TO_TYPE);
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 22 April 2021 -- END (FOr Internal Defect)
				if(UIUtil.isNullOrEmpty(sFromTYpeSuppEq)) {
					sFromTYpeSuppEq = strType;
				}
				String strSpecSubType =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING;
				if(((UIUtil.isNotNullAndNotEmpty(sFromTYpeSuppEq) && util.getTypeIncludeForMatAndComp().contains(sFromTYpeSuppEq)) || (UIUtil.isNotNullAndNotEmpty(sFromTYpeManuEq) && util.getTypeIncludeForMatAndComp().contains(sFromTYpeManuEq))) && (sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_RAWMATERIALPART) && (!strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.SUBTYPE_WITH_MCP) || !strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.DEVICE))) && strArchstatus.equalsIgnoreCase(ConstantsUtil.FALSE)) {
				showMaterialAndComp = true;
				}
				if((((strPolClass.equalsIgnoreCase(ConstantsUtilIRM.EQUIVALENT) || strPolClass.equalsIgnoreCase(ConstantsUtil.PRODUCTION) || strPolClass.equalsIgnoreCase(ConstantsUtil.DEVELOPMENT)) && (UIUtil.isNotNullAndNotEmpty(sFromTYpeSuppEq) && util.getTypeIncludeForSubAndMat().contains(sFromTYpeSuppEq))) || ((sFromTYpeSuppEq.equalsIgnoreCase(ConstantsUtil.TYPE_PGPROMOTIONALITEMPART) || sFromTYpeSuppEq.equalsIgnoreCase(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART)) && strpolicy.equalsIgnoreCase(ConstantsUtil.POLICY_SUPPLIEREQUIVALENT))) && !strpolicy.equalsIgnoreCase(ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT) && strArchstatus.equalsIgnoreCase(ConstantsUtil.FALSE)) {
				showSubstanceAndMaterial = true;
				}
				//SPEC: Modified by Ajay for Req. no. 30224 START
				if((sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_RAWMATERIALPART) && (strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.SUBTYPE_WITH_MCP) || strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.DEVICE))) || sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_DEVICEPRODUCTPART)) {
					showSubstanceAndMaterial = true;
				//SPEC: 30-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50470-- START
				}else if((sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART) || sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_INTERMEDIATEPRODUCTPART) || ((sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_PGRAWMATERIAL)) && (!strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.SUBTYPE_WITH_MCP) && !strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.DEVICE))))) {
				//SPEC: 30-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50470-- END
					showMaterialAndComp = true;
				}
				//SPEC: Modified by Ajay for Req. no. 30224 END
			isRM = (sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_PGRAWMATERIAL));
			//Added by Ketan for Req. no. 6045 -- START
			boolean bSupplierOrSP = false;
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
				bSupplierOrSP = true;
			}
			resultMaps.put(ConstantsUtilIRM.IS_SUPPLIER, bSupplierOrSP);
			//Added by Ketan for Req. no. 6045 -- END
			if(showMaterialAndComp)
			{
				//Modified by Ketan for Req no 2332
				if(!isRM) {
				StopWatch swSubts = new StopWatch();
				swSubts.start();
				//RawMaterialPartBO RawBO = new RawMaterialPartBO();
				mpMaterialComposition = RawBO.getMaterialCompositionAndSubstance(context, resultMaps);
				mpMaterialComposition = util.verifyOwnership(context,mpMaterialComposition);
				if(bSupplierView || bManufacturerView) 
				{
					mpMaterialComposition=util.filterPhase(mpMaterialComposition);
					mpMaterialComposition = util.filterMapList(mpMaterialComposition);
				}
				swSubts.stop();
				LOGGER.info("SEP GET SUBSTANCE ELAPSED TIME : "+swSubts.getTime());
				}
				else if(isRM) { //Modified by Ketan for Req. no. 6045

					StopWatch swSubts = new StopWatch();
					swSubts.start();
					//RawMaterialPartBO RawBO = new RawMaterialPartBO();
					mpMaterialComposition = RawBO.getMaterialCompositionAndSubstance(context, resultMaps);
					mpMaterialComposition = util.verifyOwnership(context,mpMaterialComposition);
					if(bSupplierView || bManufacturerView) 
					{
						mpMaterialComposition=util.filterPhase(mpMaterialComposition);
						mpMaterialComposition = util.filterMapList(mpMaterialComposition);
					}
					swSubts.stop();
					LOGGER.info("SEP GET SUBSTANCE ELAPSED TIME : "+swSubts.getTime());
					
				}
			}
			if(showSubstanceAndMaterial)
			{
				StopWatch swMSubts = new StopWatch();
				swMSubts.start();
				PackagingMaterialPartBO pmpBO = new PackagingMaterialPartBO();
				mpMaterialResult=pmpBO.getSubstances(context,resultMaps);
				if(bSupplierView || bManufacturerView) 
				{
					mpMaterialResult=util.filterPhase(mpMaterialResult);
					mpMaterialResult=util.filterMapList(mpMaterialResult);
				}
				//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- START
				//SPEC: Modified by Ajay for Req. no. 30224 START
				if(sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_DEVICEPRODUCTPART) || (sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_RAWMATERIALPART) && (strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.SUBTYPE_WITH_MCP) || strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.DEVICE)))) { //Modified by Ketan for Defect no. 51812
					mpMaterialResult.remove(ConstantsUtil.TRADE_NAME);
					mpMaterialResult.remove(ConstantsUtil.LAYER_DESC);
				}
				//SPEC: Modified by Ajay for Req. no. 30224 END
				//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- END
				swMSubts.stop();
				LOGGER.info("SEP GET SUBSTANCE&MATERIAL ELAPSED TIME : "+swMSubts.getTime());
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- START
			if(!bSupplierView)
			{
				/**
				 * LOAD GPSASSESSMENTS SECTION
				 * */
				StopWatch swgps= new StopWatch();
				swgps.start();
				mpGPSAssessments = DPPBO.getGPSAssessments(context, sContextObjectId);
				mpGPSAssessments = util.filterMapList(mpGPSAssessments);
				swgps.stop();
				LOGGER.info("SEP  GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());
				//SPEC: Release SR18x.6.0 - MODIFIED  by gaikwad.tg on Date 02 Mar 2021 -- END
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- END	
				/**
				 * LOAD IP CLASSES SECTION
				 */
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				mpIpSecuritySetting = SEP.getIpClass(context, doSEP, slIpSelects);
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
				
				//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- START
				if (mpIpSecuritySetting.containsKey(ConstantsUtil.HASCLASSACCESS)) {
					mpIpSecuritySetting.remove(ConstantsUtil.HASCLASSACCESS);
				}
				//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- END
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- START
				if(!bSupplierView)
				{
					/**
					 * FILES SECTION
					 */
					
					String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
					String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
					String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
					StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
					
					//	SPEC	 Added on 12-Dec-2020 by Chandra for Defect 37746 ##--END
					//SPEC: 29-06-2022: Pooja Added for Internal Defect -- START
					CommonDocBO cdoc = new CommonDocBO();
					String strFileSize = cdoc.updateFileSize(FileSize);
					//SPEC: 29-06-2022: Pooja Added for Internal Defect -- END
					mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
					mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
					mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
					mpFiles.put(ConstantsUtil.FILESSIZES, strFileSize);
					//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
				}
				
				//SPEC: <09.06.2022>: Guna Added for Req 33476 and 41754 22x Release  -- START
				/**
				 * LOAD PACKAGING CERTIFICATIONS
				 * */
				if(sType.equals(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART) || sType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
					StopWatch swPkgCert = new StopWatch();
					swPkgCert.start();
					ManufacturingEquivalentPartBO mepBo = new ManufacturingEquivalentPartBO();
					String strName =(String)resultMaps.get(DomainConstants.SELECT_NAME);
					String strPolicy =(String)resultMaps.get(DomainConstants.SELECT_POLICY);
					if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
						MapList mpPackagingCert =mepBo.getPackagingCertificationsList(context,objId,strName,strType,strPolicy);
						mpPackCert =mepBo.getCertificationDetails(context,mpPackagingCert,(String)resultMaps.get(DomainConstants.SELECT_NAME),doSEP,sType);
					}
					swPkgCert.stop();
					LOGGER.info("SEP PACKAGING CERTIFICATIONS ELAPSED TIME : "+swPkgCert.getTime());
				}
				//SPEC: <09.06.2022>: Guna Added for Req 33476 and 41754 22x Release  -- END
			}
			
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.REACH, mpReachResult);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			hmAttrib.put(ConstantsUtil.ENTERPRISEPARTS, mpEnterpriseParts);
			hmAttrib.put(ConstantsUtil.EQUIVALENTMEP, mpEquivalentMep);
			// Added by Jwala for the req 4945 - START
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				hmAttrib.put(ConstantsUtil.CERTIFICATION, mpCertification);
			}
			// Added by Jwala for the req 4945 - END
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- START
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			//Modified by Ketan for Req no 2332 -- START
			if(showMaterialAndComp) {
				if(!isRM) {
					hmAttrib.put(ConstantsUtil.MATERIALCOMPOSITION, mpMaterialComposition);
				}
				else if(isRM && !bSupplierView) {
					hmAttrib.put(ConstantsUtil.MATERIALCOMPOSITION, mpMaterialComposition);
				}
				//Added by Ketan for Req. no. 6045 -- START
				else if(isRM && bSupplierView) {
					String stType = validator.isNotNullOrEmpty((String)mpMaterialComposition.get(ConstantsUtil.TYPE))?(String)mpMaterialComposition.get(ConstantsUtil.TYPE) : ConstantsUtil.EMPTY_STRING;
					if(stType.contains(ConstantsUtilIRM.EXTERNAL_MATERIAL)) {
						hmAttrib.put(ConstantsUtil.MATERIALCOMPOSITION, mpMaterialComposition);
					}
				}
				//Added by Ketan for Req. no. 6045 -- END
			}
			//Modified by Ketan for Req no 2332 -- END
			//SPEC: <22.04.2022>: Guna Modified for Req 33476 22x Release  -- START
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//SPEC: <22.04.2022>: Guna Modified for Req 33476 22x Release  -- END	
			if(!bSupplierView)
			{
				
				hmAttrib.put(ConstantsUtil.FILES, mpFiles);
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- START
				hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- END
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- START
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- END
			
			if(showSubstanceAndMaterial)
			hmAttrib.put(ConstantsUtil.SUBSTANCESMATERIALS, mpMaterialResult);
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				hmAttrib.put(ConstantsUtilIRM.PACKAGINGCERTIFICATIONS, mpPackCert);
			}
			sp.stop();
			pool.checkIn(context);
			LOGGER.info("SEP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "SEP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));

		} catch (IOException e) {
			LOGGER.error("Exception in getSEPdata: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		} catch (MatrixException e) {
			LOGGER.error("Exception in getSEPdata: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}
		//LOGGER.info("SEP RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		context.close();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		return hmAttrib;
		
	}
	
	public static void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
}
