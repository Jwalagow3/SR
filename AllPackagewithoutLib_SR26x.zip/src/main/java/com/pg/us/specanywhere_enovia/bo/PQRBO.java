package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.FileUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import ch.qos.logback.classic.pattern.Util;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;
import com.matrixone.apps.domain.DomainRelationship;
public class PQRBO {
	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(PQRBO.class);
	static StringValidatorUtil validator = new StringValidatorUtil();
	static BusObjectAttribUtil util = new BusObjectAttribUtil();

	public PQRBO() {
		// empty constructor
	}
	
	
	/**
	 * Method Name 			: formatDataforPCP
	 * Method Description 	:
	 * @param slData
	 * @param sData
	 */
	public void formatDataforPCP(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_COMMA);
	}

	/**
	 * Method Name 			: formatDataforPCP
	 * Method Description 	:
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
	
	/**
	 * Method Name 			: formatDataforPCP
	 * Method Description 	:
	 * @param slData
	 * @param sData
	 */
	public void formatDataforStringList(StringBuilder slData, StringList sData) {
		int i=0;
		while(i<sData.size()-1) {
			slData.append(sData.get(i));
			slData.append(ConstantsUtil.SYMBL_PIPE);
			i++;
		}
		slData.append(sData.get(i));
	}
	
	
	/**
	 * Method Name 			: getPqrBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getPqrBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getPqrDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getPqrDO(Context context, String oId) throws Exception {
		try {
			DomainObject doObj = new DomainObject(oId);
			if (doObj.exists(context))
				return doObj;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize domainobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getPQRSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getPQRSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info
		busSelect.addAll(getCommonDataBusSelectable(context));
		
		//SPEC: Release SR18x.6.0 - Defect#41377 Added  by gaikwad.tg on Date 23 Mar 2021 -- START
		busSelect.add(ConstantsUtilIRM.STR_SELECT_MANU_EQU_PARTS);
		//SPEC: Release SR18x.6.0 - Added for Defect# 41946  by gaikwad.tg on Date 30 March 2021 -- START
		busSelect.add(ConstantsUtilIRM.STR_SELECT_SUPP_EQU_PARTS);
		busSelect.add(ConstantsUtilIRM.STR_SELECT_ENTERPRISE_PARTS_KEY);
		//Added By Jwala for the defect - 46784 6.0.3 -- START
		busSelect.add(ConstantsUtil.STR_SELECT_ENTERPRISE_PARTS);
		//Added By Jwala for the defect - 46784 6.0.3 -- END
		//SPEC: Release SR18x.6.0 - Added for Defect# 41946  by gaikwad.tg on Date 30 March 2021 -- END
		//SPEC: Release SR18x.6.0 - Defect#41377 Added  by gaikwad.tg on Date 23 Mar 2021 -- END
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getCommonDataBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getCommonDataBusSelectable(Context context) {
		StringList busSelect = new StringList();
		
		
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PREFERENCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PREFERENCESCORE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCATIONSTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRMANUFACTURER);
		busSelect.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		busSelect.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFIEDEQUIVALENTSNAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURERLINES);
		
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_SAP_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);	
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION);
		
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.APPROVER_FULLNAME);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		
		busSelect.add(ConstantsUtil.ATL_IPCLASSIFICATION);
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_ID);
		busSelect.add(ConstantsUtil.ATL_REVISION);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);

		busSelect.add(ConstantsUtil.SELECT_SAP_ID);
		busSelect.add(ConstantsUtil.SELECT_SAP_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SAP_PHASE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TITLE);
		busSelect.add(ConstantsUtil.SELECT_SAP_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);
		
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_ID);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_PHASE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_TITLE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_EXPIRATION_DATE);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYOFPRODUCTIS);
		
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 22, 2021 -- START
		busSelect.add(ConstantsUtilIRM.CONNECTED_TYPE_TO_PQR);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 22, 2021 -- END
		
		return busSelect;
	}
	
	/**
	 * Method Name 			: getMpsRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getPqrRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getCommonDataBusSelectable(context));
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);

		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_CONNECTION_ID);
		busSelect.add(ConstantsUtil.SELECT_PARENT);
		busSelect.add(ConstantsUtil.SELECT_LEVEL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGLEVEL);

		return busSelect;
	}
	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
	
		relSelect.add("to."+ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET); 			
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM);				
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR);	
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION); 	
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT); 			
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMBINATION_NUMBER);
		
		return relSelect;
	}
	
	
	
	/**
	 * Method Name 			: updateRefDocs
	 * Method Description 	: Getting the Reference Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map updateRefDocs(Context context, Map resultMaps) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();
		CommonDocBO commonDoc = new CommonDocBO();
		FileUtil fileUtil = new FileUtil();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);

		boolean bHasOwnerShip = false;

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();

		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}
		
		String sObjectId = validator.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ID))
				? (String) resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

		Map<String, String> mpRefDoc = new HashMap();

		String objectWhere = "((name ~~RF_* || name ~~DF_* || name ~~QEC_* || name ~~LR_* || name ~~IMG_*) && (revision != Rendition))";

		if (util.isModificatinRequired()) {
			objectWhere = "((name ~~LR_*) && (revision != Rendition))";
		}

		try {
			DomainObject dobCdoc = new DomainObject(sObjectId);
			
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			dobCdoc.close(context);
			//END :: gaikwad.tg
			if (util.isModificatinRequired()) {
				mlRelatedSpecs = util.filterPhase(mlRelatedSpecs);
			}
			
			Iterator objectListItr = mlRelatedSpecs.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbDispType = new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbDescription = new StringBuilder();
			StringBuilder sbTitle = new StringBuilder();
			StringBuilder sbLangBuffer = new StringBuilder();
			StringBuilder sbSource = new StringBuilder();
			StringBuilder sbGendocName = new StringBuilder();
			StringBuilder sbGendocPath = new StringBuilder();
			// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
						// : 02-08-2021 -- START
						StringBuilder sbIsIRM = new StringBuilder();
						StringBuilder sbGendocFormat = new StringBuilder();
						// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
						// : 02-08-2021 -- END
			while (objectListItr.hasNext()) {
				
				Map objectMap = (Map) objectListItr.next();
				String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				//Guna Modified  for 38122 defect 18x.5.2 Release -- START
				String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				//Guna Modified  for 38122 defect 18x.5.2 Release -- END
				String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRev = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				
				String sCSSType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
				String Display_Type = "";

				String strClassFied = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				StringList eachOwnership = validator
						.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				
				// SPEC: Added for 18x.5.2 DEV --Shashank -- START
				Map mpFiles = new HashMap();
				DomainObject doRefDoc = new DomainObject(sId);
				boolean bisIRMDoc = commonDoc.isIRMDoc(sType);
				String sGendocName="";
				String sGendocPath="";
				// On : 02-08-2021 -- START
				String sGendocPathFormat = "";
				// On : 02-08-2021 -- END
				if(bisIRMDoc) {
					mpFiles=fileUtil.getGendocForIRM(context, doRefDoc);
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
				}else {
					mpFiles = fileUtil.getFilesForIPM(context, doRefDoc);
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
					sGendocPathFormat = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FORMAT_FILE));
					// SPEC: Modified for 18x.5.2 DEV -- Guna For ReferenceDocuments
					// On : 02-08-2021 -- END
				}
				// SPEC: Added for 18x.5.2 DEV --Shashank -- END
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doRefDoc.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE)) {
					continue;
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- START
				if(!bisIRMDoc){
					sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_NAME));
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- END
				if (!sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR)) {
					String sLangBuffer = ConstantsUtil.EMPTY_STRING;
					//Guna modified  for 38122 defect 18x.5.2 Release -- START
					if (sPLangBuffer.contains("LR_*"))
						sLangBuffer = sPGLangBuffer;
					else
						sLangBuffer = sPLangBuffer;
					//Guna modified  for 38122 defect 18x.5.2 Release -- END
					//SPEC: <22.03.2021>: Guna Modified for Req 38530 Dev 18x.6   -- START
					if ("Reference File".equalsIgnoreCase(sCSSType) || "Reference_File".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Reference File";
					} else if ("QEC_File".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Quality Evolution Chart File";

					} else if ("Design_File".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Design File";

					} else if ("Language_Rendition".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Language Rendition";

					}
					
					if(UIUtil.isNotNullAndNotEmpty(Display_Type)){
					sType =Display_Type;
					}
					boolean showData = util.checkHasAccess(context, null, sId);
					if (showData) {
						// START :: gaikwad.tg
						if(UIUtil.isNotNullAndNotEmpty(sCurrent) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE))
						sId = ConstantsUtil.NO_ACCESS;
						// END :: gaikwad.tg
						util.formatData(sbType, util.mapType(sType));
						util.formatData(sbDispType, Display_Type);
						//START :: gaikwad.tg :: Defect#38123
						//util.formatData(sbName, sName);
						util.formatData(sbName, sName);
						//END :: gaikwad.tg :: Defect#38123
						util.formatData(sbDescription, sDesc);
						util.formatData(sbCurrent, sCurrent);
						util.formatData(sbId, sId);
						util.formatData(sbRev, sRev);
						util.formatData(sbTitle, sTitle);
						util.formatData(sbSource, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbLangBuffer, sLangBuffer);
						util.formatData(sbGendocName, sGendocName);
						util.formatData(sbGendocPath, sGendocPath);
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- START
						util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, sGendocPathFormat);
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- END
					}
					//START :: gaikwad.tg :: Defect#38116
					else
					{
						util.formatData(sbType, util.mapType(sType));
						util.formatData(sbDispType, Display_Type);
						util.formatData(sbName, sName);
						util.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
						util.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
						util.formatData(sbId, ConstantsUtil.NO_ACCESS);
						util.formatData(sbRev, sRev);
						util.formatData(sbTitle, ConstantsUtil.NO_ACCESS);
						util.formatData(sbSource, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbLangBuffer, ConstantsUtil.NO_ACCESS);
						util.formatData(sbGendocName, ConstantsUtil.NO_ACCESS);
						util.formatData(sbGendocPath, ConstantsUtil.NO_ACCESS);
						sGendocPathFormat=ConstantsUtil.NO_ACCESS;
					}
				
				}//perform char
			}
			mpRefDoc.put(ConstantsUtil.NAME, sbName.toString());
			mpRefDoc.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpRefDoc.put(ConstantsUtil.TYPE, sbType.toString());
			mpRefDoc.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.REVISION, sbRev.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCNAME, sbGendocName.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCPATH, sbGendocPath.toString());
			mpRefDoc.put(ConstantsUtil.ISIRM, sbIsIRM.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCFORMAT, sbGendocFormat.toString());
		} catch (Exception e) {

			LOGGER.error("Exception in Program : PQRBO Method :updateRefDocs " + e);
			return new HashMap();
		}

		return mpRefDoc;
	}
	
	
	/**
	 * Method Name 			: getQualifiedEquivalent
	 * Method Description 	: Getting the Qualified Equivalents
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getQualifiedEquivalent(Context context, Map resultMaps) {
		
		boolean bHasOwnerShip = false;
		//SPEC: <08-23-2021>: Sanjeeva Commented for Defect 41962  -- START 
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();

		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}
		
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		StringList slRelSelects = new StringList();
		slRelSelects.add(DomainRelationship.SELECT_FROM_ID);
		slRelSelects.add(DomainRelationship.SELECT_FROM_NAME);
		slRelSelects.add(DomainRelationship.SELECT_FROM_TYPE);
		//SPEC: Sanjeeva Commented for Defect 41964  -- START 
		slRelSelects.add(DomainRelationship.SELECT_FROM_REVISION);
		//SPEC: Sanjeeva Commented for Defect 41964  -- END
		slRelSelects.add(ConstantsUtil.CURRENT_FROMRELID);
		slRelSelects.add(ConstantsUtil.DESC_FROMRELID);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATIONFROMRELID);
		slRelSelects.add(ConstantsUtil.STR_IPCLASSFROMRELID);
		slRelSelects.add(ConstantsUtil.OWNERSHIPFROMRELID);
		slRelSelects.add(ConstantsUtil.TITLE_FROMRELID);
		slRelSelects.add("from.previous.id");
		slRelSelects.add("from.previous.current");
		slRelSelects.add("from.previous.revision");
		slRelSelects.add(ConstantsUtilIRM.SELECT_FROM_POLICY);
		//END :: gaikwad.tg
		
		Map<String, String> mpQuaEqu = new HashMap();
		
		String sID = validator.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ID))
				? (String) resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;	
				
		try {
			StringBuilder sbQEName = new StringBuilder();
			StringBuilder sbQEID = new StringBuilder();
			StringBuilder sbQEType = new StringBuilder();
			StringBuilder sbQERevision = new StringBuilder();
			StringBuilder sbQEState = new StringBuilder();
			StringBuilder sbQEDescription = new StringBuilder();
			StringBuilder sbQETitle = new StringBuilder();
			DomainObject doObjPQR = DomainObject.newInstance(context, sID);
			StringList slEnterprisePartObjIds = doObjPQR.getInfoList(context,ConstantsUtil.STR_SELECT_ENTERPRISE_PARTS );	
			slEnterprisePartObjIds = util.removeDuplicateSlType(slEnterprisePartObjIds);
			String[] saRelIds = (String[])slEnterprisePartObjIds.toArray(new String []{});
			MapList mlQE = DomainRelationship.getInfo(context, saRelIds , slRelSelects);
			HashMap tempMap = new HashMap<>();
			mlQE.sort(ConstantsUtil.CURRENT_FROMRELID, "descending", "string");
			//SPEC: Release SR18x.6.0 - Added for Defect# 41280  by gaikwad.tg on Date 19 April 2021 -- END
			Iterator objectListItr = mlQE.iterator();
			
			while(objectListItr.hasNext())
			{
				Map mpTemp = (Map) objectListItr.next();
				//START :: gaikwad.tg
				//SPEC: 09-05-2022: Pooja added for Defect 50517 -- START
				String strPolicy = (String)mpTemp.get(ConstantsUtilIRM.SELECT_FROM_POLICY);
				//SPEC: 09-05-2022: Pooja added for Defect 50517 -- END
				String slQEState = (String)mpTemp.get(ConstantsUtil.CURRENT_FROMRELID);
				String slQEID = DomainConstants.EMPTY_STRING;
				String slQERevision = DomainConstants.EMPTY_STRING;
					slQEID = (slQEState.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) ? (String)mpTemp.get(DomainRelationship.SELECT_FROM_ID) : ConstantsUtil.NO_ACCESS);
					slQERevision = (String)mpTemp.get(DomainRelationship.SELECT_FROM_REVISION);
				
				String slQEName = (String)mpTemp.get(DomainRelationship.SELECT_FROM_NAME);
				if(tempMap != null && !tempMap.isEmpty() && tempMap.containsKey(slQEName) && !slQEState.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
				continue;
				}
				//SPEC: 12-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 49989-- START
				//SPEC: 25-08-2022: Guna Modified for SR22x.0_NovemberCW Defect 49989-- START
				if(!tempMap.containsKey(slQEName) || !tempMap.containsValue(slQERevision)) {
				//SPEC: 12-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 49989-- END
					tempMap.put(slQEName, slQERevision);
					//SPEC: 25-08-2022: Guna Modified for SR22x.0_NovemberCW Defect 49989-- END
					//SPEC: 09-05-2022: Pooja added for Defect 50517 -- START
					if(strPolicy != null && !strPolicy.isEmpty() && strPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_PGPARALLELCLONEPRODUCTDATAPART)) {
						continue;
					}
					//SPEC: 09-05-2022: Pooja added for Defect 50517 -- END
					String slQEType =util.mapType((String)mpTemp.get(DomainRelationship.SELECT_FROM_TYPE));
					//END:: gaikwad.tg
					String slQEDescription = (String)mpTemp.get(ConstantsUtil.DESC_FROMRELID);
					String slQETitle = (String)mpTemp.get(ConstantsUtil.TITLE_FROMRELID);
					
					String strClassFied = validator
							.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.STR_IPCLASSFROMRELID));
					String sIPClassfication = validator.getStringEquivalentForStringList(
							mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATIONFROMRELID));
					StringList eachOwnership = validator
							.getStringListEquivalentForString(mpTemp.get(ConstantsUtil.OWNERSHIPFROMRELID));
					StringList slEachOwnership = util.filterOwnerShip(eachOwnership);
					//END :: gaikwad.tg
					//Guna Modified  for 38096 defect 18x.5.2 Release -- START
					boolean showData = util.checkHasAccess(context, null, slQEID);
					//Guna Modified  for 38096 defect 18x.5.2 Release -- END
					if (showData) {
						formatData(sbQEName,slQEName);
						formatData(sbQEID,slQEID);
						formatData(sbQEType,slQEType);
						formatData(sbQERevision,slQERevision);
						formatData(sbQEState,slQEState);
						formatData(sbQEDescription,slQEDescription);
						formatData(sbQETitle,slQETitle);
					}
					
					//SPEC: Release SR18x.5.2 - Added for Defect# 39313  by Amman on Feb 11, 2021 -- START
					else {
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- START
						if(util.isModificatinRequired())
							continue;
						else
						{
							formatData(sbQEName,slQEName);
							formatData(sbQEID,ConstantsUtil.NO_ACCESS);
							formatData(sbQEType,slQEType);
							formatData(sbQERevision,slQERevision);
							formatData(sbQEState,slQEState);
							formatData(sbQEDescription,slQEDescription);
							formatData(sbQETitle,slQETitle);
						}
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- END
					}
					//SPEC: Release SR18x.5.2 - Added for Defect# 39313  by Amman on Feb 11, 2021 -- END
					//SPEC: <08-23-2021>: Sanjeeva Commented for Defect 41962  -- END 
				//SPEC: 12-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49989-- START
				}
				//SPEC: 12-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49989-- END
			}
			
			mpQuaEqu.put(ConstantsUtil.NAME, sbQEName.toString());
			mpQuaEqu.put(ConstantsUtil.DESCRIPTION, sbQEDescription.toString());
			mpQuaEqu.put(ConstantsUtil.TYPE, sbQEType.toString());
			mpQuaEqu.put(ConstantsUtil.STATE, sbQEState.toString());
			mpQuaEqu.put(ConstantsUtil.ID, sbQEID.toString());
			mpQuaEqu.put(ConstantsUtil.REVISION, sbQERevision.toString());
			mpQuaEqu.put(ConstantsUtil.TITLE, sbQETitle.toString());

		}catch(Exception e) {
			LOGGER.error("Exception in Program : PQRBO Method :getQualifiedEquivalent " + e);
			e.printStackTrace();
			return new HashMap();
		}
		
		return mpQuaEqu;
	}
	

	//START :: gaikwad.tg
	/**
	 * Method Name 			: addMultiValueList
	 * Method Description 	: 
	 */
	public StringList addMultiList(){
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRMANUFACTURER);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_ENTERPRISE_PARTS);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_ENTERPRISE_PARTS);
		
		return slMultiSelects;

	}
	
	/**
	 * Method Name 			: removeMultiValueList
	 * Method Description 	: 
	 */
	public void removeMultiValueList() 
	{
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
		// Guna Added for Defect 38531  18x.5.2 Release -- START
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
				// Guna Added for Defect 38531  18x.5.2 Release -- END
				//SPEC: Release SR18x.6.0 - Added for Defect# 41946  by gaikwad.tg on Date 30 March 2021 -- START
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PQRMANUFACTURER);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_ENTERPRISE_PARTS);
				//SPEC: Release SR18x.6.0 - Added for Defect# 41946  by gaikwad.tg on Date 30 March 2021 -- END
				
	}
	/**
	 * Method Name 			: getOriginatorName
	 * Method Description 	: 
	 * @param context
	 * @param args
	 * @return
	 */
	public String getOriginatorName(Context context, Map resultMap,String ldapuser,String ldappwd) 
	{	
		String strOriginatorName = ConstantsUtil.EMPTY_STRING;
		
		try {
			String objectId = (String)resultMap.get(ConstantsUtil.ID);
			DomainObject doj = DomainObject.newInstance(context, objectId);
			String strAttributeValue = (String)doj.getInfo(context,DomainConstants.SELECT_OWNER);
			//SPEC: <07.04.2022>: Guna Modified for Req 42769 22x Release  -- START
			strOriginatorName =util.getUserName(context,strAttributeValue,ldapuser,ldappwd);
			//SPEC: <07.04.2022>: Guna Modified for Req 42769 22x Release  -- START
			
		} catch (Exception ex) {
			LOGGER.error("Error from PQRBO: getOriginatorName" + ex);
			strOriginatorName = ConstantsUtil.EMPTY_STRING;
		}
		return strOriginatorName;
	}
	
	
	/**
	 * Method Name 			: getUserName
	 * Method Description 	: 
	 * @param context
	 * @param strOriginator
	 * @return
	 * @throws Exception
	 */
	public String getUserName(Context context, String strOriginator,String ldapuser,String ldappwd) 
	{	
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		String strUserName=ConstantsUtil.EMPTY_STRING;

		try{
			StringList slObjSelects = new StringList(5);
			slObjSelects.addElement(DomainConstants.SELECT_ID);
			slObjSelects.addElement(DomainConstants.SELECT_NAME);
			slObjSelects.addElement("attribute[First Name]");
			slObjSelects.addElement("attribute[Last Name]");
			slObjSelects.addElement("attribute[pgTNumber]");
			String strNamePattern="*";
			String strRevisionPattern="*";
			String strWhere="name==\""+strOriginator+"\" && revision==last";

			MapList mlDataList =  DomainObject.findObjects(context,"Person",strNamePattern,strRevisionPattern,"*","eService Production", strWhere, false, slObjSelects);
			if(mlDataList.size()>0){
				Map dataMap= (Map)mlDataList.get(0);
				strUserName=(String)dataMap.get("attribute[First Name]")+" "+(String)dataMap.get("attribute[Last Name]");
			}else{
				strUserName = util.getLDAPInfo(strOriginator, true,ldapuser,ldappwd);
			}
		}catch (Exception ex) {
			LOGGER.error("Error from PQRBO: getUserName " + ex);
			strUserName=ConstantsUtil.EMPTY_STRING;
		} 
		return strUserName;
	}
	public String replaceSpecialSymbolsForFileName(String sData) {
		if (!UIUtil.isNotNullAndNotEmpty(sData)) {
			return ConstantsUtil.EMPTY_STRING;
		}
		sData = sData.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
				.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING);
		return sData;
	}
	//END :: gaikwad.tg	

	//SPEC: <20.12.2021>: Guna Added for 35581 Req  Dev 18x.6.0.3 Release --- START
	public StringBuilder getManufacturerPlants(StringList plantList, StringList slUserOwnership) {
		StringBuilder rtnBuilder =new StringBuilder();
		try {
			   for(int j=0;j<slUserOwnership.size();j++){
				   String strOwnership =((String)slUserOwnership.get(j)).trim();
				   if(plantList.contains(strOwnership)){
					   util.formatData(rtnBuilder, strOwnership);
				   }
			   }
		} catch (Exception e) {
			LOGGER.error("Error from PQRBO: getManufacturerPlants " + e);
		}
		 
		return rtnBuilder;
	}
	//SPEC: <20.12.2021>: Guna Added for 35581 Req  Dev 18x.6.0.3 Release --- END
}
