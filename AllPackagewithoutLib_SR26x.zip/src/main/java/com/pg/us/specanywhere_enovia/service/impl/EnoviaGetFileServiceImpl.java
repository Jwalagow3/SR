/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaGetFileServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.core.env.Environment;

import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaGetFileService;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.EncryptCrypto;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaGetFileServiceImpl implements EnoviaGetFileService {


	private static String USER;
	private static String PASS;
	private static String VAULT;
	private static Logger LOGGER = Logger.getLogger(EnoviaGetFileServiceImpl.class);
	Map<String, List> hmAttrib = new HashMap<String, List>();
	public  Map<String, List> getFilePath(String sObjId, Environment env) throws Exception {
		
		StopWatch sp = new StopWatch();
		sp.start();
		EncryptCrypto encrpto = new EncryptCrypto();
		USER = env.getProperty(ConstantsUtil.USER_ENOVIA_ID);
		PASS = env.getProperty(ConstantsUtil.USER_ENOVIA_PASS);
		VAULT= env.getProperty(ConstantsUtil.USER_ENOVIA_VAULT);
		PASS = encrpto.decryptString(PASS);
		EnoviaConnectionPool pool = new EnoviaConnectionPool(USER, PASS, VAULT);
		Context context = pool.checkOut();

		//sObjId = "20336.41905.8319.30910";
		String sDestinationPath=ConstantsUtil.EMPTY_STRING;

		Map<String,String> mpFileObject = new HashMap();
		try 
		{
			String strWorkSpace = context.createWorkspace();
			File fWorkspace = new File(strWorkSpace + File.separator + System.currentTimeMillis());
			fWorkspace.mkdirs();

			//Temprary code until FCS ready  --  Starts
			
			StringList slFilePaths = new StringList();
			StringList slFileNames = new StringList();
			
			StringBuffer sbReturn = new StringBuffer();
			String path ="3c/46/3c46uxaiuxf0q_mkwwwyxe9yvfb_w0jbifxymcb6htv.jbi";
			String path1 ="99/a6/99a6agerzla8-aeyh9pw2580dra1121wch9tueerq7x.wq9";
			
			slFilePaths.add(path);
			slFilePaths.add(path1);
			
			slFileNames.add("80252387-Rev003.pdf");
			slFileNames.add("82252952-Rev003.pdf");
			
			hmAttrib.put("path", slFilePaths);
			hmAttrib.put("Name", slFileNames);
			//Temprary code until FCS ready  --  Ends
			
		} catch (Exception e) {
			LOGGER.error("Exception from EnoviaGetFileServiceImpl getFilePath: "+e);
			new HashMap();
		}finally {
			pool.checkIn(context);
		}
		sp.stop();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		context.close();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		return hmAttrib;
	}

	
	
}
	
