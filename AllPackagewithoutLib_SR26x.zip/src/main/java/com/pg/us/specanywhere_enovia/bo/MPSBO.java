package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.FileUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class MPSBO {
	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(FinishedProductPartBO.class);
	static StringValidatorUtil validator = new StringValidatorUtil();
	static BusObjectAttribUtil util = new BusObjectAttribUtil();

	public MPSBO() {
		// empty constructor
	}
	
	
	/**
	 * Method Name 			: formatData
	 * Method Description 	:
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
	
	
	/**
	 * Method Name 			: getMpsBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getMpsBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getMpsDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getMpsDO(Context context, String oId) throws Exception {
		try {
			DomainObject doObj = new DomainObject(oId);
			if (doObj.exists(context))
				return doObj;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize domainobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getMPSSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getMPSSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info
		busSelect.addAll(getCommonDataBusSelectable(context));
		busSelect.addAll(getTransportCharSelectables());
		busSelect.addAll(getPackagingCharBusSelectables());
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getCommonDataBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getCommonDataBusSelectable(Context context) {
		StringList busSelect = new StringList();
		
		
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_SAP_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);	
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION);
		
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.APPROVER_FULLNAME);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		
		busSelect.add(ConstantsUtil.ATL_IPCLASSIFICATION);
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_ID);
		busSelect.add(ConstantsUtil.ATL_REVISION);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);

		busSelect.add(ConstantsUtil.SELECT_SAP_ID);
		busSelect.add(ConstantsUtil.SELECT_SAP_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SAP_PHASE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TITLE);
		busSelect.add(ConstantsUtil.SELECT_SAP_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);
		
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_ID);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_PHASE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_TITLE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_EXPIRATION_DATE);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYOFPRODUCTIS);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		// SPEC: Added for 18x.5.2 DEV --Guna -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS);
		// SPEC: Added for 18x.5.2 DEV --Guna -- END
		// SPEC: Added for 18x.5.2 Defect #39077 --Bala -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		// SPEC: Added for 18x.5.2 Defect #39077 --Bala -- END
		
		//SPEC: Release SR18x.5.2 - Added for Defect# 39088  by Amman on Feb 12, 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39088  by Amman on Feb 12, 2021 -- END
		
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 18, 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_SUPERSEDESONDATE);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 18, 2021 -- END
		
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList() {
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.ATL_NAME);
		slMultiSelects.add(ConstantsUtil.ATL_TITLE);
		slMultiSelects.add(ConstantsUtil.ATL_ID);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		slMultiSelects.add(ConstantsUtil.ATL_REVISION);
		slMultiSelects.add(ConstantsUtil.ATL_TYPE);
		slMultiSelects.add(ConstantsUtil.ATL_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.ATL_IPCLASSIFICATION);

		slMultiSelects.add(ConstantsUtil.REL_ATS_NAME);
		slMultiSelects.add(ConstantsUtil.REL_ATS_TITLE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_ID);
		slMultiSelects.add(ConstantsUtil.REL_ATS_STATE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_REV);
		slMultiSelects.add(ConstantsUtil.REL_ATS_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_RELEASE_PHASE);

		slMultiSelects.add(ConstantsUtil.SELECT_SAP_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_CURRENT);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);

		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_EXPIRATION_DATE);

		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_SAP_BOM_FEED);

		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GTIN); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DEPTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_WIDTH); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY);
		slMultiSelects.add(ConstantsUtil.STR_IPCLASS);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID);

		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDAT_STACK_PATTERN_TYPE);
		
		return slMultiSelects;
	}   
	
	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	: Removing multi selects from
	 * 						  DomainConstants after getting the information
	 */
	public  void removeMultiList() {
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_IPCLASSIFICATION);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_REV);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_RELEASE_PHASE);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_EXPIRATION_DATE);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_SAP_BOM_FEED);


		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GTIN); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DEPTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_WIDTH); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);
		// Guna Added for Defect 38365  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID);
		// Guna Added for Defect 38365  18x.5.2 Release -- END

		// Jwala Added for Defect 39716  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDAT_STACK_PATTERN_TYPE);
		// Jwala Added for Defect 39716  18x.5.2 Release -- END
	}
	
	
	/**
	 * Method Name 			: getEDList
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public static String getEDList(Map resultMaps,String ldapuser,String ldappwd) {
		String sAttrVal =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION) : ConstantsUtil.EMPTY_STRING;
		String strAttrValue=ConstantsUtil.EMPTY_STRING;
		String strValue=ConstantsUtil.EMPTY_STRING;
		StringTokenizer newValues=null;
		StringList strList=new StringList();

		if (sAttrVal != null && sAttrVal.trim().length() > 0) {
			newValues=new StringTokenizer(sAttrVal,ConstantsUtil.SYMBL_PIPE);
			while(newValues.hasMoreTokens())
			{
				strAttrValue=newValues.nextToken();
				if(null!=strAttrValue && (!strAttrValue.isEmpty())){
					strAttrValue = util.getLDAPInfo(strAttrValue.trim(), true,ldapuser,ldappwd);
					strList.addElement(strAttrValue);
					strList.sort();
					strValue = FrameworkUtil.join(strList, ConstantsUtil.SYMBL_PIPE);
				}
			}

		}
		return strValue;

	}
	
	
	/**
	 * Method Name 			: updateRefDocs
	 * Method Description 	: Getting the Reference Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map updateRefDocs(Context context, Map resultMaps, boolean readaccess_structured) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();
		CommonDocBO commonDoc = new CommonDocBO();
		FileUtil fileUtil = new FileUtil();
		
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);

		String sTypePattern = ConstantsUtil.EMPTY_STRING;;
		
		if(readaccess_structured){
			sTypePattern=getTypePattern(true);
		}
		else
		{
			sTypePattern=getTypePattern(false);
		}

		boolean bHasOwnerShip = false;

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();

		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}
		String sObjectId = validator.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ID))
				? (String) resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

		Map<String, String> mpRefDoc = new HashMap();

		String objectWhere = "((name ~~RF_* || name ~~DF_* || name ~~QEC_* || name ~~LR_* || name ~~IMG_*) && (revision != Rendition))";

		if (util.isModificatinRequired()) {
			objectWhere = "((name ~~LR_*) && (revision != Rendition))";
		}

		try {
			DomainObject dobCdoc = new DomainObject(sObjectId);
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1, objectWhere,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobCdoc.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			if (util.isModificatinRequired()) {
				mlRelatedSpecs = util.filterPhase(mlRelatedSpecs);
			}
			Iterator objectListItr = mlRelatedSpecs.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbDispType = new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbDescription = new StringBuilder();
			StringBuilder sbTitle = new StringBuilder();
			StringBuilder sbLangBuffer = new StringBuilder();
			StringBuilder sbSource = new StringBuilder();
			StringBuilder sbGendocName = new StringBuilder();
			StringBuilder sbGendocPath = new StringBuilder();
			// SPEC: Added for 18x.5.2 DEV -- Chandra For ReferenceDocuments On
			// : 02-05-2021 -- START
			StringBuilder sbIsIRM = new StringBuilder();
			StringBuilder sbGendocFormat = new StringBuilder();
			// SPEC: Added for 18x.5.2 DEV -- Chandra For ReferenceDocuments On
			// : 02-05-2021 -- END
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sLangName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRev = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);

				String sName = (String) objectMap.get(ConstantsUtil.STR_FILE_NAME);
				String sCSSType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
				String Display_Type = "";

				String strClassFied = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				StringList eachOwnership = validator
						.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				
				// SPEC: Added for 18x.5.2 DEV --Shashank -- START
				Map mpFiles = new HashMap();
				DomainObject doRefDoc = new DomainObject(sId);
				boolean bisIRMDoc = commonDoc.isIRMDoc(sType);
				String sGendocName = "";
				String sGendocPath = "";
				// SPEC: Added for 18x.5.2 DEV -- Chandra For ReferenceDocuments
				// On : 02-05-2021 -- START
				String sGendocPathFormat = "";
				// SPEC: Added for 18x.5.2 DEV -- Chandra For ReferenceDocuments
				// On : 02-05-2021 -- END
				if (bisIRMDoc) {
					mpFiles = fileUtil.getGendocForIRM(context, doRefDoc);
					sGendocName = validator.getStringEquivalentForSubstituteString(
							mpFiles.get(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME));
					sGendocPath = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
				} else {
					// mpFiles=fileUtil.getGendocForReferenceDocuments(context,
					// doRefDoc);
					mpFiles = fileUtil.getFilesForIPM(context, doRefDoc);
					sGendocName = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_NAME));
					sGendocPath = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
					// ReferenceDocuments On : 02-05-2021 -- START
					sGendocPathFormat = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FORMAT_FILE));
					// SPEC: Added for 18x.5.2 DEV -- Chandra For
					// ReferenceDocuments On : 02-05-2021 -- END
				}
				// SPEC: Added for 18x.5.2 DEV --Shashank -- END
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doRefDoc.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				
				if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE)) {
					continue;
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- START
				if(bisIRMDoc){
					sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- END
				if (!sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR)) {
					String sLangBuffer = ConstantsUtil.EMPTY_STRING;
					//SPEC: Release SR18x.5.2 - Modified for Defect# 38359  by Guna on Date 12/02/2021 -- START
					//if (sLangName.contains("LR_*"))
						if (sLangName.contains("LR_"))
						//SPEC: Release SR18x.5.2 - Modified for Defect# 38359  by Guna on Date 12/02/2021 -- END
						sLangBuffer = sRev;
					else
						sLangBuffer = "";

					if ("Reference File".equalsIgnoreCase(sCSSType)) {

						Display_Type = "Reference File";

					} else if ("QEC_File".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Quality Evolution Chart File";

					} else if ("Design_File".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Design File";

					} else if ("Language_Rendition".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Language Rendition";

					}
					//SPEC: Release SR18x.5.2 - Added for Defect# 38359  by Guna on Date 12/02/2021 -- START
					else{
						Display_Type = sCSSType;
					} 
					//SPEC: Release SR18x.5.2 - Added for Defect# 38359  by Guna on Date 12/02/2021 -- END
					
                   //commented by Ganesh start
					/*if (util.isModificatinRequired()) {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) {
							util.formatData(sbType, util.mapType(sType));
							util.formatData(sbDispType, Display_Type);
							util.formatData(sbName, sName);
							util.formatData(sbDescription, sDesc);
							util.formatData(sbCurrent, sCurrent);
							util.formatData(sbId, sId);
							util.formatData(sbRev, sRev);
							util.formatData(sbTitle, sTitle);
							util.formatData(sbSource, ConstantsUtil.EMPTY_STRING);
							util.formatData(sbLangBuffer, sLangBuffer);

						}
					} else {
						boolean showData = true;
						if (sIPClassfication.equalsIgnoreCase(ConstantsUtil.HIGHLY_RESTRICTED)) {
							SecurityService sct = new SecurityService();
							String sUserlicense = sct.getUserLicense();
							if (null != sUserlicense && null != strClassFied && !sUserlicense.contains(strClassFied)) {
								showData = false;
							}
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);

							if (showData) {
								util.formatData(sbType, util.mapType(sType));
								util.formatData(sbDispType, Display_Type);
								util.formatData(sbName, sName);
								util.formatData(sbDescription, sDesc);
								util.formatData(sbCurrent, sCurrent);
								util.formatData(sbId, sId);
								util.formatData(sbRev, sRev);
								util.formatData(sbTitle, sTitle);
								util.formatData(sbSource, ConstantsUtil.EMPTY_STRING);
								util.formatData(sbLangBuffer, sLangBuffer);
							}
						} else {

							util.formatData(sbType, util.mapType(sType));
							util.formatData(sbDispType, Display_Type);
							util.formatData(sbName, sName);
							util.formatData(sbDescription, sDesc);
							util.formatData(sbCurrent, sCurrent);
							util.formatData(sbId, sId);
							util.formatData(sbRev, sRev);
							util.formatData(sbTitle, sTitle);
							util.formatData(sbSource, ConstantsUtil.EMPTY_STRING);
							util.formatData(sbLangBuffer, sLangBuffer);
						}
					}*/
					//Added by Ganesh start
					boolean showData=true;
					showData = util.checkHasAccess(context, null, sId);
					
					//SPEC: Release SR18x.6.0.1 - Modified by Amman on May 11, 2021 for Req #33248 -- START
					if(util.isModificatinRequired()) {
						if(!showData) {
							continue;
						}
						if (!ConstantsUtil.RELEASED.equalsIgnoreCase(sCurrent)
								&& !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sCurrent))) {
							continue;
						}
					}
					//SPEC: Release SR18x.6.0.1 - Modified by Amman on May 11, 2021 for Req #33248 -- END
					
					if (showData) {
						util.formatData(sbType, util.mapType(sType));
						util.formatData(sbDispType, Display_Type);
						util.formatData(sbName, sName);
						util.formatData(sbDescription, sDesc);
						util.formatData(sbCurrent, sCurrent);
						util.formatData(sbId, sId);
						util.formatData(sbRev, sRev);
						util.formatData(sbTitle, sTitle);
						util.formatData(sbSource, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbLangBuffer, sLangBuffer);
						util.formatData(sbGendocName, sGendocName);
						util.formatData(sbGendocPath, sGendocPath);
						// SPEC: Added for 18x.5.2 DEV -- Chandra For
						// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
						util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, sGendocPathFormat);
						// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
					} else {
						util.formatData(sbType, util.mapType(sType));
						util.formatData(sbName, sName);
						util.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
						util.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
						util.formatData(sbId, ConstantsUtil.NO_ACCESS);
						util.formatData(sbRev, ConstantsUtil.NO_ACCESS);
						util.formatData(sbTitle, ConstantsUtil.NO_ACCESS);
						util.formatData(sbSource, ConstantsUtil.NO_ACCESS);
						util.formatData(sbLangBuffer, ConstantsUtil.NO_ACCESS);
						// SPEC: Added for 18x.5.2 DEV --Shashank -- START
						util.formatData(sbGendocName, ConstantsUtil.NO_ACCESS);
						util.formatData(sbGendocPath, ConstantsUtil.NO_ACCESS);
						// SPEC: Added for 18x.5.2 DEV --Shashank -- END

						// SPEC: Added for 18x.5.2 DEV -- Chandra For
						// ReferenceDocuments On : 02-05-2021 -- START
						util.formatData(sbIsIRM, String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, ConstantsUtil.NO_ACCESS);
						// SPEC: Added for 18x.5.2 DEV -- Chandra For
						// ReferenceDocuments On : 02-05-2021 -- END
					}
					//Added by Ganesh stop
				}
			}
			mpRefDoc.put(ConstantsUtil.NAME, sbName.toString());
			//mpRefDoc.put(ConstantsUtil.TITLE, sbTitle.toString());
			//mpRefDoc.put(ConstantsUtil.SOURCE, sbSource.toString());
			//// SPEC: Modified for 18x.5.2 DEV --Guna -- START
			mpRefDoc.put(ConstantsUtil.TYPE, sbDispType.toString());
			// SPEC: Modified for 18x.5.2 DEV --Guna -- END
			//mpRefDoc.put(ConstantsUtil.DISPLAY_TYPE, sbDispType.toString());
			//mpRefDoc.put(ConstantsUtil.STATE, sbCurrent.toString());
			//mpRefDoc.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.LANGUAGE, sbLangBuffer.toString());
			//mpRefDoc.put(ConstantsUtil.REVISION, sbRev.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCNAME, sbGendocName.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCPATH, sbGendocPath.toString());
			// SPEC: Added for 18x.5.2 DEV -- Chandra For ReferenceDocuments On
			// : 02-05-2021 -- START
			mpRefDoc.put(ConstantsUtil.ISIRM, sbIsIRM.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCFORMAT, sbGendocFormat.toString());
			// SPEC: Added for 18x.5.2 DEV -- Chandra For ReferenceDocuments On
			// : 02-05-2021 -- END
		} catch (Exception e) {

			LOGGER.error("Exception in Program : MPSBO Method :updateRefDocs " + e);
			return new HashMap();
		}

		return mpRefDoc;
	}

	
	/**
	 * Method Name 			: getTypePattern
	 * Method Description 	: 
	 * @param readaccess_structured
	 * @return
	 */
	public String getTypePattern (boolean readaccess_structured){
		
		try{
			if(readaccess_structured){
				Pattern sbTypePattern = new matrix.util.Pattern(ConstantsUtil.tILST);
				sbTypePattern.addPattern(ConstantsUtil.tTAMU);
				sbTypePattern.addPattern(ConstantsUtil.tSOP);
				return sbTypePattern.toString();
			}
			else{
				return "";
			}
		}
		catch(Exception e){
			LOGGER.error("Exception :: MPSBO : getTypePattern"+e);
			return ConstantsUtil.QUERY_WILDCARD;
		}
	}
	
	
	/**
	 * Method Name 			: updateNotes
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> updateNotes(Context context, Map objectMap) 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		Map<String,String> mpNotes = new HashMap<String,String>();
		StringBuilder sbNum = new StringBuilder();
		StringBuilder sbDes = new StringBuilder();

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);

		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);

		try
		{

			String sContextObjectId = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_ID))?(String)objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			DomainObject dom = new DomainObject(sContextObjectId);
			MapList mlNotes = dom.getRelatedObjects(context,"Extended Data", ConstantsUtil.QUERY_WILDCARD, busSelect,
					relSelect, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dom.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			Iterator objectListItr = mlNotes.iterator();
			while(objectListItr.hasNext())
			{
				Map mpTemp = (Map) objectListItr.next();
				String strType = (String)mpTemp.get(ConstantsUtil.SELECT_TYPE);
				if (strType.equals(ConstantsUtil.TYPE_NOTES_CHAR))
				{
					String strDes= validator.isNotNullOrEmpty((String)mpTemp.get(ConstantsUtil.SELECT_DESCRIPTION))?(String)mpTemp.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING;
					String strNum = (String)mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
					//SPEC: Release SR18x.5.2 - Modified for Defect 39583 by Sanjeeva ## -- START
					//if(strDes!=ConstantsUtil.EMPTY_STRING) {
						util.formatData(sbDes,strDes);
						util.formatData(sbNum,strNum);
					//}
					//SPEC: Release SR18x.5.2 - Modified for Defect 39583 by Sanjeeva ## -- END
				}
			}
			
			mpNotes.put(ConstantsUtil.NUMBER, sbNum.toString());
			mpNotes.put(ConstantsUtil.DESCRIPTION, sbDes.toString());
			
		} catch(Exception ex){
			LOGGER.error("Unable to updateNotes : Program MPSBO "+ex);
			return new HashMap();
		}
		return mpNotes;

	}
	
	
	/**
	 * Method Name 			: UpdateTransportChar
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map UpdateTransportChar(Context context , Map objectMap){
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String,String> mpTransportUnit = new HashMap<String,String>();
		try 
		{
		
			StringList slPalletType =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE));
			StringList slOutDimDepth =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH));
			StringList slOutDimWidth =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH));
			StringList slOutDimHght=  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT));
			StringList slOutDimUOM=  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM));
			StringList slTUP_VOLUME=  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME));
			StringList slITUP_UOM =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM));

			String sGW_WITH_Pallet =util.getTheValueWithSpecialSymbol(objectMap,ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
			String sGW_WITHout_Pallet =util.getTheValueWithSpecialSymbol(objectMap,ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);

			StringList slGW_UOM =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM));
			StringList slCustomlayerperTup =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER));
			StringList sllayerperTup=  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP));
			StringList slCUPPerTUp =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP));
			StringList slcubeEff =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF));
			StringList slPalletMXhgt =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT));
			StringList slCASMaxHGt =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT));
			StringList slTruckMXHGT =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT));

			StringList slStackPattern =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME));
			StringList slStackPatternType =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDAT_STACK_PATTERN_TYPE));

			StringList slStackPatternId =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID));

			String sPalletType = validator.isNotNullOrEmpty(slPalletType.toString()) ? slPalletType.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimDepth = validator.isNotNullOrEmpty(slOutDimDepth.toString()) ? slOutDimDepth.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimWidth = validator.isNotNullOrEmpty(slOutDimWidth.toString()) ? slOutDimWidth.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimHght = validator.isNotNullOrEmpty(slOutDimHght.toString()) ? slOutDimHght.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimUOM = validator.isNotNullOrEmpty(slOutDimUOM.toString()) ? slOutDimUOM.toString(): ConstantsUtil.EMPTY_STRING;
			String sTUP_VOLUME = validator.isNotNullOrEmpty(slTUP_VOLUME.toString()) ? slTUP_VOLUME.toString(): ConstantsUtil.EMPTY_STRING; 
			String sITUP_UOM = validator.isNotNullOrEmpty(slITUP_UOM.toString()) ? slITUP_UOM.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39659  by Guna on Date 17/02/2021 -- START
			//String sGW_WITH_Pallet = validator.isNotNullOrEmpty(slGW_WITH_Pallet.toString()) ? slGW_WITH_Pallet.toString(): ConstantsUtil.EMPTY_STRING;
			//String sGW_WITHout_Pallet = validator.isNotNullOrEmpty(slGW_WITHout_Pallet.toString()) ? slGW_WITHout_Pallet.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39659  by Guna on Date 17/02/2021 -- END
			
			String sGW_UOM = validator.isNotNullOrEmpty(slGW_UOM.toString()) ? slGW_UOM.toString(): ConstantsUtil.EMPTY_STRING;
			String sCustomlayerperTup = validator.isNotNullOrEmpty(slCustomlayerperTup.toString()) ? slCustomlayerperTup.toString(): ConstantsUtil.EMPTY_STRING;
			String slayerperTup = validator.isNotNullOrEmpty(sllayerperTup.toString()) ? sllayerperTup.toString(): ConstantsUtil.EMPTY_STRING;
			String sCUPPerTUp = validator.isNotNullOrEmpty(slCUPPerTUp.toString()) ? slCUPPerTUp.toString(): ConstantsUtil.EMPTY_STRING;
			String scubeEff = validator.isNotNullOrEmpty(slcubeEff.toString()) ? slcubeEff.toString(): ConstantsUtil.EMPTY_STRING;
			String sPalletMXhgt = validator.isNotNullOrEmpty(slPalletMXhgt.toString()) ? slPalletMXhgt.toString(): ConstantsUtil.EMPTY_STRING;
			String sCASMaxHGt = validator.isNotNullOrEmpty(slCASMaxHGt.toString()) ? slCASMaxHGt.toString(): ConstantsUtil.EMPTY_STRING;
			String sTruckMXHGT = validator.isNotNullOrEmpty(slTruckMXHGT.toString()) ? slTruckMXHGT.toString(): ConstantsUtil.EMPTY_STRING;
			String sStackPattern  = validator.isNotNullOrEmpty(slStackPattern.toString()) ? slStackPattern.toString(): ConstantsUtil.EMPTY_STRING;
			// Guna Added for Defect 38365  18x.5.2 Release -- START
			String sStackPatternId  = validator.isNotNullOrEmpty(slStackPatternId.toString()) ? slStackPatternId.toString(): ConstantsUtil.EMPTY_STRING;
			// Guna Added for Defect 38365  18x.5.2 Release -- END
			// Jwala Modified for Defect 39716  18x.5.2 Release -- START
			String sStackPatternType  = validator.isNotNullOrEmpty(slStackPatternType.toString()) ? slStackPatternType.toString(): ConstantsUtil.EMPTY_STRING;
			// Jwala Modified for Defect 39716  18x.5.2 Release -- END
			sPalletType = util.replaceSpecialSymbols(sPalletType);
			sOutDimDepth = util.replaceSpecialSymbols(sOutDimDepth);
			sOutDimWidth = util.replaceSpecialSymbols(sOutDimWidth);
			sOutDimHght = util.replaceSpecialSymbols(sOutDimHght);
			sOutDimUOM = util.replaceSpecialSymbols(sOutDimUOM);
			sTUP_VOLUME = util.replaceSpecialSymbols(sTUP_VOLUME);
			sITUP_UOM = util.replaceSpecialSymbols(sITUP_UOM);
			// Guna Modified for Defect 38365  18x.5.2 Release -- START
			/*sGW_WITH_Pallet = util.replaceSquareBracketsOnly(sGW_WITH_Pallet);
			sGW_WITHout_Pallet = util.replaceSquareBracketsOnly(sGW_WITHout_Pallet);*/
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39659  by Guna on Date 17/02/2021 -- START
			//sGW_WITH_Pallet = util.replaceSpecialSymbols(sGW_WITH_Pallet);
			//sGW_WITHout_Pallet = util.replaceSpecialSymbols(sGW_WITHout_Pallet);
			// Guna Modified for Defect 38365  18x.5.2 Release -- END
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39659  by Guna on Date 17/02/2021 -- END
			sGW_UOM = util.replaceSpecialSymbols(sGW_UOM);
			sCustomlayerperTup = util.replaceSpecialSymbols(sCustomlayerperTup);
			slayerperTup = util.replaceSpecialSymbols(slayerperTup);
			sCUPPerTUp = util.replaceSpecialSymbols(sCUPPerTUp);
			scubeEff = util.replaceSpecialSymbols(scubeEff);
			sPalletMXhgt = util.replaceSpecialSymbols(sPalletMXhgt);
			sCASMaxHGt = util.replaceSpecialSymbols(sCASMaxHGt);
			sTruckMXHGT = util.replaceSpecialSymbols(sTruckMXHGT);
			sStackPattern = util.replaceSpecialSymbols(sStackPattern);
			// Guna Added for Defect 38365  18x.5.2 Release -- START
			sStackPatternId = util.replaceSpecialSymbols(sStackPatternId);
			// Guna Added for Defect 38365  18x.5.2 Release -- END
			
			// Jwala Modified for Defect 39716  18x.5.2 Release -- START
			sStackPatternType = util.replaceSpecialSymbols(sStackPatternType);
			// Jwala Modified for Defect 39716  18x.5.2 Release -- START
			
			mpTransportUnit.put(ConstantsUtil.PALLETTYPE,sPalletType);
			mpTransportUnit.put(ConstantsUtil.GTIN,DomainConstants.EMPTY_STRING);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERLAYER,sCustomlayerperTup);
			mpTransportUnit.put(ConstantsUtil.DEPTH,sOutDimDepth);
			mpTransportUnit.put(ConstantsUtil.WIDTH,sOutDimWidth);
			mpTransportUnit.put(ConstantsUtil.HEIGHT,sOutDimHght);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFLAYERSPERTRANSPORTUNIT,slayerperTup);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERTRANSPORTUNIT,sCUPPerTUp);
			mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE, sOutDimUOM);
			mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE1, sITUP_UOM);
			mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE2, sGW_UOM);
			mpTransportUnit.put(ConstantsUtil.TUPVOLUME,sTUP_VOLUME);
			mpTransportUnit.put(ConstantsUtil.CUBEEFFICIENCY,scubeEff);
			mpTransportUnit.put(ConstantsUtil.WAREHOUSEPALLETSTACKHEIGHTMAXIMUM,sPalletMXhgt);
			mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHPALLET,sGW_WITH_Pallet);
			mpTransportUnit.put(ConstantsUtil.WAREHOUSECASESTACKHEIGHTMAXIMUM,sCASMaxHGt);
			mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHOUTPALLET,sGW_WITHout_Pallet);
			mpTransportUnit.put(ConstantsUtil.TRUCKPALLETSTACKHEIGHTMAXIMUM,sTruckMXHGT);
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODE,sStackPattern);
			// Guna Added for Defect 38365  18x.5.2 Release -- START
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODEID,sStackPatternId);
			// Guna Added for Defect 38365  18x.5.2 Release -- END
			
			// Jwala Modified for Defect 39716  18x.5.2 Release -- START
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODETYPE,sStackPatternType);
			// Jwala Modified for Defect 39716  18x.5.2 Release -- END

		} catch (Exception e) {
			LOGGER.error("Exception in Program : MPSBO Method :UpdateTransportChar "+e);
			return new HashMap();

		}
		return mpTransportUnit;
	}
	
	
	/**
	 * Method Name 			: getMpsRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getMpsRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getCommonDataBusSelectable(context));
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);

		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_CONNECTION_ID);
		busSelect.add(ConstantsUtil.SELECT_PARENT);
		busSelect.add(ConstantsUtil.SELECT_LEVEL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGLEVEL);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);

		return busSelect;
	}
	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
	
		relSelect.add("to."+ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET); 			
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM);				
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR);	
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION); 	
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT); 			
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMBINATION_NUMBER);
		
		return relSelect;
	}
	
	
	/**
	 * Method Name 			: getPackingUnitWeightsAndDiamensionsData
	 * Method Description 	:
	 * @param context
	 * @param objectId
	 * @return
	 * @throws Exception
	 */
	public MapList getPackingUnitWeightsAndDiamensionsData(Context context, String objectId) throws Exception 

	{

		MapList tempList = new MapList();

		MapList objList = null;
		MapList finalBomList = new MapList();
		String sLevelPrev = "0";

		String sLevelNext = "0";

		
		
		try{

			StringList busSelects = new StringList();
			busSelects.add(ConstantsUtil.SELECT_NAME);
			busSelects.add(ConstantsUtil.SELECT_TYPE);
			busSelects.add(ConstantsUtil.SELECT_ID);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT);
			busSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GTIN);

			StringList relSelects = new StringList();
			relSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);
			busSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GTIN);
			String typePattern =  ConstantsUtil.TYPE_PGCUSTOMERUNITPART+","+ConstantsUtil.TYPE_PGINNERPACKUNITPART+","+ConstantsUtil.TYPE_PGCONSUMERUNITPART;
			String relPattern = DomainConstants.RELATIONSHIP_EBOM;

			DomainObject domObject = DomainObject.newInstance(context, objectId);

			objList = domObject.getRelatedObjects(
					context, 
					relPattern,
					typePattern, 
					busSelects, 
					relSelects, 
					false, 
					true, 
					(short) 0,
					null, 
					null, 
					0);		

			String	strObjectType = null;

			String strLevel = null;

			String strCOPId = null;

			StringList listCOPLevel=new StringList();

			StringList listCOPDetails=new StringList();

			StringList COPIgnoreList=new StringList();

			MapList listFinalCharacteristics = new MapList();

			if(!objList.isEmpty())
			{
				Iterator listCharacteristicsIterator = objList.iterator();

				while (listCharacteristicsIterator.hasNext())

				{
					Map    listCharacteristicsMap = (Map) listCharacteristicsIterator.next();

					strObjectType=(String)listCharacteristicsMap.get(DomainConstants.SELECT_TYPE);
					if(strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNITPART))
					{
						strLevel=(String)listCharacteristicsMap.get(DomainConstants.SELECT_LEVEL);
						strCOPId=(String)listCharacteristicsMap.get(DomainConstants.SELECT_ID);

						listCOPLevel.add(strLevel);
						listCOPDetails.add(strLevel+"-"+strCOPId);

					}
				}

				if(listCOPLevel.isEmpty())
				{
					return objList;
				}
				listCOPLevel.sort();

				String strFirstLevel = (String)listCOPLevel.get(0);

				for(int i=0;i<listCOPDetails.size();i++)

				{

					String strCOPDetails=(String)listCOPDetails.get(i);

					String[] COPDetails = strCOPDetails.split("-");

					if(!strFirstLevel.equals(COPDetails[0]))
					{
						COPIgnoreList.add(COPDetails[1]);
					}

				}

				Iterator listRemoveCharacteristicsIterator = objList.iterator();

				while (listRemoveCharacteristicsIterator.hasNext())

				{

					Map    listRemoveCharacteristicsMap = (Map) listRemoveCharacteristicsIterator.next();

					if(!COPIgnoreList.contains((String)listRemoveCharacteristicsMap.get(DomainConstants.SELECT_ID)))
					{
						listFinalCharacteristics.add(listRemoveCharacteristicsMap);
					}


				}
			}

			if(listFinalCharacteristics.size()>0)
			{
				Iterator objItr=listFinalCharacteristics.iterator();

				while(objItr.hasNext())

				{

					Map objMap = (Map) objItr.next();

					Map objects = new HashMap();

					objects.put(DomainConstants.SELECT_NAME, (String)objMap.get(DomainConstants.SELECT_NAME));
					objects.put("relationship", (String)objMap.get("relationship"));
					objects.put("level", (String)objMap.get("level"));
					objects.put(DomainConstants.SELECT_ID, (String)objMap.get(DomainConstants.SELECT_ID));
					objects.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)objMap.get(DomainConstants.SELECT_RELATIONSHIP_ID));
					objects.put(DomainConstants.SELECT_TYPE, (String)objMap.get(DomainConstants.SELECT_TYPE));
					objects.put(DomainConstants.SELECT_ATTRIBUTE_QUANTITY, (String)objMap.get(DomainConstants.SELECT_ATTRIBUTE_QUANTITY));

					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM));
					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL));
					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE));
					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN));

					finalBomList.add(objects);

				}

			}


		} catch (Exception e) {
			LOGGER.error(" Exception in program MPSBO : getPackingUnitWeightsAndDiamensionsData");
		}


		return finalBomList;


	}
	
	
	/**
	 * Method Name 			: UpdatePackagingChar
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map UpdatePackagingChar(Context context , Map objectMap){
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String,String> mpPackingUnit = new HashMap<String,String>();
		StringList slCop =  new StringList();
		StringList slCup =  new StringList();
		try 
		{

			StringList slCssType =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE));
			StringList slOutDimUOM=  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_UOM));
			StringList slGtin=  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_GTIN));
			StringList slOutDimDepth =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_DEPTH));
			StringList slOutDimWidth =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_WIDTH));
			StringList slOutDimHght=  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT));
			StringList slDIM_UOM =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM));
			StringList slGrossWeight=  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT));
			StringList slGW_UOM =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM));
			StringList slConsumerPerPackUnit =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT));
			StringList slNetweightProd=  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION));
			StringList slNet_UOM =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM));
			StringList slcubeEff =  validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY));

			
			String sCssType = validator.isNotNullOrEmpty(slCssType.toString()) ? slCssType.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimUOM = validator.isNotNullOrEmpty(slOutDimUOM.toString()) ? slOutDimUOM.toString(): ConstantsUtil.EMPTY_STRING;
			String sGtin = validator.isNotNullOrEmpty(slGtin.toString()) ? slGtin.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimDepth = validator.isNotNullOrEmpty(slOutDimDepth.toString()) ? slOutDimDepth.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimWidth = validator.isNotNullOrEmpty(slOutDimWidth.toString()) ? slOutDimWidth.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimHght = validator.isNotNullOrEmpty(slOutDimHght.toString()) ? slOutDimHght.toString(): ConstantsUtil.EMPTY_STRING;
			
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- START
			//String sDIM_UOM = validator.isNotNullOrEmpty(slDIM_UOM.toString()) ? slDIM_UOM.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- END
			String sGrossWeight = validator.isNotNullOrEmpty(slGrossWeight.toString()) ? slGrossWeight.toString(): ConstantsUtil.EMPTY_STRING;
			
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- START
			//String sGW_UOM = validator.isNotNullOrEmpty(slGW_UOM.toString()) ? slGW_UOM.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- END
			
			String sConsumerPerPackUnit = validator.isNotNullOrEmpty(slConsumerPerPackUnit.toString()) ? slConsumerPerPackUnit.toString(): ConstantsUtil.EMPTY_STRING; 
			String sNetweightProd = validator.isNotNullOrEmpty(slNetweightProd.toString()) ? slNetweightProd.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- START
			//String sNetUOm = validator.isNotNullOrEmpty(slNet_UOM.toString()) ? slNet_UOM.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- END
			String scubeEff = validator.isNotNullOrEmpty(slcubeEff.toString()) ? slcubeEff.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.5.2 - Added for Defect# 39308  by Guna on Date 11/02/2021 -- START
			StringBuilder sDIM_UOM =new StringBuilder();
			StringBuilder sGW_UOM =new StringBuilder();
			StringBuilder sNetUOm =new StringBuilder();
			if(slDIM_UOM.size() !=0){
				for(int i=0;i<slDIM_UOM.size();i++){
				util.formatData(sDIM_UOM, (String)slDIM_UOM.get(i));
				util.formatData(sGW_UOM, (String)slGW_UOM.get(i));
				util.formatData(sNetUOm, (String)slNet_UOM.get(i));
				}
			}
			//SPEC: Release SR18x.5.2 - Added for Defect# 39308  by Guna on Date 11/02/2021 -- END
			
			sCssType = util.replaceSpecialSymbols(sCssType);
			sOutDimUOM = util.replaceSpecialSymbols(sOutDimUOM);
			sGtin = util.replaceSpecialSymbols(sGtin);
			sOutDimDepth = util.replaceSpecialSymbols(sOutDimDepth);
			sOutDimWidth = util.replaceSpecialSymbols(sOutDimWidth);
			sOutDimHght = util.replaceSpecialSymbols(sOutDimHght);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- START
			//sDIM_UOM = util.replaceSpecialSymbols(sDIM_UOM);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- END
			sGrossWeight = util.replaceSpecialSymbols(sGrossWeight);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- START
			//sGW_UOM = util.replaceSpecialSymbols(sGW_UOM);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- END
			sConsumerPerPackUnit = util.replaceSpecialSymbols(sConsumerPerPackUnit);
			sNetweightProd = util.replaceSpecialSymbols(sNetweightProd);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- START
			//sNetUOm = util.replaceSpecialSymbols(sNetUOm);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- END
			scubeEff = util.replaceSpecialSymbols(scubeEff);


			mpPackingUnit.put(ConstantsUtil.PACKINGUNITTYPE, sCssType);
			mpPackingUnit.put(ConstantsUtil.AUOM, sOutDimUOM);
			mpPackingUnit.put(ConstantsUtil.DEPTH, sOutDimDepth);
			mpPackingUnit.put(ConstantsUtil.WIDTH, sOutDimWidth);
			mpPackingUnit.put(ConstantsUtil.HEIGHT, sOutDimHght);
			//mpPackingUnit.put(ConstantsUtil.DIMENSIONUNITOFMEASURE, sDIM_UOM);
			mpPackingUnit.put(ConstantsUtil.GROSSWEIGHT, sGrossWeight);
			//mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE, sGW_UOM);
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- START
			//mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE, sDIM_UOM);
			mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE, sDIM_UOM.toString());
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- END
			//mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE1, sNetUOm);
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- START
			//mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE1, sGW_UOM);
			mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE1, sGW_UOM.toString());
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- END
			//mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE2, sGW_UOM);
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- START
			//mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE2, sNetUOm);
			mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE2, sNetUOm.toString());
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- END
			mpPackingUnit.put(ConstantsUtil.NUMBEROFCONSUMERUNITSPERUNIT, sConsumerPerPackUnit);
			mpPackingUnit.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCONSUMERUNIT, sNetweightProd);
			mpPackingUnit.put(ConstantsUtil.CUBEEFFICIENCY, scubeEff);
			mpPackingUnit.put(ConstantsUtil.GTIN,sGtin.toString());

		} catch (Exception e) {
			LOGGER.error("Exception in Program : MPSBO Method :UpdatePackagingChar "+e);
			return new HashMap();

		}
		return mpPackingUnit;
	}
	
    
    /**
	 * Method Name 			: getTransportCharSelectables
	 * Method Description 	:
	 * @return
	 */
	private static StringList getTransportCharSelectables() {
		StringList slBusSelects = new StringList();

		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_SAP_BOM_FEED);
		slBusSelects.add(ConstantsUtil.SELECT_REF_DOC_TONAME);
		// Guna Added for Defect 38365  18x.5.2 Release -- START
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID);
		// Guna Added for Defect 38365  18x.5.2 Release -- END
		// Jwala Added for Defect 39716  18x.5.2 Release -- START
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDAT_STACK_PATTERN_TYPE);
		// Jwala Added for Defect 39716  18x.5.2 Release -- END
		return slBusSelects;

	}
	
	
	/**
	 * Method Name 			: getPackagingCharBusSelectables
	 * Method Description 	:
	 * @return
	 */
	private static StringList getPackagingCharBusSelectables() {
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_UOM); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GTIN); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DEPTH);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_WIDTH); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY);


		return slBusSelects;

	}
	
	
	/**
	 * Method Name : getPhaseBOM Method Description :
	 * 
	 * @param context
	 * @param mlEBOMList
	 * @return
	 */
	public Map<String, String> getPhaseBOM(Context context, MapList mlEBOMList, Map resultMap) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		Map MPFinalEBOMSubStitute = new TreeMap();
		Map mpFinalEBOM = new TreeMap();
		Map mpFinalSubstitute = new TreeMap();
		
		
		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership = util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		StringBuilder sbHeaderOfBOM = new StringBuilder();
		
		int index=0;
		Iterator objectListItr = mlEBOMList.iterator();
		Map<String, String> mpHeaderEBOMResult = new HashMap<String, String>();
		try 
		{
			
			String sHeaderOfBOM  = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYOFPRODUCTIS));
			
			util.formatData(sbHeaderOfBOM, sHeaderOfBOM);
			
			mpHeaderEBOMResult.put(ConstantsUtil.ISQUANTITYFOR, sbHeaderOfBOM.toString());
			
			while (objectListItr.hasNext()) 
			{
				Map<String, String> mpSubstituteResult = new HashMap<String, String>();
				Map<String, String> mpEBOMResult = new HashMap<String, String>();
				
				StringBuilder sbEBOMId = new StringBuilder();
				StringBuilder sbEBOMType = new StringBuilder();
				StringBuilder sbEBOMDisplayType = new StringBuilder();
				StringBuilder sbEBOMName = new StringBuilder();
				StringBuilder sbEBOMChg = new StringBuilder();
				StringBuilder sbEBOMSapDes = new StringBuilder();
				StringBuilder sbEBOMFileDesc = new StringBuilder();
				StringBuilder sbEBOMSpecSubType = new StringBuilder();
				StringBuilder sbEBOMSubStitute = new StringBuilder();
				StringBuilder sbEBOMMin = new StringBuilder();
				StringBuilder sbEBOMTarget = new StringBuilder();
				StringBuilder sbEBOMMax = new StringBuilder();
				StringBuilder sbEBOMUOM = new StringBuilder();
				StringBuilder sbEBOMMaterialFunc = new StringBuilder();
				StringBuilder sbEBOMPosIndicator = new StringBuilder();
				StringBuilder sbEBOMCmt = new StringBuilder();
				StringBuilder sbEBOMBatch = new StringBuilder();
				StringBuilder sbEBOMQuantity = new StringBuilder();
				StringBuilder sbEBOMPackingLevel = new StringBuilder();
				
				
				Map mpPhase = (Map) objectListItr.next();
				String sId = (String) mpPhase.get(ConstantsUtil.SELECT_ID);
				
				MapList mlPhaseEBOMList = new MapList();
				if (UIUtil.isNotNullAndNotEmpty(sId)) 
				{
					DomainObject doMPS = new DomainObject(sId);
					mlPhaseEBOMList = doMPS.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
							ConstantsUtil.QUERY_WILDCARD, getBomBusSelect(context), getBomRelSelect(context), false, true,
							(short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doMPS.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				}

				
				String sType = (String) mpPhase.get(ConstantsUtil.SELECT_TYPE);
				String sName = (String) mpPhase.get(ConstantsUtil.SELECT_NAME);
				String sDesc = (String) mpPhase.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sChg = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
				String sSAPDesc = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sFileDesc = (String) mpPhase.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sDispType="";
				String sSpecSubType = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				String sIsDSO = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				sSpecSubType =getMappedType(sSpecSubType);
				 
				String sSubstitute = validator.getStringEquivalentForStringList(mpPhase.get(ConstantsUtil.SELECT_SUBSTITUTE));
				String sMin = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
				
				String sPackingLevel = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGLEVEL);
				
				//Target Column 
				String sSubTotal = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);
				String sSubTUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
				String sIngrLoss = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
				String sIngrLossUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);
				String sTotal = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
				
				String sFinalTarget ="Subtotal: "+sSubTotal+" "+sSubTUOM+" Ingredient Loss: "+sIngrLoss+" "+sIngrLossUOM+" Total: "+sTotal;
				
				//Child
				String sChildTarget = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
				String sMax = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
				String sUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
				String sMaterialFunc = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
				String sPosIndicator = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
				String sAttrCmt = validator.getStringEquivalentForStringList(mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT));
				String sTotalBatch = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
				String sTBUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
				
				String sFinalBatch  ="Target: "+sTotalBatch+" Range Min: "+sMin +" Range Max  "+sMax+" UOM: "+sTBUOM;
				String strClassFiedParent = validator.getStringEquivalentForStringList(mpPhase.get(ConstantsUtil.STR_IPCLASS));
				
				sMin="";
				sMax="";
				
				
				boolean bHasOwnership = false;
				String sFormulaPropagate = sId;
				//commented by Ganesh start
				
				/*if (util.isModificatinRequired()) 
				{

					// Formulation part does not have ownership on itself, hence
					// expand to get it from the Cosmetic formulation
					if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = util.getFormulaPropagate(context, sId);
					}

					if (!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}
					if (!bHasOwnership) {
						
						sId = ConstantsUtil.NO_ACCESS;
						sType = ConstantsUtil.NO_ACCESS;
						sChg = ConstantsUtil.NO_ACCESS;
						sSAPDesc = ConstantsUtil.NO_ACCESS;
						sFileDesc = ConstantsUtil.NO_ACCESS;
						sSpecSubType = ConstantsUtil.NO_ACCESS;
						sSubstitute = ConstantsUtil.NO_ACCESS;
						sMin = ConstantsUtil.NO_ACCESS;
						sFinalTarget = ConstantsUtil.NO_ACCESS;
						sMax = ConstantsUtil.NO_ACCESS;
						sUOM = ConstantsUtil.NO_ACCESS;
						sMaterialFunc = ConstantsUtil.NO_ACCESS;
						sPosIndicator = ConstantsUtil.NO_ACCESS;
						sAttrCmt = ConstantsUtil.NO_ACCESS;
						sTBUOM = ConstantsUtil.NO_ACCESS;
						sChildTarget = ConstantsUtil.NO_ACCESS;
						sPackingLevel = ConstantsUtil.NO_ACCESS;
						sDispType = ConstantsUtil.NO_ACCESS;
					}
				} else 
				{

					StringList slHIRTypes = new StringList();

					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

					boolean showData = true;
					if (slHIRTypes.contains(sType)) {

						String sFormulaClassif = strClassFiedParent;

						if (!sec.isExternalUser()) {
							if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
							}
							if (null != sUserlicense && null != sFormulaClassif
									&& !sUserlicense.contains(sFormulaClassif)) {
								showData = false;
							}
						}

						if (!showData) {

							sId = ConstantsUtil.NO_ACCESS;
							sType = ConstantsUtil.NO_ACCESS;
							sChg = ConstantsUtil.NO_ACCESS;
							sSAPDesc = ConstantsUtil.NO_ACCESS;
							sFileDesc = ConstantsUtil.NO_ACCESS;
							sSpecSubType = ConstantsUtil.NO_ACCESS;
							sSubstitute = ConstantsUtil.NO_ACCESS;
							sMin = ConstantsUtil.NO_ACCESS;
							sFinalTarget = ConstantsUtil.NO_ACCESS;
							sMax = ConstantsUtil.NO_ACCESS;
							sUOM = ConstantsUtil.NO_ACCESS;
							sMaterialFunc = ConstantsUtil.NO_ACCESS;
							sPosIndicator = ConstantsUtil.NO_ACCESS;
							sAttrCmt = ConstantsUtil.NO_ACCESS;
							sTBUOM = ConstantsUtil.NO_ACCESS;
							sChildTarget = ConstantsUtil.NO_ACCESS;
							sPackingLevel = ConstantsUtil.NO_ACCESS;
							sDispType = ConstantsUtil.NO_ACCESS;
						}

					}
				} commented by Ganesh stop*/
				//Added by Ganesh start
				boolean showData =util.checkHasAccess(context, null, sId);
				if (!showData) {

					sId = ConstantsUtil.NO_ACCESS;
					sType = ConstantsUtil.NO_ACCESS;
					sChg = ConstantsUtil.NO_ACCESS;
					sSAPDesc = ConstantsUtil.NO_ACCESS;
					sFileDesc = ConstantsUtil.NO_ACCESS;
					sSpecSubType = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					sMin = ConstantsUtil.NO_ACCESS;
					sFinalTarget = ConstantsUtil.NO_ACCESS;
					sMax = ConstantsUtil.NO_ACCESS;
					sUOM = ConstantsUtil.NO_ACCESS;
					sMaterialFunc = ConstantsUtil.NO_ACCESS;
					sPosIndicator = ConstantsUtil.NO_ACCESS;
					sAttrCmt = ConstantsUtil.NO_ACCESS;
					sTBUOM = ConstantsUtil.NO_ACCESS;
					sChildTarget = ConstantsUtil.NO_ACCESS;
					sPackingLevel = ConstantsUtil.NO_ACCESS;
					sDispType = ConstantsUtil.NO_ACCESS;
				}
				//Added by Ganesh stop

				
				
				util.formatData(sbEBOMId, sId);
				util.formatData(sbEBOMType, sType);
				util.formatData(sbEBOMDisplayType, sDispType);
				util.formatData(sbEBOMName, sName);
				util.formatData(sbEBOMChg, sChg);
				util.formatData(sbEBOMSapDes, sFileDesc);
				util.formatData(sbEBOMFileDesc, sFileDesc);
				util.formatData(sbEBOMSpecSubType,(sSpecSubType==null)?"":sSpecSubType);
				util.formatData(sbEBOMSubStitute, sSubstitute);
				util.formatData(sbEBOMMin, sMin);
				util.formatData(sbEBOMTarget, sFinalTarget);
				util.formatData(sbEBOMMax, sMax);
				util.formatData(sbEBOMSubStitute, sSubstitute);
				util.formatData(sbEBOMUOM, sUOM);
				util.formatData(sbEBOMMaterialFunc, sMaterialFunc);
				util.formatData(sbEBOMPosIndicator, sPosIndicator);
				util.formatData(sbEBOMCmt,sAttrCmt);
				util.formatData(sbEBOMBatch,sFinalBatch);
				util.formatData(sbEBOMQuantity,sChildTarget);
				util.formatData(sbEBOMPackingLevel,sPackingLevel);
				
				//Vector sl12 =	getSpecificationSubtype(context,mlPhaseEBOMList);
			
				
				Iterator objectPhaseListItr = mlPhaseEBOMList.iterator();
				
				 mpSubstituteResult = getMPSSubstitutes(context,mlPhaseEBOMList,sName,sDesc);
					
				while (objectPhaseListItr.hasNext()) 
				{
					Map objectMap = (Map) objectPhaseListItr.next();
					sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
					if(sType.equals("pgNonGCASPart")) {
						sName = "Non-GCAS";
					}else {
						sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					}
					String sOid = (String) objectMap.get(ConstantsUtil.SELECT_ID);
					sChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
					sSAPDesc = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					sFileDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
					//if(!sType.equals(ConstantsUtil.TYPE_PGPHASE)){
					 sDispType =getMappedType(sType);
					//}
					sSpecSubType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					sIsDSO = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
					sSpecSubType =getMappedType(sSpecSubType);
					sSubstitute = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
					sMin = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
					sChildTarget = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
					sMax = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
					sUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
					sMaterialFunc = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
					sPosIndicator = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
					sAttrCmt = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
					sTBUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
					sPackingLevel = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGLEVEL);
					
					//Target Column 
					
					if(sType.equals(ConstantsUtil.TYPE_PGPHASE)){
					 sSubTotal = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);
					 sSubTUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
					 sIngrLoss = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
					 sIngrLossUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);
					 sTotal = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
					
					 sFinalTarget ="Subtotal: "+sSubTotal+" "+sSubTUOM+" Ingredient Loss: "+sIngrLoss+" "+sIngrLossUOM+" Total: "+sTotal;
					
					//Child
					 sChildTarget = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
					 sMax = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
					 sUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
					 sMaterialFunc = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
					 sPosIndicator = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
					 sAttrCmt = validator.getStringEquivalentForStringList(mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT));
					 sTotalBatch = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
					 sTBUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
					
					 sFinalBatch  ="Target: "+sTotalBatch+" Range Min: "+sMin +" Range Max  "+sMax+" UOM: "+sTBUOM;
					 
					}
					String	strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
                      
					
					if (util.isModificatinRequired()) {
						// Formulation part does not have ownership on itself,
						// hence expand to get it from the Cosmetic formulation
						//modified by Ganesh for security impl--->start
						/*if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaPropagate = util.getFormulaPropagate(context, sOid);
						}

						if (!sFormulaPropagate.isEmpty()) {
							bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
						}*/
						bHasOwnership = util.checkHasAccess(context, null, sOid);
						//modified by Ganesh for security impl--->start
						if (!bHasOwnership) {
							sOid = ConstantsUtil.NO_ACCESS;
							sType = ConstantsUtil.NO_ACCESS;
							sChg = ConstantsUtil.NO_ACCESS;
							sSAPDesc = ConstantsUtil.NO_ACCESS;
							sFileDesc = ConstantsUtil.NO_ACCESS;
							sSpecSubType = ConstantsUtil.NO_ACCESS;
							sSubstitute = ConstantsUtil.NO_ACCESS;
							sMin = ConstantsUtil.NO_ACCESS;
							sFinalTarget = ConstantsUtil.NO_ACCESS;
							sMax = ConstantsUtil.NO_ACCESS;
							sUOM = ConstantsUtil.NO_ACCESS;
							sMaterialFunc = ConstantsUtil.NO_ACCESS;
							sPosIndicator = ConstantsUtil.NO_ACCESS;
							sAttrCmt = ConstantsUtil.NO_ACCESS;
							sTBUOM = ConstantsUtil.NO_ACCESS;
							sChildTarget = ConstantsUtil.NO_ACCESS;
							sPackingLevel = ConstantsUtil.NO_ACCESS;
							sDispType = ConstantsUtil.NO_ACCESS;
						}
					} else {

						/*StringList slHIRTypes = new StringList();

						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

						boolean showData = true;
						if (slHIRTypes.contains(sType)) {

							String sFormulaClassif = strClassFied;

							if (!sec.isExternalUser()) {
								if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
									sFormulaClassif = util.getFormulaPropagateClassification(context, sOid);
								}
								if (null != sUserlicense && null != sFormulaClassif
										&& !sUserlicense.contains(sFormulaClassif)) {
									showData = false;
								}
							}

							if (!showData) {
								sOid = ConstantsUtil.NO_ACCESS;
								sType = ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
								sSAPDesc = ConstantsUtil.NO_ACCESS;
								sFileDesc = ConstantsUtil.NO_ACCESS;
								sSpecSubType = ConstantsUtil.NO_ACCESS;
								sSubstitute = ConstantsUtil.NO_ACCESS;
								sMin = ConstantsUtil.NO_ACCESS;
								sFinalTarget = ConstantsUtil.NO_ACCESS;
								sMax = ConstantsUtil.NO_ACCESS;
								sUOM = ConstantsUtil.NO_ACCESS;
								sMaterialFunc = ConstantsUtil.NO_ACCESS;
								sPosIndicator = ConstantsUtil.NO_ACCESS;
								sAttrCmt = ConstantsUtil.NO_ACCESS;
								sTBUOM = ConstantsUtil.NO_ACCESS;
								sChildTarget = ConstantsUtil.NO_ACCESS;
								sPackingLevel = ConstantsUtil.NO_ACCESS;
								sDispType = ConstantsUtil.NO_ACCESS;
							}

						}*/
						//modified by Ganesh for security impl---->start
						showData = util.checkHasAccess(context, null, sOid);
						if (!showData) {
							sOid = ConstantsUtil.NO_ACCESS;
							sType = ConstantsUtil.NO_ACCESS;
							sChg = ConstantsUtil.NO_ACCESS;
							sSAPDesc = ConstantsUtil.NO_ACCESS;
							sFileDesc = ConstantsUtil.NO_ACCESS;
							sSpecSubType = ConstantsUtil.NO_ACCESS;
							sSubstitute = ConstantsUtil.NO_ACCESS;
							sMin = ConstantsUtil.NO_ACCESS;
							sFinalTarget = ConstantsUtil.NO_ACCESS;
							sMax = ConstantsUtil.NO_ACCESS;
							sUOM = ConstantsUtil.NO_ACCESS;
							sMaterialFunc = ConstantsUtil.NO_ACCESS;
							sPosIndicator = ConstantsUtil.NO_ACCESS;
							sAttrCmt = ConstantsUtil.NO_ACCESS;
							sTBUOM = ConstantsUtil.NO_ACCESS;
							sChildTarget = ConstantsUtil.NO_ACCESS;
							sPackingLevel = ConstantsUtil.NO_ACCESS;
							sDispType = ConstantsUtil.NO_ACCESS;
						}
						//modified by Ganesh for security impl---->stop
					}
					
					util.formatData(sbEBOMId, sOid);
					util.formatData(sbEBOMType, sType);
					util.formatData(sbEBOMDisplayType, sDispType);
					util.formatData(sbEBOMName, sName);
					util.formatData(sbEBOMChg, sChg);
					util.formatData(sbEBOMSapDes, sSAPDesc);
					util.formatData(sbEBOMFileDesc, sFileDesc);
					util.formatData(sbEBOMSpecSubType, (sSpecSubType==null)?"":sSpecSubType);
					util.formatData(sbEBOMSubStitute, sSubstitute);
					util.formatData(sbEBOMMin, sMin);
					util.formatData(sbEBOMTarget, sFinalTarget);
					util.formatData(sbEBOMMax, sMax);
					util.formatData(sbEBOMUOM, sUOM);
					util.formatData(sbEBOMMaterialFunc, sMaterialFunc);
					util.formatData(sbEBOMPosIndicator, sPosIndicator);
					util.formatData(sbEBOMCmt,sAttrCmt);
					util.formatData(sbEBOMBatch,sTBUOM);
					util.formatData(sbEBOMQuantity,sChildTarget);
					util.formatData(sbEBOMPackingLevel,sPackingLevel);

				}

				
				
				mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbEBOMSapDes.toString());
				//mpEBOMResult.put(ConstantsUtil.FILEDESCRIPTION, sbEBOMFileDesc.toString());
				mpEBOMResult.put(ConstantsUtil.SS, sbEBOMSpecSubType.toString());
				//mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMDisplayType.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
				//mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sDispType.toString());
				mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sbEBOMDisplayType.toString());
				mpEBOMResult.put(ConstantsUtil.SUB, sbEBOMSubStitute.toString());
				//mpEBOMResult.put(ConstantsUtil.MIN, sbEBOMMin.toString());
				//mpEBOMResult.put(ConstantsUtil.TARGET, sbEBOMTarget.toString());
				//mpEBOMResult.put(ConstantsUtil.MAX, sbEBOMMax.toString());
				mpEBOMResult.put(ConstantsUtil.UOM, sbEBOMUOM.toString());
				//mpEBOMResult.put(ConstantsUtil.MF, sbEBOMMaterialFunc.toString());
				//mpEBOMResult.put(ConstantsUtil.PI, sbEBOMPosIndicator.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENT, sbEBOMCmt.toString());
				//mpEBOMResult.put(ConstantsUtil.BATCH, sbEBOMBatch.toString());
				mpEBOMResult.put(ConstantsUtil.QUANTITY, sbEBOMQuantity.toString());
				mpEBOMResult.put(ConstantsUtil.PACKINGLEVEL, sbEBOMPackingLevel.toString());
				
				
				mpFinalEBOM.put(String.valueOf(index), mpEBOMResult);
				mpFinalSubstitute.put(String.valueOf(index), mpSubstituteResult);
				index++;
				
			}
			
			
			MPFinalEBOMSubStitute.put(ConstantsUtil.BILLOFMATERIALS, mpFinalEBOM);
			MPFinalEBOMSubStitute.put(ConstantsUtil.SUBSTITUTEPARTS, mpFinalSubstitute);
			MPFinalEBOMSubStitute.put(ConstantsUtil.HEADER, mpHeaderEBOMResult);
			
			

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in MPSBO:  getPhaseBOM: " + e);
		}
		return MPFinalEBOMSubStitute;

		//return util.filterMapList(mpFinal);
	}

	
	/**
	 * Getting the Substitutes of MPS
	 * @param context
	 * @param mapList
	 * @param sDesc 
	 * @param sFilName 
	 * @return
	 * @throws Exception
	 */

	public Map<String, String> getMPSSubstitutes(Context context, MapList mapList, String sFilName, String sFilDesc) throws Exception 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil  util = new BusObjectAttribUtil();
		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		
		StringBuilder sbFilName = new StringBuilder();
		StringBuilder sbFilDesc = new StringBuilder();
		
		util.formatData(sbFilName, sFilName);
		util.formatData(sbFilDesc, sFilDesc);
		
		
		
		Map mpFinal = new TreeMap();
		try 
		{
			SecurityService sec = new SecurityService();
			String sComp = sec.getUserCauthorities();
			StringList slUserOwnership = util.filterOwnerShip(sComp);
			String sUserlicense = sec.getUserLicense();
			
			Iterator objectListItr = mapList.iterator();
			int j=0;
			while (objectListItr.hasNext()) 
			{
				
				Map<String, String> mpEBOMResult = new HashMap<String, String>();
				StringBuilder sbSubPartType = new StringBuilder();
				StringBuilder sbSubPartName = new StringBuilder();
				StringBuilder sbSubPartId = new StringBuilder();
				StringBuilder sbSubPartTitle = new StringBuilder();
				StringBuilder sbSubPartSpecSubType = new StringBuilder();	
				StringBuilder sbSubPartValidUntiltDt = new StringBuilder();
				StringBuilder sbSubstituteMinQTY = new StringBuilder();
				StringBuilder sbSubstituteChg = new StringBuilder();
				StringBuilder sbSubstituteSCN = new StringBuilder();
				StringBuilder sbSubstituteMaxQTY = new StringBuilder();
				StringBuilder sbSubstituteTarget = new StringBuilder();
				StringBuilder sbSubstituteUOM = new StringBuilder();
				StringBuilder sbSubstitutePI = new StringBuilder();	
				StringBuilder sbSubstituteMF = new StringBuilder();
				StringBuilder sbSubstituteCMT = new StringBuilder();
				StringBuilder sbSubstituteQuantity = new StringBuilder();
				
				
				StringBuilder sbSubForType = new StringBuilder();
				StringBuilder sbSubForName = new StringBuilder();
				StringBuilder sbSubForId = new StringBuilder();
				StringBuilder sbSubForTitle = new StringBuilder();
				
				
				
				Map objectMap = (Map) objectListItr.next();

				if (objectMap.containsKey(ConstantsUtil.SELECT_SUBSTITUTE))
				{
					String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
					String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
					
					
					String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
					boolean isExternal =util.isModificatinRequired(); 
					//commented by Ganesh for security impl stop
					/*String sFormulaPropagate =sId;
					if (isExternal)
					{
						if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							 sFormulaPropagate = util.getFormulaPropagate(context, sFormulaPropagate);
						}
						boolean bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
						if (!bHasOwnership) 
							continue;
					}else if (!isExternal) 
					{
						if (slHIRTypes.contains(sType)) 
						{
							String sFormulaClassif = strClassFied;
							if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
							}
							
							if (null != sUserlicense && null != sFormulaClassif
									&& !sUserlicense.contains(sFormulaClassif)) {
								continue;
							}
							
						}
						
					}commented by Ganesh stop*/
					//Added by Ganesh start
					boolean bHasOwnership = util.checkHasAccess(context, null, sId);
					if (!bHasOwnership) 
						continue;
					//Added by Ganesh stop
					
					String sHasSubstitute = validator.getStringEquivalentForStringList((String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
				
					if (sHasSubstitute.contains("No") || sHasSubstitute.contains("NO")) {
						continue;
					}
					
					
					
					StringList slSubType = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE)));
					StringList sltrValidUntilDt = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
					StringList slSubstituteName = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME)));
					StringList slSubstituteType = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)));
					StringList slSubstituteSCN = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER)));
					StringList slSubstituteMinQTY = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY)));
					StringList slSubstituteMaxQTY = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY)));
					StringList slSubstituteTarget = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET)));
					StringList slSubstituteUOM = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM)));
					StringList slSubstitutePI = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR)));
					StringList slSubstituteMF = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION)));
					/*StringList slSubstituteCMT = util.getStringList(validator.getStringEquivalentForSubstituteString(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT)));*/
					StringList slSubstituteQuantity = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY)));
					
					
					StringList slSubstituteCMT = new StringList();
					
					if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT)){
						
						String clClass = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT).getClass().getSimpleName();
						if (clClass.equals(ConstantsUtil.STRING)) 
						{
							String sSubstituteCMT = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT))?(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT) : ConstantsUtil.EMPTY_STRING;
							//sSubstituteCMT.replace(",", "&");
							slSubstituteCMT= util.getStringList(sSubstituteCMT);
						}else
						{
							slSubstituteCMT = validator.isNotNullOrEmpty((StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						}
						
					}
					
					StringList slSubstituteTitle = new StringList();
					
				if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE)){
					
					String clClass = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE).getClass().getSimpleName();
					if (clClass.equals(ConstantsUtil.STRING)) 
					{
						String sSubstituteTitle = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE))?(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE) : ConstantsUtil.EMPTY_STRING;
						slSubstituteTitle=util.getStringList(sSubstituteTitle);
					}else
					{
						slSubstituteTitle = validator.isNotNullOrEmpty((StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
					}
					
				}
					
					StringList slSubstitutePart = util.getStringList(validator
							.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID)));
					StringList slSubstitutePartCHG = util.getStringList(validator
							.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG)));
					
						for (int i = 0; i < slSubstituteName.size(); i++) 
						{
							if (UIUtil.isNotNullAndNotEmpty(sHasSubstitute)
									&& (sHasSubstitute.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)
											|| sHasSubstitute.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE))) 
							{
								String sSubstituteAssemblyType = util.getValueFromStringList(slSubType,i);
								String sSubstituteUntilDate = util.getValueFromStringList(sltrValidUntilDt,i);
								String sSubstituteName = util.getValueFromStringList(slSubstituteName,i);
								String sSubstituteType = util.getValueFromStringList(slSubstituteType,i);
								String sSubstituteTitle = util.getValueFromStringList(slSubstituteTitle,i);
								String sSubstitutePartId = util.getValueFromStringList(slSubstitutePart,i);
								
								String sSubstituteMinQTY = util.getValueFromStringList(slSubstituteMinQTY,i);
								String sSubstituteSCN = util.getValueFromStringList(slSubstituteSCN,i);
								String sSubstituteMaxQTY = util.getValueFromStringList(slSubstituteMaxQTY,i);
								String sSubstituteTarget = util.getValueFromStringList(slSubstituteTarget,i);
								String sSubstituteUOM = util.getValueFromStringList(slSubstituteUOM,i);
								String sSubstitutePI = util.getValueFromStringList(slSubstitutePI,i);
								String sSubstituteMF = util.getValueFromStringList(slSubstituteMF,i);
								String sSubstituteCMT = util.getValueFromStringList(slSubstituteCMT,i);
								String sSubstituteChg = util.getValueFromStringList(slSubstitutePartCHG,i);
								String sSubstituteQuantity = util.getValueFromStringList(slSubstituteQuantity,i);
								
								sSubstituteType = getMappedType(sSubstituteType);
								
								util.formatData(sbSubPartType, sSubstituteType);
								util.formatData(sbSubPartName, sSubstituteName);
								util.formatData(sbSubForType, util.mapType(sType));
								util.formatData(sbSubForName, sName);
								
								boolean bSubstuteHasAccess = false;
								//commented by Ganesh start
								/*if (isExternal)
								{
									if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										sSubstitutePartId = util.getFormulaPropagate(context, sSubstitutePartId);
									}
									bSubstuteHasAccess = util.checkOwnerShip(context, slUserOwnership, sSubstitutePartId);
									if (!bSubstuteHasAccess) 
										
										util.formatData(sbSubPartId, ConstantsUtil.NO_ACCESS);
										//util.formatData(sbSubPartId, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubPartTitle, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubPartSpecSubType, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubPartValidUntiltDt, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubForId, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubForTitle, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteChg, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteMinQTY, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteSCN, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteMaxQTY, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteTarget, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteUOM, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstitutePI, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteMF, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteCMT, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteQuantity, ConstantsUtil.NO_ACCESS);
										
										continue;
								}else if (!isExternal) 
								{
									if (slHIRTypes.contains(sType)) 
									{
										DomainObject dobSubstitute = new DomainObject(sSubstitutePartId);
										String sSubstituteIPClass = validator.getStringEquivalentForStringList(
												objectMap.get(ConstantsUtil.STR_IPCLASS));
										
										String sSubFormulalassif = sSubstituteIPClass;
										if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
											sSubFormulalassif = util.getFormulaPropagateClassification(context, sSubstitutePartId);
										}
										
										if (null != sUserlicense && null != sSubFormulalassif
												&& !sUserlicense.contains(sSubFormulalassif))
										{
											util.formatData(sbSubPartId, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubPartTitle, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubPartSpecSubType, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubPartValidUntiltDt, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubForId, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubForTitle, ConstantsUtil.NO_ACCESS);
											
											util.formatData(sbSubstituteChg, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteMinQTY, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteSCN, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteMaxQTY, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteTarget, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteUOM, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstitutePI, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteMF, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteCMT, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteQuantity, ConstantsUtil.NO_ACCESS);
											
											continue;
										}
										
									}
									
								}commented by Ganesh stop*/
								//Added by Ganesh Start
								bSubstuteHasAccess = util.checkHasAccess(context, null, sSubstitutePartId);
								if (!bSubstuteHasAccess) 
								{	
									util.formatData(sbSubPartId, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubPartTitle, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubPartSpecSubType, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubPartValidUntiltDt, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubForId, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubForTitle, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteChg, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteMinQTY, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteSCN, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteMaxQTY, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteTarget, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteUOM, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstitutePI, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteMF, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteCMT, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteQuantity, ConstantsUtil.NO_ACCESS);
									
									
							}
								//Added by Ganesh stop
								
								util.formatData(sbSubPartId, sSubstitutePartId);
								util.formatData(sbSubPartTitle, sSubstituteTitle);
								util.formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
								util.formatData(sbSubPartValidUntiltDt, sSubstituteUntilDate);
								util.formatData(sbSubForId, sId);
								util.formatData(sbSubForTitle, sTitle);
								util.formatData(sbSubstituteChg, sSubstituteChg);
								util.formatData(sbFilName, sFilName);
								util.formatData(sbFilDesc, sFilDesc);
								util.formatData(sbSubstituteMinQTY, sSubstituteMinQTY);
								util.formatData(sbSubstituteSCN, sSubstituteSCN);
								util.formatData(sbSubstituteMaxQTY, sSubstituteMaxQTY);
								util.formatData(sbSubstituteTarget, sSubstituteTarget);
								util.formatData(sbSubstituteUOM, sSubstituteUOM);
								util.formatData(sbSubstitutePI, sSubstitutePI);
								util.formatData(sbSubstituteMF, sSubstituteMF);
								util.formatData(sbSubstituteCMT, sSubstituteCMT);
								util.formatData(sbSubstituteQuantity, sSubstituteQuantity);
								
								
							}
							
						}
				} 
				
				mpEBOMResult.put(ConstantsUtil.SF_ID, sbSubForId.toString());
				mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbSubForType.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbSubForName.toString());
				mpEBOMResult.put(ConstantsUtil.USEDINPCT, sFilName.toString());
				mpEBOMResult.put(ConstantsUtil.HEADERSAPDESC, sbSubForTitle.toString());
				//mpEBOMResult.put(ConstantsUtil.FILDESC, sFilDesc.toString());
				mpEBOMResult.put(ConstantsUtil.PCTDESC, sFilDesc.toString());
				
				mpEBOMResult.put(ConstantsUtil.TYPE, sbSubPartType.toString());
				mpEBOMResult.put(ConstantsUtil.ID, sbSubPartId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbSubPartName.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbSubstituteChg.toString());
				mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbSubPartTitle.toString());
				mpEBOMResult.put(ConstantsUtil.SS, sbSubPartSpecSubType.toString());
				mpEBOMResult.put(ConstantsUtil.COMBINATIONNUMBER, sbSubstituteSCN.toString());
				//mpEBOMResult.put(ConstantsUtil.MIN, sbSubstituteMinQTY.toString());
				//mpEBOMResult.put(ConstantsUtil.TARGET, sbSubstituteTarget.toString());
				//mpEBOMResult.put(ConstantsUtil.MAX, sbSubstituteMaxQTY.toString());
				mpEBOMResult.put(ConstantsUtil.UOM, sbSubstituteUOM.toString());
				//mpEBOMResult.put(ConstantsUtil.MF, sbSubstituteMF.toString());
				//mpEBOMResult.put(ConstantsUtil.PI, sbSubstitutePI.toString());
				mpEBOMResult.put(ConstantsUtil.VALIDUNTILDATE, sbSubPartValidUntiltDt.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbSubstituteCMT.toString());
				mpEBOMResult.put(ConstantsUtil.QUANTITY, sbSubstituteQuantity.toString());
				
				
				mpFinal.put(j, mpEBOMResult);
				j++;
				
			}

			

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in MPSBO : getMPSSubstitutes : "+ e);
			return new HashMap();
		}
		return mpFinal;
		//return filterMapList(mpEBOMResult);
	}
	
	
	public Vector getSpecificationSubtype(Context context,MapList objectList) throws Exception
	{
		Vector vc= new Vector();
		/*DSO 2013x.4 - Changes to handle attribute and picklist of Specification Sub Type for Substitute view : START*/


		String strColumnName = "";
		/*DSO 2013x.4 - Changes to handle attribute and picklist of Specification Sub Type for Substitute view : END*/
		Map mapDataMapping = new HashMap();
		mapDataMapping.put("pgPackingMaterial","Packaging");
		mapDataMapping.put("pgRawMaterial","Raw");
		String strAttributeName = PropertyUtil.getSchemaProperty("attribute_pgAssemblyType");
		String strAttributeCSSType = PropertyUtil.getSchemaProperty("attribute_pgCSSType");
		String strTypepgFinishedProduct = PropertyUtil.getSchemaProperty("type_pgFinishedProduct");
		String strTypepgQualitySpecification = PropertyUtil.getSchemaProperty("type_pgQualitySpecification");
		String strAttrPgAssemblyType = "";
		String strTypepgTestMethod= PropertyUtil.getSchemaProperty("type_pgTestMethod");
		String strAttrPgCSSType = "";
		String strID = "";
		// Added for Defect fix 7084 by DSM 2015x.1(Sogeti) Starts
		boolean isContextPushed = false;
		// Added for Defect fix 7084 by DSM 2015x.1(Sogeti) Ends
		//DSO 2013x.4 Added check to handle Specification SubType picklist : START
		String strAssemblyTypeRel = PropertyUtil.getSchemaProperty(context, "relationship_pgPDTemplatestopgPLIAssemblyType");
		String strOriginatingSource = PropertyUtil.getSchemaProperty(context, "attribute_pgOriginatingSource");
		//DSO 2013x.4 Added check to handle Specification SubType picklist : END
		Map mapObject = null;
		String strType="";
		String strRootNode="";
		String strSpecSubType = "";
		/*DSO 2013x.4 - Changes to handle attribute and picklist of Specification Sub Type for Substitute view : START*/
		String strPicklistValue = DomainConstants.EMPTY_STRING;
		/*DSO 2013x.4 - Changes to handle attribute and picklist of Specification Sub Type for Substitute view : END*/
		// Added for Defect fix 7084 by DSM 2015x.1(Sogeti) Starts
		//DSM(DS) 2018x.0 - Fix for ALM 23952 - Incorrect "Specification Sub Type" is getting display in Substitute tab - START
		String sEBOMSubsRelid = DomainConstants.EMPTY_STRING;
		String[] arrRelIdArray = null;
		MapList mlresultList = null;
		Iterator itrEBOM = null;
		Map mpEBOMMap = null;
		StringList slRelSelStmt = new StringList(2);
		slRelSelStmt.add("to."+ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		slRelSelStmt.add("to.id");
		//DSM(DS) 2018x.0 - Fix for ALM 23952 - Incorrect "Specification Sub Type" is getting display in Substitute tab - END
		try{
			ContextUtil.pushContext(context);
			isContextPushed = true;
			// Added for Defect fix 7084 by DSM 2015x.1(Sogeti) Ends
			for (Iterator iterator = objectList.iterator(); iterator.hasNext();)
			{
				mapObject = (Map) iterator.next();
				//DSM(DS) 2018x.0 - Fix for ALM 23952 - Incorrect "Specification Sub Type" is getting display in Substitute tab - START
				//strType=(String)mapObject.get(DomainConstants.SELECT_TYPE);
				strType=(String)mapObject.get("SubstituteType");
				//DSM(DS) 2018x.0 - Fix for ALM 23952 - Incorrect "Specification Sub Type" is getting display in Substitute tab - ENDS

				strID = (String)mapObject.get(DomainConstants.SELECT_ID);	
				DomainObject dom = new DomainObject(strID);
				// Modified for Defect fix 3896 by DSM 2015x.1(Sogeti) Starts
				// commented for Defect fix 7084 by DSM 2015x.1(Sogeti) Starts
				//if(FrameworkUtil.hasAccess(context, dom , "read")!=false){
				// commented for Defect fix 7084 by DSM 2015x.1(Sogeti) Ends
				// Modified for Defect fix 3896 by DSM 2015x.1(Sogeti) Ends
				if(strType==null){
					strType=(String)dom.getInfo(context,DomainConstants.SELECT_TYPE);
				}
				//DSO 2013x.4 Added check to handle Specification SubType picklist : START
				//DSM(DS) 2018x.0 - Fix for ALM 23952 - Incorrect "Specification Sub Type" is getting display in Substitute tab - START
				//if(UTILS.isOfDSOOrigin(context, strID)){
				//DSM(DS) 2018x.0 - Fix for ALM 23952 - Incorrect "Specification Sub Type" is getting display in Substitute tab - END
				/*DSO 2013x.4 - Changes to handle attribute and picklist of Specification Sub Type for Substitute view : START*/
				strPicklistValue = dom.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				if("DSOSubstituteForSpecificationSubType".equalsIgnoreCase(strColumnName)){
					//DSM(DS) 2018x.0 - Fix for ALM 23952 - Incorrect "Specification Sub Type" is getting display in Substitute tab - START
					//DSM(DS) 2018x.0 - ALM 24083 - Invalid Characters in GenDoc and All info view - START
					if(UIUtil.isNotNullAndNotEmpty((String) mapObject.get("EBOM ID"))){
					//DSM(DS) 2018x.0 - ALM 24083 - Invalid Characters in GenDoc and All info view - END
					sEBOMSubsRelid        = (String)mapObject.get("EBOM ID");
					arrRelIdArray          = new String[1];
					arrRelIdArray[0]          = sEBOMSubsRelid;
					mlresultList           = DomainRelationship.getInfo(context,arrRelIdArray,slRelSelStmt);
					itrEBOM                 = mlresultList.iterator();
					mpEBOMMap = (Map) itrEBOM.next();
					strPicklistValue        =(String)mpEBOMMap.get("to."+ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					strID = (String)mpEBOMMap.get("to.id");
					dom.setId(strID);
					}
				    //DSM(DS) 2018x.0 - ALM 24083 - Invalid Characters in GenDoc and All info view - START
					else {
						strPicklistValue = dom.getInfo(context, "from["+DomainConstants.RELATIONSHIP_EBOM+"].to."+ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					}
					//DSM(DS) 2018x.0 - ALM 24083 - Invalid Characters in GenDoc and All info view - END
					//DSM(DS) 2018x.0 - Fix for ALM 23952 - Incorrect "Specification Sub Type" is getting display in Substitute tab - END

					//DSM(DS) 2018x.0 - Fix for ALM 23952 - Incorrect "Specification Sub Type" is getting display in Substitute tab - START
				}
				BusObjectAttribUtil util = new BusObjectAttribUtil();
				if(util.isOfDSOOrigin(context, strID)){
					//DSM(DS) 2018x.0 - Fix for ALM 23952 - Incorrect "Specification Sub Type" is getting display in Substitute tab - END
					//}

					if(UIUtil.isNullOrEmpty(strPicklistValue)){
						strPicklistValue = "";
					}
					mapDataMapping.put(strType, strPicklistValue);
					/*DSO 2013x.4 - Changes to handle attribute and picklist of Specification Sub Type for Substitute view : END*/

				} else {
			//DSO 2013x.4 Added check to handle Specification SubType picklist : END				
			if (strTypepgFinishedProduct.equals(strType))
			{
				strAttrPgAssemblyType = dom.getInfo(context, //context
						"attribute["+strAttributeName+"]");//java.lang.String select
				//Modified by V4 as per defect 1132 - Starts	
				if("".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgFinishedProduct","Finished Product");
				}
				else if("FWIP-Finished Work in Process".equals(strAttrPgAssemblyType)) {
					mapDataMapping.put("pgFinishedProduct","FWIP-Finished Work in Process");			
				}
				/*else if("FWIP-Finished Work in Process".equals(strAttrPgAssemblyType)) {
				 mapDataMapping.put("pgFinishedProduct","FWIP");			
				}*/
				//Modified by V4 as per defect 1132 - Ends
				else if("Purchased Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgFinishedProduct","Purchased Subassembly");	
				}
				else if("Purchased and/or Produced Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgFinishedProduct","Purchased and/or Produced Subassembly");	
				}				
			} else if (strTypepgQualitySpecification.equals(strType)){
				strAttrPgCSSType = dom.getInfo(context,"attribute["+strAttributeCSSType+"]");
				//DSM(Sogeti) - 2015x.2 Added for defect 7790 - Starts
				if(!UIUtil.isNullOrEmpty(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification",strAttrPgCSSType);
				}
				else{
					strAttrPgAssemblyType=dom.getInfo(context,"attribute["+strAttributeName+"]");
					if(!UIUtil.isNullOrEmpty(strAttrPgAssemblyType)){
						if(strAttrPgAssemblyType.equalsIgnoreCase("Sampling"))
						{
							strSpecSubType = "SMPL";
						} 
						else if(strAttrPgAssemblyType.equalsIgnoreCase("Cleaning/Inspection/Lubrication"))
						{
							strSpecSubType = "CIL";
						}
						mapDataMapping.put("pgQualitySpecification",strSpecSubType);
					}
				}
				//DSM(Sogeti) - 2015x.2 Added for defect 7790 - Ends
			} else if (strTypepgTestMethod.equals(strType))
			{   strAttrPgCSSType = dom.getInfo(context, //context
					"attribute["+strAttributeCSSType+"]");//java.lang.String select
			if ("TAMU".equals(strAttrPgCSSType)){
				mapDataMapping.put("pgTestMethod","TAMU");
			}
			else{
				mapDataMapping.put("pgTestMethod","");
			}
			}
			//P&G: Added for V4 to include pgPackingSubassembly
			else if (ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY.equals(strType))
			{
				strAttrPgAssemblyType = dom.getInfo(context, //context
						"attribute["+strAttributeName+"]");//java.lang.String select
				if("Purchased Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgPackingSubassembly","Purchased Subassembly");	
				}
				else if("Purchased and/or Produced Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgPackingSubassembly","Purchased and/or Produced Subassembly");	
				}				
				//DSO 2013x.4 Added check to handle Specfication SubType picklist : START
				}
				//DSO 2013x.4 Added check to handle Specfication SubType picklist : END
			}
			//P&G: Addition by V4 ends
			strRootNode=(String)mapObject.get("Root Node");
			if(!"true".equalsIgnoreCase(strRootNode))
			{
				strSpecSubType = (String)mapDataMapping.get(strType);
				if(strSpecSubType != null)
				{
					vc.add(strSpecSubType);
				}
				else
				{
					vc.add("");
				}
			}else{
				vc.add("");
			}
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dom.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		}
		}
		catch(Exception e){
		throw e;
		}
		finally{
		if(isContextPushed){
		ContextUtil.popContext(context);
		}
		}
		return vc;
	}
	
	
public String getMappedType(String sType){
		
		try
		{
			Map mapCodeMapping = new HashMap();
			mapCodeMapping.put("pgApprovedSupplierList", "ASL");
			mapCodeMapping.put("pgArtwork", "ART");
			mapCodeMapping.put("pgBaseFormula","BSF");
			mapCodeMapping.put("ECR","CR");
			mapCodeMapping.put("pgCommonPerformanceSpecification", "CPST");
			mapCodeMapping.put("pgConsumerDesignBasis","CDB");
			mapCodeMapping.put("pgFinishedProduct","FP");
			mapCodeMapping.put("pgIllustration", "ILST");
			mapCodeMapping.put("pgLogisticSpec", "LOG");
			mapCodeMapping.put("pgMakingInstructions","MI");
			mapCodeMapping.put("pgMasterPackingMaterial","MPMS");
			mapCodeMapping.put("pgMasterRawMaterial", "MRMS");
			mapCodeMapping.put("pgMasterFinishedProduct","MPS");
			mapCodeMapping.put("pgPackingMaterial","MATL");
			mapCodeMapping.put("pgRawMaterial","MATL");
			mapCodeMapping.put("Shared Table","CPS");
			mapCodeMapping.put("pgNonGCASPart", "NGCAS");
			mapCodeMapping.put("pgPackingInstructions", "PI");
			mapCodeMapping.put("pgPackingSubassembly","PSUB");
			mapCodeMapping.put("pgProcessStandard", "PROS");
			mapCodeMapping.put("pgApplianceProduct", "APP");
			mapCodeMapping.put("pgAssembledProduct","ASP");
			mapCodeMapping.put("pgFormulatedProduct","FC");
			mapCodeMapping.put("pgQualitySpecification", "QUAL");
			mapCodeMapping.put("pgStackingPattern", "SPS");
			mapCodeMapping.put("pgStandardOperatingProcedure","SOP");
			mapCodeMapping.put("pgSupplierInformationSheet", "SIS");
			mapCodeMapping.put("pgTestMethod", "TM");
			mapCodeMapping.put("Safety And Regulatory Characteristic","SRS");
			mapCodeMapping.put("pgFormulatedMaterial","FMATL");
			mapCodeMapping.put("pgMaterial","MATL");		
			mapCodeMapping.put("Finished Product Part", "FPP");
			mapCodeMapping.put("pgConsumerUnitPart", "COP");
			mapCodeMapping.put("pgCustomerUnitPart", "CUP");
			mapCodeMapping.put("pgInnerPackUnitPart", "IP");
			mapCodeMapping.put("pgTransportUnitPart", "TUP");
			mapCodeMapping.put("pgMasterConsumerUnitPart", "MCOP");
			mapCodeMapping.put("pgMasterCustomerUnitPart", "MCUP");
			mapCodeMapping.put("pgMasterInnerPackUnitPart", "MIP");
			mapCodeMapping.put("pgAncillaryPackagingMaterialPart", "APMP");
			mapCodeMapping.put("pgPromotionalItemPart", "PIP");
			mapCodeMapping.put("Formulation Part", "FOP");
			mapCodeMapping.put("Packaging Material Part", "PMP");
			mapCodeMapping.put("Raw Material", "RMP");
			mapCodeMapping.put("pgMasterPackagingMaterialPart", "MPMP");
			mapCodeMapping.put("Packaging Assembly Part", "PAP");
			mapCodeMapping.put("pgMasterPackagingAssemblyPart", "MPAP");
			mapCodeMapping.put("pgPackingInstructions", "PI");
			mapCodeMapping.put("pgAuthorizedTemporarySpecification", "ATS");
			mapCodeMapping.put("pgStackingPattern", "SPS");
			mapCodeMapping.put("pgPPMConstituent", "CNT");
			mapCodeMapping.put("pgOnlinePrintingPart", "OPP");
			mapCodeMapping.put("pgFabricatedPart","FAB");
			mapCodeMapping.put("pgAncillaryRawMaterialPart","ARMP");
			mapCodeMapping.put("pgAssembledProductPart","APP");
			mapCodeMapping.put("pgAuthorizedConfigurationStandard","ACS");
			mapCodeMapping.put("pgDeviceProductPart","DPP");
			mapCodeMapping.put("Formula Technical Specification","IAPS");
			mapCodeMapping.put("pgMasterProductPart","MPP");
			mapCodeMapping.put("pgMasterRawMaterialPart","MRMP");
			mapCodeMapping.put("Formulation Process","FOPR");
			
			if (ConstantsUtil.TYPE_PGPHASE.equals(sType)) {
				
				return "";
				
			}else{
				
				return	(String)mapCodeMapping.get(sType);
			}
			
		}catch(Exception e){
			LOGGER.error("Exception in MPSBO : getMPSSubstitutes : "+ e);
			return sType;
		}
	}



public MapList getPerformChars(Context context, String objectId) {

	MapList objList = null;

	MapList outputList = new MapList();
	try {
		BusObjectAttribUtil utill = new BusObjectAttribUtil();

		StringList objectSelects = new StringList();
		objectSelects.add(DomainConstants.SELECT_ID);
		objectSelects.add(DomainObject.SELECT_NAME);
		objectSelects.add(DomainObject.SELECT_TYPE);
		
		objectSelects.add(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS);
		objectSelects.add("attribute[Specification]");
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGTEXT);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		objectSelects.add("to[Reference Document].from.name");
		objectSelects.add("to[Reference Document].from.type");
		objectSelects.add("to[Reference Document].from.attribute[pgShareWithSuppliers]");
			// Guna Added for Defect 38346 18x.5.2 Release -- START
			objectSelects.add(ConstantsUtil.SELECT_TEST_METHOD_TONAME);
			objectSelects.add(ConstantsUtil.SELECT_REF_DOC_TO_ID);
			objectSelects.add(ConstantsUtil.SELECT_TEST_METHOD_TOTYPE);
			objectSelects.add(ConstantsUtil.SELECT_TEST_METHOD_TOID);
			// Guna Added for Defect 38346 18x.5.2 Release -- END
			objectSelects.add(ConstantsUtil.SELECT_REF_DOC_TO_CSS);
			objectSelects.add(DomainConstants.SELECT_LEVEL);
			objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC);
			objectSelects.add("to[Shared Characteristic].from.name");
			objectSelects.add("to[Shared Characteristic].from.type");
			objectSelects.add("to[Shared Characteristic].from.id");
			// START :: gaikwad.tg
			objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CPSID);
			objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME);
			objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE);
			// END :: gaikwad.tg
			StringList relSelects = new StringList();
			relSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
			relSelects.add("from.name");
			relSelects.add("to.name");
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);


		String relPattern = ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + ","
				+ ConstantsUtil.RELATIONSHIP_SHARED_TABLE + "," + ConstantsUtil.RELATIONSHIP_SHAREDCHARACTERISTIC+ "," + "Extended Data";;

		String type = PropertyUtil.getSchemaProperty("type_pgPerformanceCharacteristic");

		String typePattern = ConstantsUtil.TYPE_SHARED_TABLE + "," + type;

		DomainObject doObj = DomainObject.newInstance(context, objectId);

		boolean isShared = Boolean.valueOf((String) doObj.getInfo(context, "relationship[Shared Table]"));

		if (isShared) {
			objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects, false,
					true, (short) 2, null, null, 0);
		} else {
			objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects, false,
					true, (short) 1, null, null, 0);
		}
		//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		doObj.close(context);
		//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

		Iterator sharedmapItr = objList.iterator();
		HashMap sharedmap = new HashMap();

		while (sharedmapItr.hasNext()) {
			Map perMap = (Map) sharedmapItr.next();
			String mapType = (String) perMap.get(DomainObject.SELECT_TYPE);
			String tableSeqNo = (String) perMap
					.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
			String tabName = (String) perMap.get("name");

			if (mapType.equals(ConstantsUtil.TYPE_SHARED_TABLE)) {
				Vector charList = new Vector();
				charList.add(tableSeqNo);
				charList.add(perMap);
				sharedmap.put(tabName, charList);
			}

		}

		StringList tabList = new StringList();
		Set sharedTabNames = new HashSet();
		sharedTabNames.addAll(sharedmap.keySet());
		Integer sortNo = 0;
		Iterator objListItr = objList.iterator();

		while (objListItr.hasNext()) {

			Map perMap = (Map) objListItr.next();

			String seq = (String) perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);

			if (!"".equals(seq) && seq != null) {
				sortNo = Integer.parseInt(seq) * 100;
			}

			perMap.put("sortNo", "" + sortNo);

			String relation = (String) perMap.get("relationship");

			if (relation.equals(ConstantsUtil.RELATIONSHIP_SHAREDCHARACTERISTIC)) {

				String tableName = (String) perMap.get("from.name");

				Vector charList = (Vector) sharedmap.get(tableName);

				String tabSeqNo = "0";

				if (charList != null && !charList.isEmpty()) {

					tabSeqNo = (String) charList.get(0);

				}

				if ((sharedTabNames.contains(tableName)) && (null != tabSeqNo) && (!tabSeqNo.isEmpty())) {
					sharedTabNames.remove(tableName);
				}

				String perMapSeqNo = (String) perMap
						.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
				sortNo = Integer.parseInt(tabSeqNo) * 100 + Integer.parseInt(perMapSeqNo);
				perMap.put("sortNo", "" + sortNo);

			}

			if (!relation.equals("Shared Table")) {

				outputList.add(perMap);

			}

		}

		for (Iterator emptySharedTableItr = sharedTabNames.iterator(); emptySharedTableItr.hasNext();) {

			String tableName = (String) emptySharedTableItr.next();
			Vector charList = (Vector) sharedmap.get(tableName);

			String tabSeqNo = "0";

			if (charList != null && !charList.isEmpty()) {

				tabSeqNo = (String) charList.get(0);

			}

			sortNo = Integer.parseInt(tabSeqNo) * 100;
			Map perMap = (Map) charList.get(1);
			perMap.put("sortNo", "" + sortNo);
			outputList.add(perMap);

		}

		try {
			outputList.sort("sortNo", "ascending", "Integer");

		} catch (Exception ex) {

			ex.printStackTrace();

		}

		if (outputList.size() > 0)
			return pgGetCharacteristicList(context, outputList);
		else
			return outputList;

	} catch (Exception e) {

		e.printStackTrace();

	}
  
	return outputList;
}

public static MapList pgGetCharacteristicList(Context context, MapList inputList) throws Exception {

	Iterator objListItr = inputList.iterator();

	int nCount = 0;

	MapList outputList = new MapList();

	while (objListItr.hasNext()) {

		Map perMap = (Map) objListItr.next();

		nCount++;

		perMap.put("nCount", "" + nCount);

		outputList.add(perMap);

	}
	return outputList;

}

public Map getPerformanceSpecifications(Context context,String objID){
	
	StringValidatorUtil validator = new StringValidatorUtil();
	Map<String, String> mpFinal = new HashMap<String, String>();
	
	BusExtractUtil utill = new BusExtractUtil();
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	
	StringBuilder sbNo = new StringBuilder();
	StringBuilder schg = new StringBuilder();
	StringBuilder sCharcteristic = new StringBuilder();
	StringBuilder sCharSpec = new StringBuilder();
	StringBuilder sTMNActualName = new StringBuilder();
	StringBuilder sTMNActualID = new StringBuilder();
	StringBuilder sTMNActualType = new StringBuilder();
	
	try 
	{
	
		MapList ml = getPerformChars(context, objID);
		
		//System.out.println("ml------------------------"+ml.size());
		Iterator itrSubPartsFor = ml.iterator();
		while (itrSubPartsFor.hasNext()) 
		{
			Map objectMap = (Map) itrSubPartsFor.next();
			
			String sNO = validator.getStringEquivalentForStringList(objectMap.get("nCount"));
			String sPchg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE));
			String sPCharcteristic = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC));
			String sPCharSpec = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS));
			
			Map mpProcessedTM =getProcessTMRD(context ,objectMap);
			
			String sTMType = (String)mpProcessedTM.get(ConstantsUtil.TYPE);
			String sTMName = (String)mpProcessedTM.get(ConstantsUtil.TYPE);
			String sTMId = (String)mpProcessedTM.get(ConstantsUtil.TYPE);
			
			util.formatData(sbNo, sNO);
			util.formatData(schg, sPchg);
			util.formatData(sCharcteristic, sPCharcteristic);
			util.formatData(sCharSpec, sPCharSpec);
			util.formatData(sTMNActualType, sTMType);
			util.formatData(sTMNActualID, sTMId);
			util.formatData(sTMNActualName, sTMName);
					
		}
		
		mpFinal.put(ConstantsUtil.NUMBER, sbNo.toString());
		mpFinal.put(ConstantsUtil.CHG, schg.toString());
		mpFinal.put(ConstantsUtil.CHARACTERISTICCH, sCharcteristic.toString());
		mpFinal.put(ConstantsUtil.CS, sCharSpec.toString());
		
		mpFinal.put(ConstantsUtil.TMTYPE, sTMNActualType.toString());
		mpFinal.put(ConstantsUtil.TESTMETHODNAME, sTMNActualName.toString());
		mpFinal.put(ConstantsUtil.TESTMETHODNAMEID, sTMNActualID.toString());
		
	} catch (Exception e) {

		e.printStackTrace();

	}
	return mpFinal;
}
	

private static Map getProcessTMRD(Context context,Map objectMap) 
{
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	StringValidatorUtil validator = new StringValidatorUtil();
	Map mpIndexes = new HashMap();;
	boolean bHasOwnerShip = false;
	StringList sbFinalIndex = new StringList();
	SecurityService ss = new SecurityService();
	String sUserCompanies = ss.getUserCauthorities();
	String[] aCompany = sUserCompanies.split(",");
	StringBuilder sbCompany = new StringBuilder();

	if (aCompany.length > -1) {
		for (int i = 0; i < aCompany.length; i++) {
			if (null != aCompany[i]) {
				String Company = aCompany[i].toString();
				sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
			}
		}
	}

try
	{

	StringList slPTMName = util.getStringList(validator
			.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
					? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
					: ConstantsUtil.EMPTY_STRING);
	StringList slPTMType = util.getStringList(validator
			.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
					? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
					: ConstantsUtil.EMPTY_STRING);
	StringList slTMHasSharedAccess = util.getStringList(validator.isNotNullOrEmpty((String) objectMap
			.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS))
					? (String) objectMap
							.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS)
					: ConstantsUtil.EMPTY_STRING);
	StringList slPTMNameID = util.getStringList(validator
			.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
					: ConstantsUtil.EMPTY_STRING);
					
	StringList slPCSSType = util.getStringList(validator
			.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_CSS))
					? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_CSS)
					: ConstantsUtil.EMPTY_STRING);
					
	
	StringList slSelects = new StringList();
	slSelects.add(ConstantsUtil.OWNERSHIP);
	
	
	StringBuilder sbPName = new StringBuilder();
	StringBuilder sbPId = new StringBuilder();
	StringBuilder sbPType = new StringBuilder();
	
	String sType = ConstantsUtil.TYPE_TESTMETHODSPECIFCATION;
	for (int i = 0; i < slPTMType.size(); i++) 
	{
		if (sType.equals(slPTMType.get(i)) && !"TAMU".equals(slPCSSType.get(i))) 
		{
			sbPType.append(slPTMType.get(i)).append("&");
			sbPName.append(slPTMName.get(i)).append("&");
			if (util.isModificatinRequired()) 
			{
				if("TRUE".equalsIgnoreCase(slTMHasSharedAccess.get(i)))
				{
					DomainObject dob = new DomainObject(slPTMNameID.get(i));
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.OWNERSHIP);
					Map mpChildOwnership = dob.getInfo(context, slSelects);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					dob.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.OWNERSHIP);

					/*String sPartOwnership=	validator.getStringEquivalentForStringList(mpChildOwnership.get(ConstantsUtil.OWNERSHIP));
					
					StringList slEachOwnership = util.filterOwnerShip(sPartOwnership);
					bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);*/
					//modified by Ganesh for security impl ------>start
					bHasOwnerShip = util.checkHasAccess(context, null, slPTMNameID.get(i));
					//modified by Ganesh for security impl ------>end
					if (bHasOwnerShip) 
						sbPId.append(slPTMNameID.get(i)).append("&");
					else
						sbPId.append("").append("&");
			    }else{
			    	sbPId.append("").append("&");
			    }
			}else
			{
				sbPId.append(slPTMNameID.get(i)).append("&");
			}
		 }
	}
	
	mpIndexes .put(ConstantsUtil.TYPE, sbPType.toString());
	mpIndexes.put(ConstantsUtil.NAME, slPTMName);
	mpIndexes.put(ConstantsUtil.REV, slTMHasSharedAccess);
	mpIndexes.put(ConstantsUtil.ID, slPTMNameID);
	
	}catch(Exception e){
		//LOGGER.error("Error from BusExtractUtil :  getProcessTMRD : " + e);
	}
	return mpIndexes;
	}


/**
 * Method Name 			: parseTransMaplist
 * Method Description 	:
 * @param context 
 * @param mapList
 * @param sFPName 
 * @param sFPType 
 * @param sID 
 * @param env 
 * @return
 */
public Map<String, String> parseTransMaplist(Context context, MapList mapList, String sID, String sFPType, String sFPName, Environment env) {
	Map<String, String> mpTransportUnit = new HashMap<String, String>();
	Iterator objectListItr = mapList.iterator();
	StringBuilder sbPalletType = new StringBuilder();
	StringBuilder sbOuterDimLength = new StringBuilder();
	StringBuilder sbTruckMaxHt = new StringBuilder();
	StringBuilder sbOuterDimWidth = new StringBuilder();
	StringBuilder sbOuterDimHeight = new StringBuilder();
	StringBuilder sbDimUOM = new StringBuilder();
	StringBuilder sbCUPLI = new StringBuilder();
	StringBuilder sbCUPTLI = new StringBuilder();
	StringBuilder sbWCMHT = new StringBuilder();
	StringBuilder sbCubeEff = new StringBuilder();
	StringBuilder sbTackPattern = new StringBuilder();
	StringBuilder sbNumOfCUPPerTUP = new StringBuilder();
	StringBuilder sbIsPrimary = new StringBuilder();
	StringBuilder sbGrossWithPallet = new StringBuilder();
	StringBuilder sbGrossWithOutPallet = new StringBuilder();
	StringBuilder sbGrossUOM = new StringBuilder();
	StringBuilder sbIncludedInBomAsFed = new StringBuilder();
	StringBuilder sbPalletMaxHt = new StringBuilder();
	StringBuilder sbTackPatternID = new StringBuilder();
	StringBuilder sbTackPatternType = new StringBuilder();
	StringBuilder sbTuvUOM = new StringBuilder();

	BusObjectAttribUtil util = new BusObjectAttribUtil();
	StringValidatorUtil validator = new StringValidatorUtil();
	
	try {
		
		BusExtractUtil utill = new BusExtractUtil();
		String sGtinValue = ConstantsUtil.EMPTY_STRING;
		//String sGtinValue = utill.getGTINValue(context, mapList, sID, sFPType,sFPName, false,env);
		
		while (objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
			
			
			String sPalletType = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE));
			String sOuterDimLength = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH));
			String sOuterDimWidth = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH));
			String sOuterDimHeight = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT));
			String sDimUOM = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM));
			String sCUPLI = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER));
			String sCUPTLI = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER));
			String sWCMHT = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSECASEMAXHEIGHT));
			String sTruckMaxHt = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT));
			String sTackPattern = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_STACKINGPATTERNGCASCODENAME));
			String sTackPatternID = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_STACKINGPATTERNGCASCODEID));
			String sTackPatternType = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_STACKINGPATTERNGCASCODETYPE));
			String sNumOfCUPPerTUP = getNumOfCUPPerTUP(objectMap);
			String sCubeEff = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUBEEFFECIENCY));
			String sPalletMaxHt = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT));
			String strIncludedInBomAsFed = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRIMARY));
			String sIsPrimary = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRIMARY));
			String sGrossWithPallet = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHPALLETREAL));
			String sGrossWithOutPallet = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLETREAL));
			String sGrossUOM = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
			String sTuvUOM = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM));

			
			
			util.formatData(sbPalletType, sPalletType);
			util.formatData(sbOuterDimLength, sOuterDimLength);
			util.formatData(sbOuterDimWidth, sOuterDimWidth);
			util.formatData(sbOuterDimHeight, sOuterDimHeight);
			util.formatData(sbDimUOM, sDimUOM);
			util.formatData(sbCUPLI, sCUPLI);
			util.formatData(sbCUPTLI, sCUPTLI);
			util.formatData(sbWCMHT, sWCMHT);
			util.formatData(sbTruckMaxHt, sTruckMaxHt);
			util.formatData(sbTackPattern, sTackPattern);
			util.formatData(sbTackPatternID, sTackPatternID);
			util.formatData(sbTackPatternType, sTackPatternType);
			util.formatData(sbNumOfCUPPerTUP, sNumOfCUPPerTUP);
			util.formatData(sbCubeEff, sCubeEff);
			util.formatData(sbIsPrimary, sIsPrimary);
			util.formatData(sbGrossWithPallet, sGrossWithPallet);
			util.formatData(sbGrossWithOutPallet, sGrossWithOutPallet);
			util.formatData(sbGrossUOM, sGrossUOM);
			util.formatData(sbIncludedInBomAsFed, strIncludedInBomAsFed);
			util.formatData(sbPalletMaxHt, sPalletMaxHt);
			util.formatData(sbTuvUOM, sTuvUOM);
		}

		mpTransportUnit.put(ConstantsUtil.PALLETTYPE, sbPalletType.toString());
		mpTransportUnit.put(ConstantsUtil.GTIN, sGtinValue);
		mpTransportUnit.put(ConstantsUtil.DEPTH, sbOuterDimLength.toString());
		mpTransportUnit.put(ConstantsUtil.WIDTH, sbOuterDimWidth.toString());
		mpTransportUnit.put(ConstantsUtil.HEIGHT, sbOuterDimHeight.toString());
		mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE, sbDimUOM.toString());
		mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHPALLET, sbGrossWithPallet.toString());
		mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHOUTPALLET, sbGrossWithOutPallet.toString());
		mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE1, sbTuvUOM.toString());
		mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE2, sbGrossUOM.toString());
		mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERLAYER, sbCUPLI.toString());
		mpTransportUnit.put(ConstantsUtil.NUMBEROFLAYERSPERTRANSPORTUNIT, sbCUPTLI.toString());
		mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERTRANSPORTUNIT, sbNumOfCUPPerTUP.toString());
		mpTransportUnit.put(ConstantsUtil.WAREHOUSEPALLETSTACKHEIGHTMAXIMUM, sbPalletMaxHt.toString());
		mpTransportUnit.put(ConstantsUtil.WAREHOUSECASESTACKHEIGHTMAXIMUM, sbWCMHT.toString());
		mpTransportUnit.put(ConstantsUtil.TRUCKPALLETSTACKHEIGHTMAXIMUM, sbTruckMaxHt.toString());
		mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODE, sbTackPattern.toString());
		mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODEID, sbTackPatternID.toString());
		mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODETYPE, sbTackPatternType.toString());
		mpTransportUnit.put(ConstantsUtil.CUBEEFFICIENCY, sbCubeEff.toString());
		mpTransportUnit.put(ConstantsUtil.INCLUDEINSAPBOMFEED, sbIncludedInBomAsFed.toString());


	} catch (Exception e) {
		LOGGER.error("Error from MPSBO :  parseTransMaplist" + e);
		return new HashMap();
	}

	return util.filterMapList(mpTransportUnit);
}


/**
 * Method Name 			: getNumOfCUPPerTUP
 * Method Description 	:
 * @param resultMap
 * @return
 */
public String getNumOfCUPPerTUP(Map resultMap) {
	StringValidatorUtil validator = new StringValidatorUtil();
	String sQty = DomainConstants.EMPTY_STRING;
	try {
		boolean sClass = resultMap.containsKey(ConstantsUtil.STR_PARTSPEC_QUANTITY);
		if (sClass) {
			String sClassName = (resultMap.get(ConstantsUtil.STR_PARTSPEC_QUANTITY)).getClass().getSimpleName();
			if (sClassName.equals(ConstantsUtil.STRINGLIST)) {
				StringList slQty = validator
						.isNotNullOrEmpty((StringList) resultMap.get(ConstantsUtil.STR_PARTSPEC_QUANTITY));
				StringList slType = validator
						.isNotNullOrEmpty((StringList) resultMap.get(ConstantsUtil.STR_EBOM_TYPE));
				for (int i = 0; i < slQty.size(); i++) {
					String stype = slType.get(i);
					String sTempQty = slQty.get(i);
					if (stype.equals(ConstantsUtil.TYPE_PGMASTERCUSTOMERUNITPART)) {
						sQty = sTempQty;
					}
				}
			} else {

				sQty = validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.STR_PARTSPEC_QUANTITY))
						? (String) resultMap.get(ConstantsUtil.STR_PARTSPEC_QUANTITY) : ConstantsUtil.EMPTY_STRING;
						String sType = validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.STR_EBOM_TYPE))
								? (String) resultMap.get(ConstantsUtil.STR_EBOM_TYPE) : ConstantsUtil.EMPTY_STRING;
			}
		}
	} catch (Exception e) {
		LOGGER.error("Exception in Program : MPSBO Method :getNumOfCUPPerTUP " + e);
		return DomainConstants.EMPTY_STRING;
	}
	return sQty;
}


/**
 * Method Name 			: getPackagingDimensions
 * Method Description 	: For getting the Packing characteristics of FPP
 * @param context
 * @param mlObjectList
 * @param mpPackingUnit
 * @param env 
 * @return
 * @throws Exception
 */
public Map<String, String> getPackagingDimensions(Context context, MapList mlObjectList, Map<String, String> mpPackingUnit, String sId, String sFPType, String sFPName, Environment env) throws Exception {
	StringList slReturnVal = new StringList();
	StringBuilder sbDepth = new StringBuilder();
	StringBuilder sbWidth = new StringBuilder();
	StringBuilder sbHeight = new StringBuilder();
	StringBuilder sbDimUom= new StringBuilder();
	StringList strPGDUoM = new StringList();
	StringBuilder sbGrossWtUom = new StringBuilder();
	StringBuilder sbNetWt = new StringBuilder();
	StringBuilder sbAuom = new StringBuilder();
	StringBuilder sbGrossWtReal = new StringBuilder();
	StringBuilder sbPackingType = new StringBuilder();
	StringBuilder sbNetWetOfProdInCU = new StringBuilder();
	StringBuilder sbGtin = new StringBuilder();
	StringBuilder sbId = new StringBuilder();
	StringBuilder sbCubeEff = new StringBuilder();

	try
	{

		String  sAttrName = "";
		String  strReportFormat = "";
		String sDepthVal = "";
		String sWidthVal = "";
		String sHeightVal = "";
		String sDimUoMVal = "";
		String sConnectionId="";
		String sConn="";
		String strResult="";

		BusExtractUtil utill = new BusExtractUtil();
		String sGtinValue = ConstantsUtil.EMPTY_STRING;
		//String sGtinValue = utill.getGTINValue(context, mlObjectList, sId, sFPType,sFPName, true,env);
		
		StringBuilder sbNPC =  getNumberPerCustomerUnit(context,mlObjectList);
		Iterator objListItr = mlObjectList.iterator();
		while (objListItr.hasNext()) {

			Map perMap = (Map) objListItr.next();
			String sObjectId = (String)perMap.get(DomainConstants.SELECT_ID);
			String sType = (String)perMap.get(DomainConstants.SELECT_TYPE);

			String strGrossWth = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			String strNetWetUoM = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
			String strGrossWtReal = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
			String strNetWetOfProdInCU = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
			String sAUOM =  (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
			String sGtin =  (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);
			String sCubeEff = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUBEEFFICIENCY);

			formatData(sbGtin,sGtin);
			formatData(sbId,sObjectId);
			formatData(sbGrossWtUom,strGrossWth);
			formatData(sbNetWt,strNetWetUoM);
			formatData(sbAuom,sAUOM);
			formatData(sbGrossWtReal,strGrossWtReal);
			formatData(sbNetWetOfProdInCU,strNetWetOfProdInCU);
			formatData(sbCubeEff,sCubeEff);

			sType = util.mapType(sType);
			String sName =(String)perMap.get(ConstantsUtil.SELECT_NAME);
			sName = sType+ConstantsUtil.SYMBL_OPNBRACE+ sName +ConstantsUtil.SYMBL_CLSBRACE;
			formatData(sbPackingType,sName);

			if(sType != null && !"".equals(sType)){
				if(sObjectId != null && !"".equals(sObjectId))
				{
					sConn="";
					sDepthVal = "";
					sWidthVal = "";
					sHeightVal = "";

					String sMQLStmt = "print connection $1 select $2 dump $3;";
					DomainObject bomObject = DomainObject.newInstance(context,sObjectId);
					StringList sConnList = bomObject.getInfoList(context, "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM+"].id");
					for(int i=0;i<sConnList.size();i++)

					{
						sConnectionId=(String)sConnList.get(i);
						String querycommand="print connection"+" "+"\"$1\""+" "+ "select $2 dump  $3";
						strResult=MqlUtil.mqlCommand(context,querycommand,sConnectionId,"frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"]","|").trim();

						if(strResult.equalsIgnoreCase("True"))
						{
							sConn=sConnectionId;
							break;
						}
						else
						{
							continue;
						}
					}

					String sSelectable1 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTR_OUTER_DIMENSION_LENGTH+"].value";
					String sSelectable2 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTR_OUTER_DIMENSION_WIDTH+"].value";
					String sSelectable3 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTRIBUTE_PG_OUTERDIMENSIONHEIGHT+"].value";
					String sSelectable4 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTRIBUTE_PG_DIMENSTION_UOM+"].value";

					String sSelectable5 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT+"].value";

					String tempVal = new String();						
					if(sConn != null && !"".equals(sConn))
					{

						sDepthVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable1, "|");
						sWidthVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable2, "|");
						sHeightVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable3, "|");
						sDimUoMVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable4, "|");
						if (sDepthVal == null || "".equals(sDepthVal)){

							sDepthVal = "0.0";

						}
						if (sWidthVal == null || "".equals(sWidthVal)){

							sWidthVal = "0.0";

						}
						if (sHeightVal == null || "".equals(sHeightVal)){

							sHeightVal = "0.0";

						}
						formatData(sbDepth,sDepthVal);
						formatData(sbWidth,sWidthVal);
						formatData(sbHeight,sHeightVal);
						formatData(sbDimUom,sDimUoMVal);

					} else 
					{
						sDepthVal = "0.0";
						sWidthVal = "0.0";
						sHeightVal = "0.0";
						sDimUoMVal = "";

						formatData(sbDepth,sDepthVal);
						formatData(sbWidth,sWidthVal);
						formatData(sbHeight,sHeightVal);
						formatData(sbDimUom,sDimUoMVal);
					}
				}
			}

		}
		mpPackingUnit.put(ConstantsUtil.ID, sbId.toString());
		mpPackingUnit.put(ConstantsUtil.DEPTH, sbDepth.toString());
		mpPackingUnit.put(ConstantsUtil.WIDTH, sbWidth.toString());
		mpPackingUnit.put(ConstantsUtil.HEIGHT, sbHeight.toString());
		mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE, sbDimUom.toString());
		mpPackingUnit.put(ConstantsUtil.NUMBEROFCONSUMERUNITSPERUNIT, sbNPC.toString());
		mpPackingUnit.put(ConstantsUtil.PACKINGUNITTYPE, sbPackingType.toString());
		mpPackingUnit.put(ConstantsUtil.GROSSWEIGHT, sbGrossWtReal.toString());
		mpPackingUnit.put(ConstantsUtil.AUOM, sbAuom.toString());
		mpPackingUnit.put(ConstantsUtil.GTIN, sGtinValue);
		mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE1, sbGrossWtUom.toString());
		mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE2, sbNetWt.toString());
		mpPackingUnit.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCONSUMERUNIT, sbNetWetOfProdInCU.toString());
		mpPackingUnit.put(ConstantsUtil.CUBEEFFICIENCY, sbCubeEff.toString());

	} catch(Exception e){
		LOGGER.error(" Exception in program MPSBO : getPackagingDimensions");
	}
	
	return util.filterMapList(mpPackingUnit);

}


/**
 * Method Name 			: getNumberPerCustomerUnit
 * Method Description 	:
 * @param context
 * @param mlObjectList
 * @return
 * @throws Exception
 */
public StringBuilder getNumberPerCustomerUnit(Context context, MapList mlObjectList) throws Exception

{

	String sReturn = "";
	StringBuilder sbNumberOfCopPerUnit = new StringBuilder();
	StringList slReturnVal = new StringList();
	String sObjectId = "";
	String strLevel ="";
	String strQuantity="";
	String strType="";
	String iPrevious="";
	Double dQuantity=0.0;

	boolean ipLevel2= false;

	boolean cupLevel1=false;

	try

	{

		mlObjectList.sort("level", "ascending", "integer");

		Iterator objListItr = mlObjectList.iterator();

		while (objListItr.hasNext())

		{

			Map perMap = (Map) objListItr.next();

			strType=(String)perMap.get(DomainConstants.SELECT_TYPE);

			sObjectId = (String)perMap.get(DomainConstants.SELECT_ID);

			strLevel=(String)perMap.get(ConstantsUtil.SELECT_LEVEL);

			strQuantity=(String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);

			DomainObject bomObject = DomainObject.newInstance(context,sObjectId);

			if(UIUtil.isNullOrEmpty(strType) || UIUtil.isNullOrEmpty(strLevel) || UIUtil.isNullOrEmpty(strQuantity) ||  mlObjectList.size()==1)

			{
				slReturnVal.addElement("");
			}

			else

			{

				if(strType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART) && "1".equals(strLevel))

				{
					cupLevel1=true;
				}

				else if(strType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART) && "2".equals(strLevel) && cupLevel1)

				{
					slReturnVal.addElement(strQuantity);
					slReturnVal.addElement("");
					cupLevel1=false;

				}

				else if(strType.equals(ConstantsUtil.TYPE_PGINNERPACKUNITPART) && "2".equals(strLevel) && cupLevel1)

				{
					iPrevious=strQuantity;
					ipLevel2=true;
					slReturnVal.addElement("");
					slReturnVal.addElement("");

				}

				else if(strType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART) && "3".equals(strLevel) && ipLevel2)

				{
					dQuantity=Double.parseDouble(iPrevious) * Double.parseDouble(strQuantity);
					slReturnVal.removeAllElements();
					slReturnVal.addElement(Double.toString(dQuantity));
					slReturnVal.addElement(strQuantity);
					slReturnVal.addElement("");

					ipLevel2=false;

				}

				else

				{
					slReturnVal.addElement("");
				}

			}

		}

		for (int i = 0; i < slReturnVal.size(); i++) {
			formatData(sbNumberOfCopPerUnit,slReturnVal.get(i));
		}



	} catch(Exception e){

		LOGGER.error(" Exception in program MPSBO : getNumberPerCustomerUnit");

	}

	return sbNumberOfCopPerUnit;

}


//SPEC: Release SR18x.6.0.1 - Added by Amman on June 12, 2021 for Defect #43514 -- START
/**
 * Method Name : getTransportUnitDetails
 * Method Description : to fetch the Transport Unit Details for External Users
 * @param context
 * @param resultMaps
 * @return
 */
public Map getTransportUnitDetails(Context context,Map resultMaps)
{
	Map mpTransportUnit = new HashMap();
	StringValidatorUtil validator = new StringValidatorUtil();	
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	
	StringBuilder sbPalletType = new StringBuilder();
	StringBuilder sbOutDimDepth = new StringBuilder();
	StringBuilder sbOutDimWidth = new StringBuilder();
	StringBuilder sbOutDimHght = new StringBuilder();
	StringBuilder sbOutDimUOM = new StringBuilder();
	StringBuilder sbTUP_VOLUME = new StringBuilder();
	StringBuilder sbITUP_UOM = new StringBuilder();
	StringBuilder sbGW_WITH_Pallet = new StringBuilder();
	StringBuilder sbGW_WITHout_Pallet = new StringBuilder();
	StringBuilder sbGW_UOM = new StringBuilder();
	StringBuilder sbCustomlayerperTup = new StringBuilder();
	StringBuilder sblayerperTup = new StringBuilder();
	StringBuilder sbCUPPerTUp = new StringBuilder();
	StringBuilder sbcubeEff = new StringBuilder();
	StringBuilder sbPalletMXhgt = new StringBuilder();
	StringBuilder sbCASMaxHGt = new StringBuilder();
	StringBuilder sbTruckMXHGT = new StringBuilder();
	StringBuilder sbStackPattern = new StringBuilder();
	StringBuilder sbStackPatternId = new StringBuilder();
	StringBuilder sbStackPatternType = new StringBuilder();

	SecurityService sct = new SecurityService();
	String sUserlicense = sct.getUserLicense();
	String sComp = sct.getUserCauthorities();
	StringList slUserOwnership=util.filterOwnerShip(sComp);

	StringList slHIRTypes = new StringList();
	slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
	slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
	slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
	slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
	slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

	try
	{
		String strContextId = (String)resultMaps.get(ConstantsUtil.SELECT_ID);

		DomainObject doTU = new DomainObject(strContextId);

		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDEPTH);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWIDTH);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHEIGHT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUNITOFMEASURE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUME);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUMEUNITOFMEASURE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHPALLET);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLET);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CUSTOM_UNITS_PER_LAYER);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_LAYERS_PER_TUP);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CUP_PER_TUP);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUBEEFFECIENCY);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PALLET_STACK_MAX_HEIGHT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASE_STACK_MAX_HEIGHT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TRUCK_STACK_MAX_HEIGHT);
		slBusSelects.add(ConstantsUtil.SELECT_REF_DOC_TONAME);
		slBusSelects.add(ConstantsUtil.SELECT_REF_DOC_TO_ID);
		slBusSelects.add(ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
		slBusSelects.add(ConstantsUtilIRM.SELECT_REF_DOC_TOCURRENT);
		
		MapList mlTUList = doTU.getRelatedObjects(context, "Extended Data",
				ConstantsUtil.TYPE_PGTRANSPORTUNITCHARACTERISTIC, slBusSelects, null, false, true, (short) 1,
				ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
		//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		doTU.close(context);
		//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		Iterator objectListItr = mlTUList.iterator();

		while(objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
			
			String strPalletType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE));
			String strOutDimDepth = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDEPTH));
			String strOutDimWidth = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWIDTH));
			String strOutDimHght = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHEIGHT));
			String strOutDimUOM = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUNITOFMEASURE));
			String strTUP_VOLUME = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUME));
			String strITUP_UOM = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUMEUNITOFMEASURE));
			String strGW_WITH_Pallet = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHPALLET));
			String strGW_WITHout_Pallet = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLET));
			String strGW_UOM = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
			String strCustomlayerperTup= validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CUSTOM_UNITS_PER_LAYER));
			String strlayerperTup = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LAYERS_PER_TUP));
			String strCUPPerTUp = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CUP_PER_TUP));
			String strcubeEff = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUBEEFFECIENCY));
			String strPalletMXhgt = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PALLET_STACK_MAX_HEIGHT));
			String strCASMaxHGt = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CASE_STACK_MAX_HEIGHT));
			String strTruckMXHGT = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TRUCK_STACK_MAX_HEIGHT));
			String strStackPattern = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME));
			String strStackPatternId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID));
			String strStackPatternType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE));
			String strStackPatternState = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtilIRM.SELECT_REF_DOC_TOCURRENT));
			
			boolean bHasOwnership = false;
			boolean showData = false;

			if(util.isModificatinRequired()) {
				bHasOwnership=util.checkHasAccess(context, null, strStackPatternId);
				if(!bHasOwnership) {
					strStackPatternId = ConstantsUtil.NO_ACCESS;
				}
				if (!ConstantsUtil.RELEASED.equalsIgnoreCase(strStackPatternState)
						&& !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strStackPatternState))) {
					strStackPatternId = ConstantsUtil.NO_ACCESS;
				}
			}else if(sct.isStaffAUGUser()) {
				showData=util.checkHasAccess(context, null,strStackPatternId);
				if(!showData) {
					strStackPatternId = ConstantsUtil.NO_ACCESS;
				}
			}else {
				showData=util.checkHasAccess(context, null,strStackPatternId);
				if(!showData) {
					strStackPatternId = ConstantsUtil.NO_ACCESS;
				}
			}

			formatData(sbPalletType, strPalletType);
			formatData(sbOutDimDepth, strOutDimDepth);
			formatData(sbOutDimWidth, strOutDimWidth);
			formatData(sbOutDimHght, strOutDimHght);
			formatData(sbOutDimUOM, strOutDimUOM);
			formatData(sbTUP_VOLUME, strTUP_VOLUME);
			formatData(sbITUP_UOM, strITUP_UOM);
			formatData(sbGW_WITH_Pallet, strGW_WITH_Pallet);
			formatData(sbGW_WITHout_Pallet, strGW_WITHout_Pallet);
			formatData(sbGW_UOM, strGW_UOM);
			formatData(sbCustomlayerperTup, strCustomlayerperTup);
			formatData(sblayerperTup, strlayerperTup);
			formatData(sbCUPPerTUp, strCUPPerTUp);
			formatData(sbcubeEff, strcubeEff);
			formatData(sbPalletMXhgt, strPalletMXhgt);
			formatData(sbCASMaxHGt, strCASMaxHGt);
			formatData(sbTruckMXHGT, strTruckMXHGT);
			formatData(sbStackPattern, strStackPattern);
			formatData(sbStackPatternId, strStackPatternId);
			formatData(sbStackPatternType, strStackPatternType);
		}
	
		mpTransportUnit.put(ConstantsUtil.PALLETTYPE,sbPalletType);
		mpTransportUnit.put(ConstantsUtil.GTIN,DomainConstants.EMPTY_STRING);
		mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERLAYER,sbCustomlayerperTup);
		mpTransportUnit.put(ConstantsUtil.DEPTH,sbOutDimDepth);
		mpTransportUnit.put(ConstantsUtil.WIDTH,sbOutDimWidth);
		mpTransportUnit.put(ConstantsUtil.HEIGHT,sbOutDimHght);
		mpTransportUnit.put(ConstantsUtil.NUMBEROFLAYERSPERTRANSPORTUNIT,sblayerperTup);
		mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERTRANSPORTUNIT,sbCUPPerTUp);
		mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE, sbOutDimUOM);
		mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE1, sbITUP_UOM);
		mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE2, sbGW_UOM);
		mpTransportUnit.put(ConstantsUtil.TUPVOLUME,sbTUP_VOLUME);
		mpTransportUnit.put(ConstantsUtil.CUBEEFFICIENCY,sbcubeEff);
		mpTransportUnit.put(ConstantsUtil.WAREHOUSEPALLETSTACKHEIGHTMAXIMUM,sbPalletMXhgt);
		mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHPALLET,sbGW_WITH_Pallet);
		mpTransportUnit.put(ConstantsUtil.WAREHOUSECASESTACKHEIGHTMAXIMUM,sbCASMaxHGt);
		mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHOUTPALLET,sbGW_WITHout_Pallet);
		mpTransportUnit.put(ConstantsUtil.TRUCKPALLETSTACKHEIGHTMAXIMUM,sbTruckMXHGT);
		mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODE,sbStackPattern);
		mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODEID,sbStackPatternId);
		mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODETYPE,sbStackPatternType);
		
	}catch(Exception e){
		LOGGER.error("Error from MPSBO:  getTransportUnitDetails"+e);
		return new HashMap();
	}
	return mpTransportUnit;
}
//SPEC: Release SR18x.6.0.1 - Added by Amman on June 12, 2021 for Defect #43514 -- END
}
