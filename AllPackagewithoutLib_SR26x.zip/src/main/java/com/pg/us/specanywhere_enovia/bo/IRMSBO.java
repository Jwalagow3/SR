/**
 * Project 		: SpecsAnywhere
 * Program 		: IRMSBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.FileUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.util.Pattern;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class IRMSBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(IRMSBO.class);
	static StringValidatorUtil validator = new StringValidatorUtil();
	static BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
	public IRMSBO() {
		// empty constructor
	}

	public IRMSBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getMaterialProduced
	 * Method Description 	: Fetching "Materials Produced" related information
	 * @param context
	 * @param strObjId
	 * @returns materials Produced
	 */
	public Map getMaterialProduced(Context context,String strObjId)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		
		StringBuilder sbId=new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();
		
		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbRevision=new StringBuilder();
		StringBuilder sbOwner=new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();
		
		try
		{
			if(UIUtil.isNotNullAndNotEmpty(strObjId))
				{
					DomainObject contextObj = DomainObject.newInstance(context,strObjId);
					StringList selectStmts = new StringList(5);                     
					selectStmts.addElement(ConstantsUtil.SELECT_ID);
					selectStmts.addElement(ConstantsUtil.SELECT_TYPE);
					selectStmts.addElement(ConstantsUtil.SELECT_NAME);
					selectStmts.addElement(ConstantsUtil.SELECT_REVISION);
					selectStmts.addElement(ConstantsUtil.SELECT_DESCRIPTION);
					selectStmts.addElement(ConstantsUtil.SELECT_CURRENT);		
					selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);	
					
					Pattern typePattern = new Pattern(ConstantsUtil.TYPE_RAWMATERIALPART);
					typePattern.addPattern(ConstantsUtil.TYPE_PGRAWMATERIAL);

					MapList mlRelatedIAPSList = contextObj.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_PGDEFINESMATERIAL,  
							typePattern.getPattern(), 
							selectStmts,                
							null,              
							false,                        
							true,                       
							(short)1,                    
							null,                        
							null,0);
					//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
					contextObj.close(context);
					//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
					Iterator objectListItr = mlRelatedIAPSList.iterator();
					
					while(objectListItr.hasNext())
					{
						Map resultMaps = (Map) objectListItr.next();
						
						String strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.TYPE));
						String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.ID));
						String strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.NAME));
						
						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
						//String strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.DESCRIPTION));
						String strDesc	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.DESCRIPTION));
						//String strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String strTitle	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
						
						String strRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
						String strState	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
						String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
						
						formatData(sbType,strType);
						formatData(sbName,strName);
						formatData(sbDesc,strDesc);
						formatData(sbCurrent,strState);
						formatData(sbId,strID);
						formatData(sbRevision,strRev);
						formatData(sbPhase,strPhase);
						formatData(sbTitle,strTitle);
						
					}
						
					mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString());
					mpSubStanceResult.put(ConstantsUtil.TITLE,sbDesc.toString());
					mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString());
					mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString());
					mpSubStanceResult.put(ConstantsUtil.REV,sbRevision.toString());
					mpSubStanceResult.put(ConstantsUtil.STATE,sbCurrent.toString());
					mpSubStanceResult.put(ConstantsUtil.PHASE, sbPhase.toString());
					mpSubStanceResult.put(ConstantsUtil.ID, sbId.toString());
			}

		}catch(Exception e){

			LOGGER.error("Error from DeviceProductPartBO:  getSubstances"+e);
			return new HashMap();
		}
		return util.filterMapList(mpSubStanceResult);
	}
	
	
	/**
	 * Method Name 			: formatData
	 * Method Description 	:
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
	
	
	/**
	 * Method Name 			: getIRMSBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getIRMSBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getIRMSDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getIRMSDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getIRMSPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getIRMSPartSelectables(Context context) {
		StringList busSelect = new StringList(150);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getProfileIdentificationSelectables(context));
		busSelect.addAll(getOrgSelects(context));
		busSelect.addAll(getChemicalClassficationsSelectables(context));
		busSelect.addAll(getPhysicalPropertiesSelectables(context));
		busSelect.addAll(getPerfumePropertiesSelectables(context));
		busSelect.addAll(getChemicalMolecularSelectables(context));
		busSelect.addAll(getDetergentSurfactantSelectables(context));
		busSelect.addAll(getReachSelectables(context));
		busSelect.addAll(getStartingMaterialsSelectables(context));
		busSelect.addAll(getSubstanceSelectables(context));
		busSelect.addAll(getWeightCharSelectables(context));
		busSelect.addAll(getMEPS(context));
		busSelect.addAll(getSEPS(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getAlternateSelects(context));
		busSelect.addAll(getIRMSMasterSpecs(context));
		busSelect.addAll(getPlantInfoSelectable(context));
		busSelect.addAll(getRegSafetySelectables());
		
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
		busSelect.addAll(getSecuritySelects(context));
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
				
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}


	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);

		busSelect.add(ConstantsUtil.REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.STR_TEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_SAP_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SAP_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);

		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_NAME);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TITLE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ID);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.ATL_ORGNSOURCE);

		return busSelect;

	}
	

	/**
	 * Method Name 			: getProfileIdentificationSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getProfileIdentificationSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INCINAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICALNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EMPIRICALFORMULA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STANDARDCOSTPERKG);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COLORINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRMCISPRONUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPERIMENTALNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALUSAGEGUIDANCE);
		return busSelect;
	}

	
	/**
	 * Method Name 			: getOrgSelects
	 * Method Description 	: Fetching "Organization" related data
	 * @param context
	 * @return
	 */
	public static StringList getOrgSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		return busSelect;

	}
	
	
	/**
	 * Method Name 			: getChemicalClassficationsSelectables
	 * Method Description 	: Fetching "Chemical Classification" related data
	 * @param context
	 * @return
	 */
	public static StringList getChemicalClassficationsSelectables (Context context) {
		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EINECSNUMBER);
		//SPEC: <17.05.2021>: Bala Added for External Defect Dev 18x.6.0.1   -- START
		//busSelect.add(ConstantsUtil.SELECT_REL_MATERIAL_FUNCTIONALITY);
		busSelect.add(ConstantsUtil.SELECT_REL_PGMATERIALFUNCTIONGLOBAL);
		//SPEC: <17.05.2021>: Bala Added for External Defect Dev 18x.6.0.1   -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS);
		//SPEC: Release SR18x.6.0 - Added for IRMS  by Manikanta on Date 03/03/2021 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FLAVOURCLUSTERRANK);
		//SPEC: Release SR18x.6.0 - Added for IRMS  by Manikanta on Date 03/03/2021 -- END

		return busSelect;
	}

	
	/**
	 * Method Name 			: getRegSafetySelectables
	 * Method Description 	:
	 * @return
	 */
	public static StringList getRegSafetySelectables () {
		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIAL_ORIGIN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COLOR_INDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVALENCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICAL_REACTIVITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEINECSELINCSNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MOLECULAR_FORMULA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_RPHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_SPHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAFETYSYMBOL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGERCATEGORY);
		return busSelect;
	}

	
	/**
	 * Method Name 			: getPhysicalPropertiesSelectables
	 * Method Description 	: Fetching "Physical Properties" related data
	 * @param context
	 * @return
	 */
	public static StringList getPhysicalPropertiesSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_APPEARANCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COLOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SPECIFICGRAVITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MELTINGPOINT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_BOILINGPOINT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_VISCOSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PHYSICALFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PHYSICALFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_GRADE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRMAQUEOUSSOLUBILITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPERATURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FLASHPOINT);
		return busSelect;
	}


	/**
	 * Method Name 			: getPerfumePropertiesSelectables
	 * Method Description 	: Fetching "Perfume Properties" related data
	 * @param context
	 * @return
	 */
	public static StringList getPerfumePropertiesSelectables(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGODORFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYODORDESCRIPTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYODORDESCRIPTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGODORDESCRIPTION);
		return busSelect;

	}

	
	/**
	 * Method Name 			: getChemicalMolecularSelectables
	 * Method Description 	: Fetching "Chemical Molecular" related data
	 * @param context
	 * @return
	 */
	public static StringList getChemicalMolecularSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HYDROPHILICLIPOPHILICBALANCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SAPONIFICATIONVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHYDROPHILICINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HYDROXYLVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACTIVITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_IUSPERGRAM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ALKALINITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ISANIMALDERIVED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PHVALUE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getDetergentSurfactantSelectables
	 * Method Description 	: Fetching "Detergent Surface" related data
	 * @param context
	 * @return
	 */
	public static StringList getDetergentSurfactantSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SO3CONTRIBUTOR);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getReachSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getReachSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getStartingMaterialsSelectables
	 * Method Description 	: Fetching "Starting Materials" related details
	 * @param context
	 * @return
	 */
	public static StringList getStartingMaterialsSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_TYPE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_NAME);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_REVISION);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_PHASE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_TITLE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_STATE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_ORIGIN_SOURCE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	: Fetching "Substances" related data
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceSelectables (Context context) 
	{
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.COMP_TYPE); 
		busSelect.add(ConstantsUtil.COMP_ID); 
		busSelect.add(ConstantsUtil.COMP_NAME);  
		busSelect.add(ConstantsUtil.COMP_REVS);  
		busSelect.add(ConstantsUtil.COMP_DESC); 
		busSelect.add(ConstantsUtil.COMP_TITLE); 
		busSelect.add(ConstantsUtil.COMP_PHASE);
		busSelect.add(ConstantsUtil.COMP_STATE); 
		busSelect.add(ConstantsUtil.COMP_CASNUM);  		
		busSelect.add(ConstantsUtil.COMP_SUBNAME);  		
		busSelect.add(ConstantsUtil.COMP_QSTCOMPOSITE);  
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);  		
		busSelect.add(ConstantsUtil.COMP_QTY);  			
		busSelect.add(ConstantsUtil.COMP_MAXHGHT);  		
		busSelect.add(ConstantsUtil.COMP_MINHGHT);  		
		busSelect.add(ConstantsUtil.COMP_QUOM);  	
		
		busSelect.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
        busSelect.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
        
        //SPEC: <11.07.2020>: Modified for Defect 37114 ## -- START
        busSelect.add(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE);  		
		busSelect.add(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE);  
		busSelect.add(ConstantsUtil.SELECT_COMP_DRYWEGHT);
		//SPEC: <11.07.2020>: Modified for Defect 37114 ## -- END

		return busSelect;
	}

	
	/**
	 * Method Name 			: getWeightCharSelectables
	 * Method Description 	: Fetching "Weight Characteristics" data
	 * @param context
	 * @return
	 */
	public static StringList getWeightCharSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_TYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_NAME);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_GROSSWEIGHTUOM);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_GROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_COMMENTS);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching "Plant" related data
	 * @param context
	 * @return
	 */
	public static StringList getPlantSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getAlternateSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getAlternateSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_BASE_UOM);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE__RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE__ORIGIN_SOURCE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getLifeCycleSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getLifeCycleSelectables (Context context) {
		StringList busSelect = new StringList();
		return busSelect;
	}

	
	/**
	 * Method Name 			: getMEPS
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getMEPS(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMNAME);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMREVISION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMCURRENT);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME);
		return busSelect;
	}

	
	/**
	 * Method Name 			: getSEPS
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getSEPS(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPTYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPNAME);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPREVISION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPCURRENT);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SUPNAME);
		return busSelect;
	}


	/**
	 * Method Name 			: getIRMSMasterSpecs
	 * Method Description 	: Fetching "Master Specifications" related data
	 * @param context
	 * @return
	 */
	public static StringList getIRMSMasterSpecs(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_ID);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TYPE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_NAME);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT);
		return busSelect;

	}
	
	
	/**
	 * Method Name 			: getPlantInfoSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getPlantInfoSelectable(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		return busSelect;
	}

	
	/**
	 * Method Name 			: updateDerivedDataInfo
	 * Method Description 	:
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sType
	 * @param sID
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceRev, String sType, String sID, String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		
		StringList slRelSelects = new StringList();

		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , slRelSelects, getTo, getFrom, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();
			
			StringBuilder sbDerivedType = new StringBuilder();
			StringBuilder sbSourceType=new StringBuilder();
			
			StringBuilder sbDerivedId = new StringBuilder();
			StringBuilder sbSourceId=new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				StringValidatorUtil validator = new StringValidatorUtil();
				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDerivedId=(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sDerivedType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=util.mapType((String)objectMap.get(ConstantsUtil.SELECT_CURRENT));
				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				if (UIUtil.isNullOrEmpty(sOrganization)) {
					sOrganization=ConstantsUtil.EMPTY_STRING;
				}
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
					util.formatData(sbDerivedName,sSourceName);
					util.formatData(sbSourceName,sDerivedName);
					
					util.formatData(sbDerivedType,sType);
					util.formatData(sbSourceType,sDerivedType);
					
					util.formatData(sbDerivedId,sID);
					util.formatData(sbSourceId,sDerivedId);
					
				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);
					
					util.formatData(sbDerivedType,sDerivedType);
					util.formatData(sbSourceType,sType);
					
					util.formatData(sbDerivedId,sDerivedId);
					util.formatData(sbSourceId,sID);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);


			}

			
			mpDerived.put(ConstantsUtil.SOURCETYPE, sbSourceType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDTYPE, sbDerivedType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDID, sbDerivedId.toString());
			mpDerived.put(ConstantsUtil.SOURCEID, sbSourceId.toString());
			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : IRMSBO Method :updateRefDocs "+e);
			return new HashMap();
		}
		return mpDerived;
	}

	
	/**
	 * Method Name 			: updatePlantInfo
	 * Method Description 	:
	 * @param objectMap
	 * @return
	 */
	public Map updatePlantInfo(Map objectMap) {
		Map<String, String> mpPlant = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			String sPlantName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_NAME));
			String sAuthorize = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE));
			String sProduce = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE));
			String sIsActivated = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED));
			String sPlantView = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW));
			
			sPlantView = util.replaceSpecialSymbols(sPlantView);
			sAuthorize = util.replaceSpecialSymbols(sAuthorize);
			sPlantName = util.replaceSpecialSymbols(sPlantName);
			sProduce = util.replaceSpecialSymbols(sProduce);
			sIsActivated = util.replaceSpecialSymbols(sIsActivated);
			//SPEC: 22/03/2021: Modified for 18x.6 Defect #40843 by Bala-- START 
			String strSAPType = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
			if(strSAPType.equalsIgnoreCase("HALB"))
			{
				mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOUSE, sAuthorize);
				mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOPRODUCE, sProduce);
			}
			else if(strSAPType.equalsIgnoreCase("ROH") || UIUtil.isNullOrEmpty(strSAPType))
			{
				mpPlant.put(ConstantsUtil.PLANTVIEW, sPlantView);
			}
			//SPEC: 22/03/2021: Modified for 18x.6 Defect #40843 by Bala-- END 
			mpPlant.put(ConstantsUtil.PLANTS, sPlantName);
			mpPlant.put(ConstantsUtil.PLANTSISACTIVATED, sIsActivated);
			

		}catch(Exception e){
			LOGGER.error("Error from IRMSBO:  updatePlantInfo"+e);
			return new HashMap();
		}
		return  mpPlant;
	}

	
	/**
	 * Method Name 			: getSpecifications
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map getSpecifications(Context context,Map objectMap)
	{

		Map<String, String> mpSpecifications = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try	{


			String strID = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ID));
			String strName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_NAME));
			String strType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TYPE));
			String strSapDec = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TITLE));
			String strSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ASSEMBLYTYPE));
			String strCurrent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_CURRENT));

			
			strID= util.replaceSpecialSymbols(strID);
			strName= util.replaceSpecialSymbols(strName);
			strType= util.replaceSpecialSymbols(strType);
			strSapDec= util.replaceSpecialSymbols(strSapDec);
			strSubType= util.replaceSpecialSymbols(strSubType);
			strCurrent= util.replaceSpecialSymbols(strCurrent);
			
			mpSpecifications.put(ConstantsUtil.ID,strID);
			mpSpecifications.put(ConstantsUtil.NAME,strName);
			mpSpecifications.put(ConstantsUtil.TYPE,util.mapType(strType));
			mpSpecifications.put(ConstantsUtil.SAPDES,strSapDec);
			mpSpecifications.put(ConstantsUtil.SPECIFICATIONSUBTYPE,strSubType);
			mpSpecifications.put(ConstantsUtil.STATE,strCurrent);


		}catch(Exception e){

			LOGGER.error("Error from IRMSBO:  getSpecifications"+e);
			return new HashMap();
		}

		return mpSpecifications;
	}
	
	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	: Fetching "Substances" data
	 * @param objectMap
	 * @return
	 */
	public Map getSubstances(Map objectMap)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{

			String strDesc = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_DESC));
			String strID	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_ID));
			String strTitle = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_TITLE));
			String strType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_TYPE));
			String strName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_NAME));
			String strRev = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_REVS));
			String strPhase = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_PHASE));
			String strState = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_STATE));
			strState=strState.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);

			String strCAS = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_CASNUM));
			String StrSub = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_SUBNAME));
			String strQty = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_QTY));
			String strQts = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_QSTCOMPOSITE));
			String strCont = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_ISCONTAM));
			
			//SPEC: <11.07.2020>: Modified for Defect 37114 ## -- START
			//String strMaxWt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_MAXHGHT));
			String strMaxWt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE));
			//String strMinWt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_MINHGHT));
			String strMinWt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE));
			//SPEC: <11.07.2020>: Modified for Defect 37114 ## -- END
			
			String StrQom = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_QUOM));
			
			String strMlLgc = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_METALENVCLASS));
			String strPCED = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_POSTCONSUMER));
			
			//SPEC: <11.07.2020>: Modified for Defect 37114 ## -- START
			//String sDRY     =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_DRYWEIGHT));
			String sDRY     =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_COMP_DRYWEGHT));
			//SPEC: <11.07.2020>: Modified for Defect 37114 ## -- END
			
			String sUF = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.EMPTY_STRING));
			String sCont    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.COMP_ISCONTAM));
			String strMFR = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_MANUF));
			String strCMT = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_COMENT));
			String strFN = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_SEQUENCE));
			String strTRN = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_MARKETNAME));
			String strMlyr = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_MATELAYER));
			
			String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);

			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,strDesc);
			mpSubStanceResult.put(ConstantsUtil.TITLE,strTitle);
			mpSubStanceResult.put(ConstantsUtil.TYPE,strType);
			mpSubStanceResult.put(ConstantsUtil.NAME,strName);
			mpSubStanceResult.put(ConstantsUtil.REV,strRev);
			mpSubStanceResult.put(ConstantsUtil.STATE,strState);
			mpSubStanceResult.put(ConstantsUtil.CAS,strCAS);
			mpSubStanceResult.put(ConstantsUtil.SUBSTANCENAME,StrSub);
			mpSubStanceResult.put(ConstantsUtil.QSTARGET,strQts);
			mpSubStanceResult.put(ConstantsUtil.TW,strQty);
//			mpSubStanceResult.put(ConstantsUtil.IC,strCont);
			mpSubStanceResult.put(ConstantsUtil.MAX,strMaxWt);
			mpSubStanceResult.put(ConstantsUtil.MIN,strMinWt);
			mpSubStanceResult.put(ConstantsUtil.UOM,StrQom);
			mpSubStanceResult.put(ConstantsUtil.PHASE,strPhase);
			mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sDRY);
			mpSubStanceResult.put(ConstantsUtil.UF,sUF);
			mpSubStanceResult.put(ConstantsUtil.IP,sCont);
			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,strMlLgc);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,strPCED);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,strMFR);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,strCMT);
			mpSubStanceResult.put(ConstantsUtil.FNUM,strFN);
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,strTRN);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,strMlyr);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);


		}catch(Exception e){

			LOGGER.error("Error from IRMSBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}


	/**
	 * Method Name 			: getMasterAttributeData
	 * Method Description 	: Fetching "Master Attribute" information
	 * @param context
	 * @param sMasterID
	 * @return
	 * @throws Exception
	 */
	public Map getMasterAttributeData(Context context, String sMasterID) throws Exception {

		Map<String, Object> mpAttribResult = new HashMap<String, Object>();
		StringList busSelect = new StringList();	
		DomainObject doIRMS =  getIRMSDO(context, sMasterID);
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		Map resultMaps = doIRMS.getInfo(context,busSelect);
		//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		doIRMS.close(context);
		StringValidatorUtil validator = new StringValidatorUtil();
		try {
		//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
			mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);		
			mpAttribResult.put(ConstantsUtil.TEMPLATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_TEMPLATE)))?(String)resultMaps.get(ConstantsUtil.STR_TEMPLATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
		//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		}catch(Exception e)
		{
			LOGGER.error("Exception in Program : IRMSBO Method :getMasterAttributeData "+e);
			return new HashMap();
		}
		//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
		return mpAttribResult;
	}


	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList(){

		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.REFRECNE_DOCUMENT_TYPE);
		slMultiSelects.add(ConstantsUtil.REFRECNE_DOCUMENT_NAME);
		slMultiSelects.add(ConstantsUtil.REFRECNE_DOCUMENT_REVISION);
		slMultiSelects.add(ConstantsUtil.COMP_TYPE); 
		slMultiSelects.add(ConstantsUtil.COMP_ID);  
		slMultiSelects.add(ConstantsUtil.COMP_NAME);  
		slMultiSelects.add(ConstantsUtil.COMP_REVS);  
		slMultiSelects.add(ConstantsUtil.COMP_DESC); 
		slMultiSelects.add(ConstantsUtil.COMP_TITLE); 
		slMultiSelects.add(ConstantsUtil.COMP_STATE); 
		slMultiSelects.add(ConstantsUtil.COMP_PHASE);
		slMultiSelects.add(ConstantsUtil.COMP_CASNUM);  		
		slMultiSelects.add(ConstantsUtil.COMP_SUBNAME);  		
		slMultiSelects.add(ConstantsUtil.COMP_QSTCOMPOSITE);  
		slMultiSelects.add(ConstantsUtil.COMP_ISCONTAM);  		
		slMultiSelects.add(ConstantsUtil.COMP_QTY);  			
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_QUOM);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ASSEMBLYTYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_CURRENT);
		slMultiSelects.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		slMultiSelects.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE);  		
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE); 
		slMultiSelects.add(ConstantsUtil.SELECT_COMP_DRYWEGHT);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_PGMATERIALFUNCTIONGLOBAL);
		slMultiSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);  
		slMultiSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);  
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);

		return slMultiSelects;
	}


	/**
	 * Method Name 			: removeMultiValueList
	 * Method Description 	:
	 */
	public void removeMultiValueList() 
	{

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REFRECNE_DOCUMENT_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REFRECNE_DOCUMENT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REFRECNE_DOCUMENT_REVISION);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REVS);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_STATE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CASNUM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SUBNAME);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QSTCOMPOSITE);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ISCONTAM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);  			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ASSEMBLYTYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ID);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CLASSIFIED_ITEM);
        DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
        
        //SPEC: <11.07.2020>: Modified for Defect 37114 ## -- START
        DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COMP_DRYWEGHT);
		//SPEC: <11.07.2020>: Modified for Defect 37114 ## -- END
		
		//SPEC: Release SR18x.5.2 - Added for Defect 38216 by Amman ## -- START
		//SPEC: <17.05.2021>: Bala Added for External Defect Dev 18x.6.0.1   -- START
		//DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_MATERIAL_FUNCTIONALITY); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_PGMATERIALFUNCTIONGLOBAL); 	
		//SPEC: <17.05.2021>: Bala Added for External Defect Dev 18x.6.0.1   -- END
		//SPEC: Release SR18x.5.2 - Added for Defect 38216 by Amman ## -- END
		
		//SPEC: Release SR18x.5.2: Modified for Defect 38797 by Amman ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);  
		//SPEC: Release SR18x.5.2: Modified for Defect 38797 by Amman ## -- END
		
		//SPEC: Added for Defect 43707 by Jwala ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END
	}

	
	/**
	 * Method Name 			: getEDList
	 * Method Description 	: Fetching "Electronic Distribution" related data
	 * @param resultMaps
	 * @return
	 */
	public static String getEDList(Map resultMaps,String ldapuser,String ldappwd) {
		String sAttrVal =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION) : ConstantsUtil.EMPTY_STRING;
		String strAttrValue=ConstantsUtil.EMPTY_STRING;
		String strValue=ConstantsUtil.EMPTY_STRING;
		StringTokenizer newValues=null;
		StringList strList=new StringList();

		if (sAttrVal != null && sAttrVal.trim().length() > 0) {
			newValues=new StringTokenizer(sAttrVal,ConstantsUtil.SYMBL_PIPE);
			while(newValues.hasMoreTokens())
			{
				strAttrValue=newValues.nextToken();
				if(null!=strAttrValue && (!strAttrValue.isEmpty())){
					strAttrValue = BbUtil.getLDAPInfo(strAttrValue.trim(), true,ldapuser,ldappwd);
					strList.addElement(strAttrValue);
					strList.sort();
					strValue = FrameworkUtil.join(strList, ConstantsUtil.SYMBL_PIPE);
				}
			}

		}
		return strValue;

	}
	
	//SPEC: <10.20.2020>: Added for req 18x.5 ## -- Start
	 public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
	    	Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
	    	MapList mlIPCLass;
			try {
				mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
						null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
						ConstantsUtil.ZERO_LEVEL);
				Iterator itr = mlIPCLass.iterator();
				Map mpIpClass = new HashMap();
				StringBuilder sbIpName = new StringBuilder();
				StringBuilder sbHasClassAccess = new StringBuilder();
				StringBuilder sbIpType = new StringBuilder();
				StringBuilder sbIpDesc = new StringBuilder();
				StringBuilder sbIpState = new StringBuilder();
				StringBuilder sbIpLibrary = new StringBuilder();
				StringBuilder sbIpClassPath = new StringBuilder();
				
				while(itr.hasNext()) {
					mpIpClass = (Map)itr.next();
					String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
					sbIpName.append(sIpClassName);
					sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
					sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
					sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
					String strIpClass="";
					if(sIpClassName.contains(ConstantsUtil.HIR)) {
						strIpClass=ConstantsUtil.HIGHLY_RESTRICTED;
						sbIpLibrary.append(strIpClass);
					} else {
						strIpClass= ConstantsUtil.BUSINESS_USE;
						sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
					}
					if(!strIpClass.isEmpty()) {
						StringBuilder sbIpClassTemp = new StringBuilder();
						sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
						sbIpClassPath.append(sbIpClassTemp.toString());
					}
					
					//Compare user classification against IPName
					sbHasClassAccess.append("TRUE");
					
					if(itr.hasNext()) {
						sbIpName.append("|");
						sbIpType.append("|");
						sbIpDesc.append("|");
						sbIpState.append("|");
						sbIpLibrary.append("|");
						sbIpClassPath.append("|");
						sbHasClassAccess.append("|");
					}
				}
				mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
				mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
				mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
				mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
				//mpIpSecuritySetting.put(ConstantsUtil.LIBRARY, sbIpLibrary.toString());
				//mpIpSecuritySetting.put(ConstantsUtil.CLASSIFICATIONPATH, sbIpClassPath.toString());
				mpIpSecuritySetting.put(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
			} catch (FrameworkException e) {
				e.printStackTrace();
				LOGGER.error("Error from MPPBO: getIpClass" + e);
			}
			return mpIpSecuritySetting;
	    }
	
	public static Map getProductPartStabilityDoc(Context context,Map resultMaps) 
	{
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTREVISION);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
		
		boolean bHasOwnerShip = false;
		
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		
		if(aCompany.length>-1) {
			for(int i=0;i<aCompany.length;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}

		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
		//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 start
		String sObjectName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
		String sObjectSapDesc = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING;
		String sObjectRev = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
		//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 end
		//SPEC: 03-5-2021: Modified for 18x.6 DEV by Manikanta -- START
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbMasterProductPartName = new StringBuilder();
		StringBuilder sbMasterProductPartRevision = new StringBuilder();
		StringBuilder sbMasterProductPartTitle =new StringBuilder();
		StringBuilder sbProductExpirationDataRequired=new StringBuilder();
		StringBuilder sbTotalShelfLifeDays=new StringBuilder();
		StringBuilder sbTemperatureGroup=new StringBuilder();
		StringBuilder sbHumidityGroup=new StringBuilder();
		StringBuilder sbTransportFreezeProtection = new StringBuilder();
		StringBuilder sbTransportHeatProtection = new StringBuilder();
		StringBuilder sbBoundaryConditions = new StringBuilder();
		StringBuilder sbStabilityDocument = new StringBuilder();
		// Guna Added for Defect 38534  18x.5.2 Release -- START
		StringBuilder sbStabilityDocumentType = new StringBuilder();
		// Guna Added for Defect 38534  18x.5.2 Release -- END
		
		//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 end							
		StringBuilder sbProductPartName = new StringBuilder();
		StringBuilder sbProductPartId = new StringBuilder();
		StringBuilder sbProductPartRev = new StringBuilder();
		StringBuilder sbProductPartTitle = new StringBuilder();
		StringBuilder sbProductPartType = new StringBuilder();
		//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 end
		
		Map<String, String> mpRefDoc = new HashMap();
		try
		{
			if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
			DomainObject doFOP = new DomainObject(sObjectId);
			MapList mlproductparts = doFOP.getRelatedObjects(context, // MatrixContext
					ConstantsUtil.RELATIONSHIP_PGDEFINESMATERIAL, // Relationship Pattern
					ConstantsUtilIRM.Stability_Document_AllowedParts, // Type Pattern
					true, // getTo
					false, // getFrom
					(short) 1, // Recurse to Level
					new StringList (DomainConstants.SELECT_CURRENT), // Object selectables
					DomainConstants.EMPTY_STRINGLIST, // Relationship selectables
					DomainConstants.EMPTY_STRING, // Object Where clause
					DomainConstants.EMPTY_STRING, // Relationship Where clause
					0, // get objects
					null, // Post Relationship Pattern
					null, // Post Type Pattern
					null);
			//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
			doFOP.close(context);
			//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
			Map mProductPartMap = null;
			String oID = DomainConstants.EMPTY_STRING;
			String currentState = DomainConstants.EMPTY_STRING;
			if(mlproductparts.size() > 0) {
			int NumberOfpart = mlproductparts.size();
			DomainObject domProductPartObj = null;
			for(int i=0; i< NumberOfpart ;i++) {
			mProductPartMap = (Map)mlproductparts.get(i);
			oID = (String) mProductPartMap.get(DomainConstants.SELECT_ID);
			currentState = (String) mProductPartMap.get(DomainConstants.SELECT_CURRENT);
			if (UIUtil.isNotNullAndNotEmpty(oID) && currentState.equals(ConstantsUtil.RELEASE))
			{
				domProductPartObj = DomainObject.newInstance(context,oID);
				MapList mlRefDocs = domProductPartObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
				domProductPartObj.close(context);
				//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
			String sUser = BbUtil.getUserType();
		
			if(sUser.equals(ConstantsUtil.PG_CM))
			{
				if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
					return new HashMap();
				}
			}
			
			if(BbUtil.isModificatinRequired()) 
			{
				mlRefDocs=BbUtil.filterPhase(mlRefDocs);
			}
			Iterator objectListItr = mlRefDocs.iterator();
			
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sId    =  (String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	 =	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
				
				String sMasterProductPartName    =  validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartRevision    =   validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTREVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartTitle		=	validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTITLE))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTITLE) : ConstantsUtil.EMPTY_STRING;
				String sProductExpirationDataRequired	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
				String sTotalShelfLifeDays		=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
				String sTemperatureGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
				String sHumidityGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
				String sTransportFreezeProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
				String sTransportHeatProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
				String sBoundaryConditions = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
				String sStabilityDocument = (String)objectMap.get(ConstantsUtil.SELECT_NAME);
				
				StringList eachOwnership = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = BbUtil.filterOwnerShip(eachOwnership);
				
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;
				
				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}
				
				if(!sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)&& !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
				{
					String sLangBuffer =ConstantsUtil.EMPTY_STRING;
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;

				if (BbUtil.isModificatinRequired()) 
				{
					//bHasOwnerShip = BbUtil.checkOwnerShip(sbCompany,slEachOwnership);
					//Added by Ganesh Start
					bHasOwnerShip = BbUtil.checkHasAccess(context, null, sId);
					//Added by Ganesh stop
					if(sCurrent!=ConstantsUtil.RELEASE) {
						bHasOwnerShip=false;
					}
					//SPEC: Release SR18x.6- Added by Manikanta for EBP Req# 33248- START
					if(!bHasOwnerShip) {
						continue;
					}
					//SPEC: Release SR18x.6- Added by Manikanta for EBP Req# 33248- END
					if(bHasOwnerShip) 
					{
						BbUtil.formatData(sbId,sId);
						BbUtil.formatData(sbMasterProductPartName,sMasterProductPartName);
						BbUtil.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
						BbUtil.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
						BbUtil.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
						BbUtil.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
						BbUtil.formatData(sbTemperatureGroup,sTemperatureGroup);
						BbUtil.formatData(sbHumidityGroup,sHumidityGroup);
						BbUtil.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
						BbUtil.formatData(sbTransportHeatProtection,sTransportHeatProtection);
						BbUtil.formatData(sbBoundaryConditions,sBoundaryConditions);
						BbUtil.formatData(sbStabilityDocument,sStabilityDocument);
						// Guna Added for Defect 38534  18x.5.2 Release -- START
						BbUtil.formatData(sbStabilityDocumentType,sType);
						// Guna Added for Defect 38534  18x.5.2 Release -- END
						
						//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 start
						BbUtil.formatData(sbProductPartName,sObjectName);
						BbUtil.formatData(sbProductPartId,sObjectId);
						BbUtil.formatData(sbProductPartTitle,sObjectSapDesc);
						BbUtil.formatData(sbProductPartRev,sObjectRev);
						BbUtil.formatData(sbProductPartType,sObjectType);
						//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 end
					}
				}else if(sct.isStaffAUGUser()) {
					/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = BbUtil.getFormulaPropagateClassification(context, sId);
						showData=BbUtil.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=BbUtil.checkInternalUserAcess(sUserlicense,strClassFied);
					}*/
					//Added by Ganesh start
					showData = BbUtil.checkHasAccess(context, null, sId);
					//Added by ganesh stop
					if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
						showData=false;
					}
				}else {
					/*StringList slHIRTypes = new StringList();
					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

					if(slHIRTypes.contains(sType)) {
						showData=BbUtil.checkInternalUserAcess(sUserlicense,strClassFied);
					}else {
						showData=true;
					}*/
					//Added by Ganesh start
					showData = BbUtil.checkHasAccess(context, null, sId);
					//Added by Ganesh stop
				}	

				if(showData) 
				{
					BbUtil.formatData(sbId,sId);
					BbUtil.formatData(sbMasterProductPartName,sMasterProductPartName);
					BbUtil.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
					BbUtil.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
					BbUtil.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
					BbUtil.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
					BbUtil.formatData(sbTemperatureGroup,sTemperatureGroup);
					BbUtil.formatData(sbHumidityGroup,sHumidityGroup);
					BbUtil.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
					BbUtil.formatData(sbTransportHeatProtection,sTransportHeatProtection);
					BbUtil.formatData(sbBoundaryConditions,sBoundaryConditions);
					BbUtil.formatData(sbStabilityDocument,sStabilityDocument);
					// Guna Added for Defect 38534  18x.5.2 Release -- START
					BbUtil.formatData(sbStabilityDocumentType,sType);
					// Guna Added for Defect 38534  18x.5.2 Release -- END
					//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 start
					BbUtil.formatData(sbProductPartName,sObjectName);
					BbUtil.formatData(sbProductPartId,sObjectId);
					BbUtil.formatData(sbProductPartTitle,sObjectSapDesc);
					BbUtil.formatData(sbProductPartRev,sObjectRev);
					BbUtil.formatData(sbProductPartType,sObjectType);
					//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 end
				}else
				{
					BbUtil.formatData(sbId,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbMasterProductPartName,sMasterProductPartName);
					BbUtil.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
					BbUtil.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbProductExpirationDataRequired,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbTotalShelfLifeDays,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbTemperatureGroup,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbHumidityGroup,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbTransportFreezeProtection,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbTransportHeatProtection,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbBoundaryConditions,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbStabilityDocument,ConstantsUtil.NO_ACCESS);
					// Guna Added for Defect 38534  18x.5.2 Release -- START
					BbUtil.formatData(sbStabilityDocumentType,sType);
					// Guna Added for Defect 38534  18x.5.2 Release -- END
					//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 start
					BbUtil.formatData(sbProductPartName,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbProductPartId,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbProductPartTitle,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbProductPartRev,ConstantsUtil.NO_ACCESS);
					BbUtil.formatData(sbProductPartType,ConstantsUtil.NO_ACCESS);
					//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 end
				}
			  }
			}
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			//mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTNAME, sbMasterProductPartName.toString());
			//mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTREV, sbMasterProductPartRevision.toString());
			//mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTTITLE, sbMasterProductPartTitle.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTEXPDATEREQ, sbProductExpirationDataRequired.toString());
			mpRefDoc.put(ConstantsUtil.TOTALSHELFLIFEDAYS, sbTotalShelfLifeDays.toString());
			mpRefDoc.put(ConstantsUtil.TEMPERATUREGROUP, sbTemperatureGroup.toString());
			mpRefDoc.put(ConstantsUtil.HUMIDITYGROUP, sbHumidityGroup.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, sbTransportFreezeProtection.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTHEATPROTECTION, sbTransportHeatProtection.toString());
			mpRefDoc.put(ConstantsUtil.BOUNDARYCONDITIONS, sbBoundaryConditions.toString());
			mpRefDoc.put(ConstantsUtil.STABILITYDOCUMENT, sbStabilityDocument.toString());
			// Guna Added for Defect 38534  18x.5.2 Release -- START
			mpRefDoc.put(ConstantsUtil.TYPE, sbStabilityDocumentType.toString());
			// Guna Added for Defect 38534  18x.5.2 Release -- END
			
			//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 start
			mpRefDoc.put(ConstantsUtil.PRODUCTPARTNAME,sbProductPartName.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTPARTID,sbProductPartId.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTPARTTITLE,sbProductPartTitle.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTPARTREVISION,sbProductPartRev.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTPARTTYPE,sbProductPartType.toString());
			//SPEC: Release SR18x5.2- modified for Defect #39778 by Govind on Date 19/02/2021 end
			}
			}
			}
			}
			//SPEC: 03-5-2021: Modified for 18x.6 DEV by Manikanta -- END
			}catch(Exception e){

			LOGGER.error("Exception in Program : IRMSBO Method :updateRefDocs "+e);
			return new HashMap();
		}
		return BbUtil.filterMapList(mpRefDoc);
		//return mpRefDoc;
	}
	/*
	* Method Name 			: updateRefDocs
	 * Method Description 	: Getting the Reference Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map updateRefDocs(Context context,Map resultMaps) 
	{
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();
		CommonDocBO commonDoc = new CommonDocBO();
		FileUtil fileUtil = new FileUtil();
		
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		//SPEC: <11.07.2020>: Modified for Defect 37114 ## -- START
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		//SPEC: <11.07.2020>: Modified for Defect 37114 ## -- END
		//SPEC: <19.03.2021>: Guna Added for Req 38530 Dev 18x.6   -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		//SPEC: <19.03.2021>: Guna Added for Req 38530 Dev 18x.6   -- END
		boolean bHasOwnerShip = false;
		
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		
		if(aCompany.length>-1) {
			for(int i=0;i<aCompany.length;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}

		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

		
		Map<String, String> mpRefDoc = new HashMap();
		try
		{
			DomainObject dobCdoc = new DomainObject(sObjectId);
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
			dobCdoc.close(context);
			//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
			String sUser = util.getUserType();
			//SPEC: <19.05.2021>: Guna Commented for Internal Defect  Dev 18x.6.0.1   -- START
			/*if(sUser.equals(ConstantsUtil.PG_CM))
			{
				if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
					return new HashMap();
				}
			}
			
			if(util.isModificatinRequired()) 
			{
				mlRelatedSpecs=util.filterPhase(mlRelatedSpecs);
			}*/
			//SPEC: <19.05.2021>: Guna Commented for Internal Defect  Dev 18x.6.0.1   -- END
			Iterator objectListItr = mlRelatedSpecs.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType=new StringBuilder();
			StringBuilder sbRev=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbDescription=new StringBuilder();
			StringBuilder sbTitle=new StringBuilder();
			StringBuilder sbLangBuffer = new StringBuilder();
			StringBuilder sbSource = new StringBuilder();
			StringBuilder sbFilePath = new StringBuilder();
			StringBuilder sbGendocName = new StringBuilder();
			StringBuilder sbGendocPath = new StringBuilder();
			// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
						// : 02-08-2021 -- START
						StringBuilder sbIsIRM = new StringBuilder();
						StringBuilder sbGendocFormat = new StringBuilder();
						// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
						// : 02-08-2021 -- END
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sType    =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
				String sId		=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sCurrent	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
				String sRev		=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				String sName    =   validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_NAME));
				DomainObject doRefDoc = new DomainObject(sId);
				boolean bisIRMDoc = commonDoc.isIRMDoc(sType);
				//SPEC: <11.07.2020>: Modified for Defect 37114 ## -- START
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39455  by Guna on Date 18/02/2021 -- START
				/*if((sType.equalsIgnoreCase(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sCurrent.equals("Exists")) || bisIRMDoc) {
					sName    =   (String)objectMap.get(ConstantsUtil.SELECT_NAME);
				}*/
				if(bisIRMDoc){
					sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				}
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39455  by Guna on Date 18/02/2021 -- END
				
				String sFilePath    =   validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_CAPTURED));
				//SPEC: <11.07.2020>: Modified for Defect 37114 ## -- END
				
				
				String sDesc	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sTitle	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				String sPGLangBuffer	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE));
				String sPLangBuffer	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE));
				String strClassFied = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				StringList eachOwnership = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);
				
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;
				if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE)) {
					continue;
				}
				
				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}
				
				// SPEC: Added for 18x.5.2 DEV --Shashank -- START
				Map mpFiles = new HashMap();
				String sGendocName="";
				String sGendocPath="";
				// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments
				// On : 02-08-2021 -- START
				String sGendocPathFormat = "";
				// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments
				// On : 02-08-2021 -- END
				if(bisIRMDoc) {
					mpFiles=fileUtil.getGendocForIRM(context, doRefDoc);
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
				}else {
					// SPEC: Modified for 18x.5.2 DEV -- Guna For ReferenceDocuments
					// On : 02-08-2021 -- START
					//mpFiles=fileUtil.getGendocForReferenceDocuments(context, doRefDoc);
					mpFiles = fileUtil.getFilesForIPM(context, doRefDoc);
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
					sGendocPathFormat = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FORMAT_FILE));
					// SPEC: Modified for 18x.5.2 DEV -- Guna For ReferenceDocuments
					// On : 02-08-2021 -- START
				}
				// SPEC: Added for 18x.5.2 DEV --Shashank -- END
				
				//SPEC: <19.03.2021>: Guna Added for Req 38530 Dev 18x.6   -- START
				
				String	strFileType=validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE));;
				if("Reference_File".equalsIgnoreCase(strFileType) || "Reference File".equalsIgnoreCase(strFileType)){
					strFileType="Reference File";
					}else if("QEC_File".equalsIgnoreCase(strFileType)){
						strFileType="Quality Evolution Chart File";
					}else if("Design_File".equalsIgnoreCase(strFileType)){
						strFileType="Design File";
					}else if("Language_Rendition".equalsIgnoreCase(strFileType)){
						strFileType="Language Rendition";
					}
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43864 on Date 29/06/2021 --START
				String strType=sType;
				String strName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43864 on Date 29/06/2021 --END
				//SPEC: <07.04.2021>: Guna Modified for 42005 Defect  Dev 18x.6   -- START
				if(UIUtil.isNotNullAndNotEmpty(strFileType)){
				     sType=strFileType;
				}
				//SPEC: <07.04.2021>: Guna Modified for 42005 Defect  Dev 18x.6   -- END

				//SPEC: <19.03.2021>: Guna Added  for Req 38530 Dev 18x.6   -- END
				
				
				String sLangBuffer =ConstantsUtil.EMPTY_STRING;
				if(!sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
				{
					
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;
					//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43864 on Date 29/06/2021 --START
					if(strType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)){
						if (strName.contains("LR_")) {
							sLangBuffer = sRev;
						}
						else {
							sLangBuffer = "";
						}
				     }
					//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43864 on Date 29/06/2021 --END

				if (util.isModificatinRequired()) 
				{
					//bHasOwnerShip = util.checkOwnerShip(sbCompany,slEachOwnership);
					//Added by Ganesh start
					bHasOwnerShip = util.checkHasAccess(context, null, sId);
					//Added by Ganesh stop
					//Added by Ganesh 1.0.2 Release End
					//SPEC: <04.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
					//if(sCurrent!=ConstantsUtil.RELEASE) {
					//SPEC: <19.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
						if(!sCurrent.equals(ConstantsUtil.RELEASE) && !sCurrent.equals(ConstantsUtil.STATE_EXISTS)) {
							//SPEC: <19.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
						//SPEC: <04.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
						bHasOwnerShip=false;
					}
					//SPEC: Release SR18x.6- Added by Manikanta for EBP Req# 33248- START
					if(!bHasOwnerShip) {
						continue;
					}
					//SPEC: Release SR18x.6- Added by Manikanta for EBP Req# 33248- END
					if(bHasOwnerShip) 
					{
						//SPEC: <04.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
					/*	util.formatData(sbType,util.mapType(sType));
						util.formatData(sbName,sName);
						util.formatData(sbDescription,sDesc);
						util.formatData(sbCurrent,sCurrent);
						util.formatData(sbId,sId);
						util.formatData(sbRev,sRev);
						util.formatData(sbTitle,sTitle);
						util.formatData(sbSource,ConstantsUtil.EMPTY_STRING);
						util.formatData(sbLangBuffer,sLangBuffer);
						util.formatData(sbFilePath,sFilePath);
						util.formatData(sbGendocName, sGendocName);
						util.formatData(sbGendocPath, sGendocPath);
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- START
						util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, sGendocPathFormat);*/
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- END
						 showData =true;
						   //SPEC: <04.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
					}
				}else if(sct.isStaffAUGUser()) {
					/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}*/
					//Added by Ganesh start
					showData = util.checkHasAccess(context, null, sId);
					//Added by ganesh stop
				}else {
					/*StringList slHIRTypes = new StringList();
					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

					if(slHIRTypes.contains(sType)) {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}else {
						showData=true;
					}*/
					//Added by Ganesh start
					showData = util.checkHasAccess(context, null, sId);
					//Added by Ganesh stop
				}	

				if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
					sId=ConstantsUtil.EMPTY_STRING;
				}
				
				if(showData) 
				{
					util.formatData(sbType,util.mapType(sType));
					util.formatData(sbName,sName);
					util.formatData(sbFilePath,sFilePath);
					util.formatData(sbDescription,sDesc);
					util.formatData(sbCurrent,sCurrent);
					//util.formatData(sbId,sId);
					util.formatData(sbRev,sRev);
					util.formatData(sbTitle,sTitle);
					//util.formatData(sbSource,ConstantsUtil.EMPTY_STRING);
					util.formatData(sbSource,ConstantsUtil.SOURCE_DIRECT);
					util.formatData(sbLangBuffer,sLangBuffer);
					//This is a temporary addition to block IRM documents. This will be removed during Release 18x5.2
					/*if (sType.equals(ConstantsUtil.TYPE_PKDIPLATFORM)
							|| sType.equals(ConstantsUtil.TYPE_PGPKGSTUDYPROTOCOL)
							|| sType.equals(ConstantsUtil.TYPE_PGCONSUMERRESEARCH)
							|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONPROTOCOL)
							|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONOTHER)
							|| sType.equals(ConstantsUtil.TYPE_PGTECHNICALRATIONAL)
							|| sType.equals(ConstantsUtil.TYPE_PGPKGSTABILITYREPORT)
							|| sType.equals(ConstantsUtil.TYPE_PGSTABILITYOUTOFSPECREPORT)
							|| sType.equals(ConstantsUtil.TYPE_PGSTABILITYOTHER)
							|| sType.equals(ConstantsUtil.TYPE_PGRTAGENERICDOCUMENT)
							|| sType.equals(ConstantsUtil.TYPE_PGPKGDEVELOPMENTOTHER)
							|| sType.equals(ConstantsUtil.TYPE_PGCOREINNOVATIONRECORD)
							|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONREPORT)
							){
						sId = ConstantsUtil.EMPTY_STRING;
						util.formatData(sbId,sId);
					}else {*/
						util.formatData(sbId,sId);
						util.formatData(sbGendocName, sGendocName);
						util.formatData(sbGendocPath, sGendocPath);
					//}
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- START
						util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, sGendocPathFormat);
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- END
				}
				else
				{
					util.formatData(sbType,util.mapType(sType));
					util.formatData(sbName,sName);
					util.formatData(sbFilePath,sFilePath);
					util.formatData(sbDescription,ConstantsUtil.NO_ACCESS);
					util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
					util.formatData(sbId,ConstantsUtil.NO_ACCESS);
					util.formatData(sbRev,ConstantsUtil.NO_ACCESS);
					util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
					util.formatData(sbSource,ConstantsUtil.NO_ACCESS);
					util.formatData(sbLangBuffer,ConstantsUtil.NO_ACCESS);
					util.formatData(sbGendocName, ConstantsUtil.NO_ACCESS);
					util.formatData(sbGendocPath, ConstantsUtil.NO_ACCESS);
					// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- START
					sGendocPathFormat=ConstantsUtil.NO_ACCESS;
					// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- END
				}
				}else
				{
					util.formatData(sbType,util.mapType(sType));
					util.formatData(sbName,sName);
					util.formatData(sbFilePath,sFilePath);
					util.formatData(sbDescription,sDesc);
					util.formatData(sbCurrent,sCurrent);
					util.formatData(sbId,sId);
					util.formatData(sbRev,sRev);
					util.formatData(sbTitle,sTitle);
					util.formatData(sbSource,ConstantsUtil.SOURCE_DIRECT);
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;
					util.formatData(sbLangBuffer,sLangBuffer);
					util.formatData(sbGendocName, sGendocName);
					util.formatData(sbGendocPath, sGendocPath);
					// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- START
					util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
					util.formatData(sbGendocFormat, sGendocPathFormat);
					// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- END
				}

			}

			mpRefDoc.put(ConstantsUtil.NAME, sbName.toString());
			mpRefDoc.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpRefDoc.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpRefDoc.put(ConstantsUtil.TYPE, sbType.toString());
			mpRefDoc.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpRefDoc.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.LANGUAGE, sbLangBuffer.toString());
			mpRefDoc.put(ConstantsUtil.REVISION, sbRev.toString());
			mpRefDoc.put(ConstantsUtil.FILESPATH, sbFilePath.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCNAME, sbGendocName.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCPATH, sbGendocPath.toString());
			// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
						// : 02-08-2021 -- START
						mpRefDoc.put(ConstantsUtil.ISIRM, sbIsIRM.toString());
						mpRefDoc.put(ConstantsUtil.GENDOCFORMAT, sbGendocFormat.toString());
						// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
						// : 02-08-2021 -- END
		}catch(Exception e){

			LOGGER.error("Exception in Program : MasterCOPBO Method :updateRefDocs "+e);
			return new HashMap();
		}
		return util.filterMapList(mpRefDoc);
		//return mpRefDoc;
	}
	//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
	
	
	public Map updatePartSpec(Context context, Map objectMap) {
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpPartSpecs = new HashMap<String, String>();
		try {

			String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
					String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
							? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

							mpPartSpecs = getPartSpecifications(context, sType, sID);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :updatePartSpec " + e);
			return new HashMap();

		}
		return util.filterMapList(mpPartSpecs);
	}
	
	
	public HashMap getPartSpecifications(Context context, String sParentType, String sObjectID) throws Exception {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		StringBuilder sbRevision = new StringBuilder();
		StringBuilder sbDescription = new StringBuilder();
		StringBuilder sbArtworkPrimary = new StringBuilder();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		boolean showData = true;
		
		//String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION+","+ConstantsUtil.REL_PG_INHERITED_CAD_SPEC;
		
		//if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
		String 	sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
					+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		//}
		//Pattern sRelationPattern = new Pattern(ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION);
		//sRelationPattern.addPattern(ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST);
		
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		StringList slRelSelects = new StringList();
		slRelSelects.addElement(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, ConstantsUtil.SYMBL_ASTERISK,
					slPartSpecSelects, null, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);

			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				//Added for defect #37081 -- START
				String strOriginatingSrc = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE));
				String strPolicy  = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.POLICY));
				//Added for defect #37081 -- END
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				String strRevision = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_REVISION));
				String strDescription = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_DESCRIPTION));
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
				
				//SPEC: 10/30/2020: Added for Defect 36711  -- START
				if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)){
					strDescription = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYDESCRIPTION));
				}
				//SPEC: 10/30/2020: Added for Defect 36711  -- END
				
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strAutocadClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));
				
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				String sArtworkPrimary = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY));
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);
				
				if(sArtworkPrimary.isEmpty()){
					sArtworkPrimary = "No";
				}
				//commented by Ganesh Start
				/*if (util.isModificatinRequired()) {
					if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {

						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
								sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
								String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForSubstituteString(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							}

						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

						}

					} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
							|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								String sView = util.updateReferences(context, strId);
								LOGGER.info("COMMON DOC SERVICE  SOP VIEW:" + sView + "User :" + sUserType);

								if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
										&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								} else {

									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
									sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
									String strState = validator
											.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
									sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
									String strTitle = validator.getStringEquivalentForSubstituteString(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									
									//SPEC: 10/30/2020: Added for Defect 36711  -- START
									if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)){
										strTitle = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYVNAME));
									}
									//SPEC: 10/30/2020: Added for Defect 36711  -- END
									
									sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
									String strOrig = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
									sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

								}
							}
						}else
						{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
							sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					}

				} else {
					if(sct.isStaffAUGUser()) {
						
						if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strType.equalsIgnoreCase("Formulation Part")){
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else if("ArtiosCAD Component".equalsIgnoreCase(strType)){
							showData=util.checkInternalUserAcess(sUserlicense,strAutocadClassFied);
						}else{
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}
					}else {
						StringList slHIRTypes = new StringList();
						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
						slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
						
						if(slHIRTypes.contains(strType)) {
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
							// Added for Defect #37081 -- START
						}else if(strOriginatingSrc.equalsIgnoreCase(ConstantsUtil.DSO) || (strType.equalsIgnoreCase(ConstantsUtil.TYPE_TECHNICALSPECIFICATION) && strOriginatingSrc.equalsIgnoreCase(ConstantsUtil.DSO) && !strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGAUTHORIZEDTEMPORARYSTANDARD)&& !strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATECHNICALSPEC) && !strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGAUTHORIZEDCONFIGURATIONSTANDARD) && !strType.equalsIgnoreCase(ConstantsUtil.TYPE_TESTMETHOD) && !strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGTESTMETHOD) && !strPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_SUPPLIEREQUIVALENT) && !strPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT) && !strType.equalsIgnoreCase(ConstantsUtil.TYPE_PRODUCTDATAPART))) {
							//(strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGARTWORK) && 
							// Added for Defect #37081 -- END
							showData=true;
						}
						
					}
					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
						sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
						String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC: 10/30/2020: Added for Defect 36711  -- START
						if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)){
							strTitle = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYVNAME));
						}
						//SPEC: 10/30/2020: Added for Defect 36711  -- END
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						//temporary fix to prevent users from downloading a Physical product(VPMReference)
						if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
							sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
						}else {
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
						// Modified for Defect #37081 -- START
						//sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						// Modified for Defect #37081 -- START
						sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

					}
					
				}*/
				//Added by Ganesh Start
				
				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
String strId_Result = strId;
if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
strId_Result=ConstantsUtil.NO_ACCESS;
}

//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END

				showData = util.checkHasAccess(context, sUserType, strId);
				if (showData) {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
					sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
					sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
					//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
					sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
					String strTitle = validator.getStringEquivalentForSubstituteString(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					//SPEC: 10/30/2020: Added for Defect 36711  -- START
					if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)){
						strTitle = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYVNAME));
					}
					//SPEC: 10/30/2020: Added for Defect 36711  -- END
					sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
					String strOrig = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
					sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
					//temporary fix to prevent users from downloading a Physical product(VPMReference)
					if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
						sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
					}else {
						
//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
/*String strState = validator
.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
					}
				} else {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					// Modified for Defect #37081 -- START
					//sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
					sbRevision.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					// Modified for Defect #37081 -- START
					sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
					//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
					sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

				}
				//Added by Ganesh stop

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			mpFinalList.put(ConstantsUtil.REVISION, sbRevision.toString());
			mpFinalList.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			mpFinalList.put(ConstantsUtil.ARTWORKPRIMARY, sbArtworkPrimary.toString());
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//}
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END

		} catch (FrameworkException e) {
			LOGGER.info("Exception in BusObjectAttribUtil getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}
	
	
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
		public static StringList getSecuritySelects(Context context) {
			
			StringList slIpSelects = new StringList();
			slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
			slIpSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
			slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
			slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
			slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
			
			return slIpSelects;

		}
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
		
		/*// SPEC: 02/04/2021: Added for Defect 38797 -- START
		*//**
		 * Method Name 			: getSecondaryOrganization
		 * Method Description 	: Fetching "pgSecondayOrganization" related data
		 * @param context
		 * @return
		 *//*
		public StringBuilder getSecondaryOrganization(Context context, DomainObject doIRMS) {
			StringBuilder sbSecondaryOrg = new StringBuilder();
			try
			{		  
				String strSecOrgList = DomainConstants.EMPTY_STRING;
				String strObjId = ConstantsUtil.EMPTY_STRING;
				String  strObName = ConstantsUtil.EMPTY_STRING;
				Map map = new HashMap();		
				StringList slSelect = new StringList(DomainConstants.SELECT_NAME);
				slSelect.addElement(DomainConstants.SELECT_ID);
				MapList mlPDInfo = doIRMS.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_PGSECONDARYORGANIZATION,
						ConstantsUtil.TYPE_PGPLIORGANIZATIONCHANGEMANAGEMENT,
						slSelect,
						null,
						false,
						true,
						(short)1,
						null,
						null, 0);
				mlPDInfo.sort("name", "ascending", "String");	
				if(mlPDInfo != null && !mlPDInfo.isEmpty())
				{
					for(int i=0;i<mlPDInfo.size();i++)
					{
						map = (Map)mlPDInfo.get(i);
						if(map != null && !map.isEmpty())
						{
							strObjId = (String)map.get(DomainConstants.SELECT_ID);
							strObName = (String)map.get(DomainConstants.SELECT_NAME);
							sbSecondaryOrg.append(strObName).append(",");
						}
					}
				}			 		
			}
			catch(Exception e)
			{
				LOGGER.info("Exception in IRMSBO getSecondaryOrganization: " + e);
				return new StringBuilder();
			}
			sbSecondaryOrg.deleteCharAt(sbSecondaryOrg.lastIndexOf(","));
			return sbSecondaryOrg;
		}
		// SPEC: 02/04/2021: Added for Defect 38797 -- END
*/
}
